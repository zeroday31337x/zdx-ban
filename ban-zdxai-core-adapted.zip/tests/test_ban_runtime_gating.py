from __future__ import annotations

from zdxai.ban.runtime import BANRuntime
from zdxai.ban.types import Authority, MeasurementContract, OperationalFailure, SupportState
from zdxai.config import Config


def test_unverified_output_does_not_become_semantic_memory(tmp_path):
    cfg = Config(base_dir=tmp_path)
    runtime = BANRuntime(cfg)
    runtime.startup(load_model=False, load_embeddings=False)
    try:
        stored = runtime.remember_episode(
            content="The provider failed, therefore this reasoning strategy is wrong.",
            tags=["provider_failure"],
            support=SupportState.UNVERIFIED,
        )
        assert stored is None
        assert runtime.memory_store.list_active() == []
    finally:
        runtime.shutdown()


def test_compliant_measurement_can_create_semantic_episode(tmp_path):
    cfg = Config(base_dir=tmp_path)
    runtime = BANRuntime(cfg)
    runtime.startup(load_model=False, load_embeddings=False)
    try:
        measurement = MeasurementContract(
            contract_id="m-1",
            claim="2+2=4",
            outcome="SUPPORTED",
            verification_class="DETERMINISTIC",
            authority=Authority.MEASURED,
            repeatable=True,
            method="integer arithmetic",
            evidence={"observed": 4, "expected": 4},
        )
        stored = runtime.remember_episode(
            content="Integer arithmetic result was supported.",
            tags=["arithmetic", "deterministic"],
            support=SupportState.SUPPORTED,
            authority=Authority.MEASURED,
            measurement=measurement,
        )
        assert stored is not None
        assert len(runtime.memory_store.list_active()) == 1
    finally:
        runtime.shutdown()


def test_operational_failure_is_separate_from_semantic_memory(tmp_path):
    cfg = Config(base_dir=tmp_path)
    runtime = BANRuntime(cfg)
    runtime.startup(load_model=False, load_embeddings=False)
    try:
        runtime.record_operational_failure(
            OperationalFailure(
                provider="ollama",
                code="RUNNER_MISSING",
                message="llama-server binary not found",
            ),
            run_id="run-1",
        )
        assert runtime.memory_store.list_active() == []
        row = runtime.db.execute("SELECT provider, code FROM ban_operational_events").fetchone()
        assert row["provider"] == "ollama"
        assert row["code"] == "RUNNER_MISSING"
    finally:
        runtime.shutdown()
