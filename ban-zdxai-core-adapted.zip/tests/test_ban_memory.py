from __future__ import annotations

from pathlib import Path

import numpy as np

from zdxai.ban.memory import BANMemory
from zdxai.ban.store import BANMemoryStore
from zdxai.ban.tags import merge_tags, tag_similarity
from zdxai.ban.types import (
    Authority,
    ContextTag,
    MemoryRecord,
    MemoryTier,
    SupportState,
)
from zdxai.config import Config
from zdxai.storage.database import Database


class FakeEmbeddingEngine:
    is_loaded = True

    def embed(self, text: str) -> np.ndarray:
        # deterministic 4-d test embedding; enough to test scoring semantics
        v = np.zeros(4, dtype=np.float32)
        for i, b in enumerate(text.encode("utf-8")):
            v[i % 4] += (b % 17) + 1
        n = np.linalg.norm(v)
        return v / n if n else v


def _setup(tmp_path: Path):
    cfg = Config(base_dir=tmp_path)
    cfg.ban_memory_min_score = 0.0
    db = Database(cfg.db_path)
    db.open()
    db.migrate()
    store = BANMemoryStore(db)
    memory = BANMemory(cfg, store, FakeEmbeddingEngine())
    return cfg, db, store, memory


def test_more_distinct_matching_tags_reduce_ambiguity():
    query = merge_tags([
        ContextTag("postgres", "domain"),
        ContextTag("migration", "task"),
        ContextTag("rollback", "strategy"),
    ])
    generic = [ContextTag("postgres", "domain")]
    specific = [
        ContextTag("postgres", "domain"),
        ContextTag("migration", "task"),
        ContextTag("rollback", "strategy"),
    ]
    assert tag_similarity(query, specific) > tag_similarity(query, generic)


def test_retrieval_is_reference_not_equivalence(tmp_path: Path):
    cfg, db, store, memory = _setup(tmp_path)
    try:
        memory.remember(MemoryRecord(
            id="memory-good",
            content="A previous PostgreSQL migration was recovered by rolling back the schema change.",
            tier=MemoryTier.DOMAIN,
            category="coding_debugging",
            support=SupportState.SUPPORTED,
            authority=Authority.MEASURED,
            tags=[
                ContextTag("postgres", "domain"),
                ContextTag("migration", "task"),
                ContextTag("rollback", "strategy"),
            ],
        ))
        refs = memory.retrieve(
            "Debug this PostgreSQL migration without assuming the old rollback applies.",
            supplied_tags=["postgres", "migration", "novel_case"],
            category="coding_debugging",
            run_id="test-run",
        )
        assert refs
        assert refs[0].relation == "context_reference"
        working = memory.build_working_memory(refs)
        assert "not declarations that the current situation is the same" in working.context_text
        assert "Current measurements/evidence outrank historical memory" in working.context_text
    finally:
        db.close()


def test_misleading_memory_remains_retrievable_and_labeled(tmp_path: Path):
    cfg, db, store, memory = _setup(tmp_path)
    try:
        for mid, support in (
            ("memory-good", SupportState.SUPPORTED),
            ("memory-bad", SupportState.CONTRADICTED),
        ):
            memory.remember(MemoryRecord(
                id=mid,
                content="Recovery path for the same tagged runtime failure.",
                tier=MemoryTier.DOMAIN,
                category="forced_recovery",
                support=support,
                failure_relevant=True,
                tags=["ollama", "arm64", "recovery"],
            ))
        refs = memory.retrieve(
            "Recover an arm64 ollama runtime failure",
            supplied_tags=["ollama", "arm64", "recovery"],
            category="forced_recovery",
            failure_context=True,
            run_id="misleading-test",
        )
        ids = {r.memory.id for r in refs}
        assert {"memory-good", "memory-bad"}.issubset(ids)
        bad = next(r for r in refs if r.memory.id == "memory-bad")
        assert bad.memory.support == SupportState.CONTRADICTED
    finally:
        db.close()


def test_snapshot_hash_is_stable_for_unchanged_semantic_state(tmp_path: Path):
    cfg, db, store, memory = _setup(tmp_path)
    try:
        memory.remember(MemoryRecord(
            id="memory-1",
            content="stable",
            tags=["one", "two"],
        ))
        first = store.snapshot_hash()
        second = store.snapshot_hash()
        assert first == second
    finally:
        db.close()
