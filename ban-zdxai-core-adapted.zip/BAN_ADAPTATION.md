# BAN adaptation of the ZDXAI local-model core

This tree preserves the existing ZDXAI wrapper and adds a BAN-specific runtime under `src/zdxai/ban/`.

## What changed

- Direct GGUF inference remains through `llama-cpp-python`; BAN does not require an Ollama server boundary.
- Added tiered BAN semantic memory with context tags, relationship-scored retrieval, provenance, support state, authority, supersession, retrieval attribution, and stable memory snapshot hashes.
- Context tags are references only. A high retrieval score means "worth reminding the model about," never "this is the same case."
- Current measurements/evidence explicitly outrank historical memory in working context.
- Contradicted/misleading memories remain retrievable so BAN can test rejection and recovery rather than silently deleting inconvenient history.
- Provider/runtime failures are stored in `ban_operational_events`, separate from semantic memories. A missing model runner cannot become a domain reasoning lesson.
- Semantic episodic writes are measurement-gated by default. Unverified model output is not automatically learned.
- Gravity-well splitting is deterministic from learned state instead of process-global random state, improving experiment replay.
- Added schema migration v4 for BAN memory and attribution tables.
- Added tests for context-tag specificity, misleading-memory retrieval, reference-not-equivalence semantics, stable snapshot hashing, measurement gating, and operational-memory separation.

## Integration point

Instantiate `zdxai.ban.BANRuntime` with the existing `Config`. It owns SQLite, direct local inference, embeddings, BAN memory retrieval, and genuine llama.cpp streaming. Existing Go BAN graph/measurement logic can remain authoritative while this runtime supplies the local-model and memory/reference layer, or the Python runtime can be expanded into the full BAN execution shell.
