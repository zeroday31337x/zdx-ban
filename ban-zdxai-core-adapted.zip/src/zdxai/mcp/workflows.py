"""Workflow engine — define and execute multi-step tool chains."""

from __future__ import annotations

import json
import logging
import re
import uuid
from collections.abc import Callable
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, TYPE_CHECKING

from zdxai.constants import WORKFLOW_MAX_STEPS
from zdxai.storage.database import Database

if TYPE_CHECKING:
    from zdxai.mcp.server import MCPServer, ToolCallRequest

log = logging.getLogger(__name__)


@dataclass
class WorkflowStep:
    """A single step in a workflow."""
    tool_name: str
    arguments: dict[str, Any]
    description: str = ""
    on_error: str = "abort"  # 'abort', 'skip', 'continue'
    condition: str | None = None  # simple condition on previous result


@dataclass
class WorkflowDefinition:
    """A reusable workflow template."""
    name: str
    description: str
    steps: list[WorkflowStep]


@dataclass
class WorkflowStepResult:
    """Result of executing a single workflow step."""
    step_index: int
    tool_name: str
    output: str
    success: bool
    skipped: bool = False


@dataclass
class WorkflowResult:
    """Result of executing a complete workflow."""
    workflow_name: str
    steps: list[WorkflowStepResult]
    success: bool
    error: str | None = None


class WorkflowEngine:
    """Execute multi-step tool chains with variable substitution."""

    def __init__(self, mcp_server: MCPServer, db: Database) -> None:
        self._mcp = mcp_server
        self._db = db
        self._workflows: dict[str, WorkflowDefinition] = {}

    def register_workflow(self, workflow: WorkflowDefinition) -> None:
        """Register a workflow definition (in-memory and optionally in DB)."""
        if len(workflow.steps) > WORKFLOW_MAX_STEPS:
            raise ValueError(
                f"Workflow '{workflow.name}' has {len(workflow.steps)} steps "
                f"(max {WORKFLOW_MAX_STEPS})."
            )
        self._workflows[workflow.name] = workflow

        # Persist to DB
        now = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%fZ")
        steps_json = json.dumps([
            {
                "tool_name": s.tool_name,
                "arguments": s.arguments,
                "description": s.description,
                "on_error": s.on_error,
                "condition": s.condition,
            }
            for s in workflow.steps
        ])

        self._db.execute(
            "INSERT INTO workflows (id, name, description, steps_json, created_at, updated_at) "
            "VALUES (?, ?, ?, ?, ?, ?) "
            "ON CONFLICT(name) DO UPDATE SET "
            "description=excluded.description, steps_json=excluded.steps_json, "
            "updated_at=excluded.updated_at",
            (uuid.uuid4().hex, workflow.name, workflow.description, steps_json, now, now),
        )
        self._db.commit()
        log.debug("Registered workflow: %s (%d steps)", workflow.name, len(workflow.steps))

    def list_workflows(self) -> list[WorkflowDefinition]:
        """List all registered workflows."""
        return list(self._workflows.values())

    def get_workflow(self, name: str) -> WorkflowDefinition | None:
        """Get a workflow by name."""
        if name in self._workflows:
            return self._workflows[name]

        # Try loading from DB
        row = self._db.execute(
            "SELECT name, description, steps_json FROM workflows WHERE name = ?",
            (name,),
        ).fetchone()
        if row is None:
            return None

        steps_data = json.loads(row["steps_json"])
        workflow = WorkflowDefinition(
            name=row["name"],
            description=row["description"] or "",
            steps=[
                WorkflowStep(
                    tool_name=s["tool_name"],
                    arguments=s["arguments"],
                    description=s.get("description", ""),
                    on_error=s.get("on_error", "abort"),
                    condition=s.get("condition"),
                )
                for s in steps_data
            ],
        )
        self._workflows[name] = workflow
        return workflow

    def delete_workflow(self, name: str) -> None:
        """Remove a workflow definition."""
        self._workflows.pop(name, None)
        self._db.execute("DELETE FROM workflows WHERE name = ?", (name,))
        self._db.commit()

    def execute(
        self,
        workflow: WorkflowDefinition,
        initial_context: dict[str, str] | None = None,
        conversation_id: str | None = None,
        progress_callback: Callable[[WorkflowStepResult], None] | None = None,
    ) -> WorkflowResult:
        """Execute a workflow sequentially.

        Variable substitution in step arguments:
        - ${prev_result}      — output of the previous step
        - ${step_N_result}    — output of step N (0-indexed)
        - ${context.key}      — value from initial_context
        """
        from zdxai.mcp.server import ToolCallRequest

        context = dict(initial_context or {})
        step_results: list[WorkflowStepResult] = []
        execution_id = uuid.uuid4().hex
        now = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%fZ")

        # Log execution start
        self._db.execute(
            "INSERT INTO workflow_executions "
            "(id, workflow_name, status, total_steps, context_json, conversation_id, started_at) "
            "VALUES (?, ?, 'running', ?, ?, ?, ?)",
            (
                execution_id, workflow.name, len(workflow.steps),
                json.dumps(context), conversation_id, now,
            ),
        )
        self._db.commit()

        for i, step in enumerate(workflow.steps):
            # Check condition
            if step.condition and step_results:
                if not self._check_condition(step.condition, step_results[-1]):
                    result = WorkflowStepResult(
                        step_index=i,
                        tool_name=step.tool_name,
                        output="Skipped: condition not met",
                        success=True,
                        skipped=True,
                    )
                    step_results.append(result)
                    if progress_callback:
                        progress_callback(result)
                    continue

            # Substitute variables in arguments
            resolved_args = self._substitute_variables(
                step.arguments, step_results, context
            )

            # Execute the tool
            call = ToolCallRequest(name=step.tool_name, arguments=resolved_args)
            tool_result = self._mcp.execute_tool(call, conversation_id)

            result = WorkflowStepResult(
                step_index=i,
                tool_name=step.tool_name,
                output=tool_result.output,
                success=tool_result.success,
            )
            step_results.append(result)

            if progress_callback:
                progress_callback(result)

            # Update execution progress
            self._db.execute(
                "UPDATE workflow_executions SET steps_completed = ? WHERE id = ?",
                (i + 1, execution_id),
            )
            self._db.commit()

            # Handle errors
            if not tool_result.success:
                if step.on_error == "abort":
                    self._finalize_execution(execution_id, "failed", tool_result.output)
                    return WorkflowResult(
                        workflow_name=workflow.name,
                        steps=step_results,
                        success=False,
                        error=f"Step {i} ({step.tool_name}) failed: {tool_result.output}",
                    )
                elif step.on_error == "skip":
                    continue
                # 'continue' — just keep going

        self._finalize_execution(execution_id, "completed")
        return WorkflowResult(
            workflow_name=workflow.name,
            steps=step_results,
            success=True,
        )

    def _finalize_execution(
        self,
        execution_id: str,
        status: str,
        error: str | None = None,
    ) -> None:
        now = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%fZ")
        self._db.execute(
            "UPDATE workflow_executions SET status = ?, error_message = ?, completed_at = ? "
            "WHERE id = ?",
            (status, error[:500] if error else None, now, execution_id),
        )
        self._db.commit()

    def _substitute_variables(
        self,
        arguments: dict[str, Any],
        step_results: list[WorkflowStepResult],
        context: dict[str, str],
    ) -> dict[str, Any]:
        """Replace ${...} placeholders in argument values."""
        resolved = {}
        for key, value in arguments.items():
            if isinstance(value, str):
                resolved[key] = self._resolve_string(value, step_results, context)
            elif isinstance(value, dict):
                resolved[key] = self._substitute_variables(value, step_results, context)
            else:
                resolved[key] = value
        return resolved

    def _resolve_string(
        self,
        text: str,
        step_results: list[WorkflowStepResult],
        context: dict[str, str],
    ) -> str:
        """Resolve all ${...} placeholders in a string."""
        def replacer(match: re.Match) -> str:
            var = match.group(1)

            if var == "prev_result" and step_results:
                return step_results[-1].output

            step_match = re.match(r"step_(\d+)_result", var)
            if step_match:
                idx = int(step_match.group(1))
                if 0 <= idx < len(step_results):
                    return step_results[idx].output
                return f"<step {idx} not available>"

            if var.startswith("context."):
                ctx_key = var[len("context."):]
                return context.get(ctx_key, f"<{ctx_key} not set>")

            return match.group(0)  # leave unresolved

        return re.sub(r"\$\{([^}]+)\}", replacer, text)

    @staticmethod
    def _check_condition(
        condition: str,
        prev_result: WorkflowStepResult,
    ) -> bool:
        """Evaluate a simple condition against the previous step result.

        Supported conditions:
        - "success"            — previous step succeeded
        - "failed"             — previous step failed
        - "contains:keyword"   — output contains keyword
        - "not_empty"          — output is not empty
        """
        condition = condition.strip().lower()

        if condition == "success":
            return prev_result.success
        if condition == "failed":
            return not prev_result.success
        if condition == "not_empty":
            return bool(prev_result.output.strip())
        if condition.startswith("contains:"):
            keyword = condition[len("contains:"):].strip()
            return keyword.lower() in prev_result.output.lower()

        log.warning("Unknown workflow condition: %s", condition)
        return True  # default to proceeding
