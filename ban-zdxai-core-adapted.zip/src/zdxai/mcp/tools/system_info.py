"""System information tools: CPU, RAM, disk, OS, battery."""

from __future__ import annotations

import os
import platform
import shutil

from zdxai.mcp.registry import ToolDefinition


def get_system_info() -> str:
    """Get comprehensive system information."""
    lines = [
        f"OS: {platform.system()} {platform.release()}",
        f"Platform: {platform.platform()}",
        f"Machine: {platform.machine()}",
        f"Processor: {platform.processor() or 'unknown'}",
        f"Python: {platform.python_version()}",
        f"CPU cores: {os.cpu_count() or 'unknown'}",
    ]

    # Memory info
    try:
        import psutil
        mem = psutil.virtual_memory()
        lines.append(f"RAM: {mem.total / (1024**3):.1f} GB total, "
                      f"{mem.available / (1024**3):.1f} GB available "
                      f"({mem.percent}% used)")

        # CPU usage
        cpu_pct = psutil.cpu_percent(interval=0.5)
        lines.append(f"CPU usage: {cpu_pct}%")

        # Battery
        battery = psutil.sensors_battery()
        if battery:
            plugged = "plugged in" if battery.power_plugged else "on battery"
            lines.append(f"Battery: {battery.percent}% ({plugged})")

    except ImportError:
        # Fallback: read /proc/meminfo on Linux
        try:
            with open("/proc/meminfo") as f:
                for line in f:
                    if line.startswith(("MemTotal:", "MemAvailable:")):
                        lines.append(line.strip())
        except OSError:
            lines.append("RAM: unavailable (install psutil for details)")

    # Disk
    try:
        usage = shutil.disk_usage("/")
        total_gb = usage.total / (1024**3)
        free_gb = usage.free / (1024**3)
        lines.append(f"Disk (/): {total_gb:.1f} GB total, {free_gb:.1f} GB free")
    except OSError:
        pass

    return "\n".join(lines)


def get_disk_usage(path: str = "/") -> str:
    """Get disk usage for a specific path."""
    try:
        usage = shutil.disk_usage(path)
        total = usage.total / (1024**3)
        used = usage.used / (1024**3)
        free = usage.free / (1024**3)
        pct = usage.used / usage.total * 100
        return (
            f"Disk usage for {path}:\n"
            f"  Total: {total:.1f} GB\n"
            f"  Used: {used:.1f} GB ({pct:.1f}%)\n"
            f"  Free: {free:.1f} GB"
        )
    except OSError as e:
        return f"Error getting disk usage for {path}: {e}"


TOOLS = [
    ToolDefinition(
        name="system.info",
        description="Get system information: OS, CPU, RAM, disk, battery",
        parameters={"type": "object", "properties": {}, "required": []},
        handler=lambda: get_system_info(),
        requires_permission=False,
    ),
    ToolDefinition(
        name="system.disk",
        description="Get disk usage for a specific path",
        parameters={
            "type": "object",
            "properties": {
                "path": {"type": "string", "description": "Path to check (default: /)"},
            },
            "required": [],
        },
        handler=lambda path="/": get_disk_usage(path),
        requires_permission=False,
    ),
]
