"""Memory tools — expose RAG search and ingestion as MCP tools."""

from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING

from zdxai.mcp.registry import ToolDefinition

if TYPE_CHECKING:
    from zdxai.core.engine import Engine


def create_memory_tools(engine: Engine) -> list[ToolDefinition]:
    """Create memory/RAG tool definitions with a bound engine reference."""

    def memory_search(query: str, top_k: int = 5) -> str:
        if engine.rag is None:
            return "RAG pipeline not initialized (embedding model not loaded)."

        results = engine.rag.retrieve(query, top_k=int(top_k))
        if not results:
            return "No relevant results found."

        lines = [f"Found {len(results)} relevant result(s):"]
        for i, r in enumerate(results, 1):
            score = round(r.score, 3)
            source = r.record.source_type
            preview = r.record.content_preview[:300]
            lines.append(f"  {i}. [{source}] (score={score}) {preview}")

        return "\n".join(lines)

    def memory_ingest(path: str) -> str:
        if engine.rag is None:
            return "RAG pipeline not initialized (embedding model not loaded)."

        file_path = Path(path).expanduser().resolve()
        if not file_path.exists():
            return f"File not found: {file_path}"
        if not file_path.is_file():
            return f"Not a file: {file_path}"

        try:
            doc_id, chunk_count = engine.ingest_document(file_path)
            return f"Ingested '{file_path.name}': {chunk_count} chunks (id={doc_id[:8]})"
        except ValueError as e:
            return f"Ingestion error: {e}"
        except Exception as e:
            return f"Failed to ingest: {e}"

    return [
        ToolDefinition(
            name="memory.search",
            description="Search RAG memory for relevant information from past conversations and ingested documents",
            parameters={
                "type": "object",
                "properties": {
                    "query": {
                        "type": "string",
                        "description": "Search query",
                    },
                    "top_k": {
                        "type": "integer",
                        "description": "Number of results to return (default: 5)",
                    },
                },
                "required": ["query"],
            },
            handler=lambda query, top_k=5: memory_search(query, top_k),
            requires_permission=False,
        ),
        ToolDefinition(
            name="memory.ingest",
            description="Ingest a file into RAG memory for future retrieval",
            parameters={
                "type": "object",
                "properties": {
                    "path": {
                        "type": "string",
                        "description": "Absolute path to the file to ingest",
                    },
                },
                "required": ["path"],
            },
            handler=lambda path: memory_ingest(path),
            requires_permission=True,
        ),
    ]
