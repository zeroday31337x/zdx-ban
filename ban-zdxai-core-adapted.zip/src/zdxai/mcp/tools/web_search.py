"""Internet search tool via DuckDuckGo or SearXNG."""

from __future__ import annotations

import json
import urllib.parse
import urllib.request

from zdxai.mcp.registry import ToolDefinition

# DuckDuckGo Instant Answer API (no API key required)
DDG_API = "https://api.duckduckgo.com/"

# DuckDuckGo HTML search (fallback, scraping lite results)
DDG_HTML = "https://html.duckduckgo.com/html/"


def web_search(query: str, num_results: int = 5) -> str:
    """Search the web using DuckDuckGo."""
    try:
        return _ddg_instant_answer(query, num_results)
    except Exception as e:
        return f"Search failed: {e}"


def _ddg_instant_answer(query: str, num_results: int) -> str:
    """Use DuckDuckGo Instant Answer API."""
    params = urllib.parse.urlencode({
        "q": query,
        "format": "json",
        "no_html": "1",
        "skip_disambig": "1",
    })
    url = f"{DDG_API}?{params}"

    req = urllib.request.Request(url, headers={"User-Agent": "zdxai/0.1"})
    with urllib.request.urlopen(req, timeout=10) as resp:
        data = json.loads(resp.read().decode())

    results = []

    # Abstract (direct answer)
    if data.get("Abstract"):
        results.append(
            f"**{data.get('Heading', 'Answer')}**\n"
            f"{data['Abstract']}\n"
            f"Source: {data.get('AbstractURL', '')}"
        )

    # Answer (computation/instant)
    if data.get("Answer"):
        results.append(f"Answer: {data['Answer']}")

    # Related topics
    for topic in data.get("RelatedTopics", [])[:num_results]:
        if isinstance(topic, dict) and "Text" in topic:
            text = topic["Text"]
            url = topic.get("FirstURL", "")
            results.append(f"- {text}\n  {url}")

    if not results:
        return f"No results found for: {query}"

    return f"Search results for '{query}':\n\n" + "\n\n".join(results)


TOOLS = [
    ToolDefinition(
        name="web.search",
        description="Search the internet using DuckDuckGo",
        parameters={
            "type": "object",
            "properties": {
                "query": {"type": "string", "description": "Search query"},
                "num_results": {"type": "integer", "description": "Max results (default: 5)"},
            },
            "required": ["query"],
        },
        handler=lambda query, num_results=5: web_search(query, int(num_results)),
    ),
]
