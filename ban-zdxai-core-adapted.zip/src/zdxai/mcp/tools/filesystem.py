"""Filesystem tools: read, write, list files with path validation."""

from __future__ import annotations

import os
from pathlib import Path

from zdxai.mcp.registry import ToolDefinition

# Paths that should never be accessed
FORBIDDEN_PATHS = {
    "/etc/shadow", "/etc/gshadow", "/etc/sudoers",
    "/root/.ssh", "/root/.gnupg",
}
FORBIDDEN_PREFIXES = (
    "/proc/", "/sys/", "/dev/",
)


def _validate_path(path_str: str) -> Path:
    """Validate and resolve a file path. Raises ValueError on forbidden paths."""
    path = Path(path_str).expanduser().resolve()
    path_s = str(path)

    for forbidden in FORBIDDEN_PATHS:
        if path_s == forbidden or path_s.startswith(forbidden + "/"):
            raise ValueError(f"Access denied: {path_s}")

    for prefix in FORBIDDEN_PREFIXES:
        if path_s.startswith(prefix):
            raise ValueError(f"Access denied: {path_s}")

    # Block access to .ssh directories
    if "/.ssh/" in path_s or path_s.endswith("/.ssh"):
        raise ValueError(f"Access denied: SSH directory")

    return path


def read_file(path: str, max_bytes: int = 100000) -> str:
    """Read a file's contents."""
    p = _validate_path(path)
    if not p.exists():
        return f"Error: File not found: {p}"
    if not p.is_file():
        return f"Error: Not a file: {p}"

    size = p.stat().st_size
    if size > max_bytes:
        content = p.read_text(encoding="utf-8", errors="replace")[:max_bytes]
        return f"{content}\n\n[Truncated: file is {size} bytes, showing first {max_bytes}]"

    return p.read_text(encoding="utf-8", errors="replace")


def write_file(path: str, content: str) -> str:
    """Write content to a file."""
    p = _validate_path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(content, encoding="utf-8")
    return f"Written {len(content)} bytes to {p}"


def list_directory(path: str = ".", show_hidden: bool = False) -> str:
    """List directory contents."""
    p = _validate_path(path)
    if not p.exists():
        return f"Error: Directory not found: {p}"
    if not p.is_dir():
        return f"Error: Not a directory: {p}"

    entries = []
    for item in sorted(p.iterdir()):
        if not show_hidden and item.name.startswith("."):
            continue
        kind = "dir" if item.is_dir() else "file"
        size = ""
        if item.is_file():
            s = item.stat().st_size
            if s < 1024:
                size = f" ({s}B)"
            elif s < 1024 * 1024:
                size = f" ({s / 1024:.1f}KB)"
            else:
                size = f" ({s / 1024 / 1024:.1f}MB)"
        entries.append(f"  [{kind}] {item.name}{size}")

    if not entries:
        return f"Directory is empty: {p}"

    return f"Contents of {p}:\n" + "\n".join(entries)


def search_files(path: str, pattern: str) -> str:
    """Search for files matching a glob pattern."""
    p = _validate_path(path)
    if not p.is_dir():
        return f"Error: Not a directory: {p}"

    matches = list(p.glob(pattern))[:50]  # Limit results
    if not matches:
        return f"No files matching '{pattern}' in {p}"

    lines = [f"Found {len(matches)} match(es) for '{pattern}' in {p}:"]
    for m in matches:
        rel = m.relative_to(p)
        lines.append(f"  {rel}")
    return "\n".join(lines)


# Tool definitions for registration
TOOLS = [
    ToolDefinition(
        name="filesystem.read",
        description="Read a file's contents",
        parameters={
            "type": "object",
            "properties": {
                "path": {"type": "string", "description": "File path to read"},
            },
            "required": ["path"],
        },
        handler=lambda path: read_file(path),
    ),
    ToolDefinition(
        name="filesystem.write",
        description="Write content to a file",
        parameters={
            "type": "object",
            "properties": {
                "path": {"type": "string", "description": "File path to write"},
                "content": {"type": "string", "description": "Content to write"},
            },
            "required": ["path", "content"],
        },
        handler=lambda path, content: write_file(path, content),
    ),
    ToolDefinition(
        name="filesystem.list",
        description="List files and directories",
        parameters={
            "type": "object",
            "properties": {
                "path": {"type": "string", "description": "Directory path (default: current)"},
                "show_hidden": {"type": "boolean", "description": "Show hidden files"},
            },
            "required": [],
        },
        handler=lambda path=".", show_hidden=False: list_directory(path, show_hidden),
    ),
    ToolDefinition(
        name="filesystem.search",
        description="Search for files matching a glob pattern",
        parameters={
            "type": "object",
            "properties": {
                "path": {"type": "string", "description": "Directory to search in"},
                "pattern": {"type": "string", "description": "Glob pattern (e.g. '*.py')"},
            },
            "required": ["path", "pattern"],
        },
        handler=lambda path, pattern: search_files(path, pattern),
    ),
]
