"""Fetch and parse web URLs."""

from __future__ import annotations

import html
import re
import urllib.request

from zdxai.mcp.registry import ToolDefinition

MAX_FETCH_SIZE = 500_000  # 500KB
FETCH_TIMEOUT = 15


def _html_to_text(html_content: str) -> str:
    """Simple HTML to text conversion (no external deps)."""
    # Remove script and style blocks
    text = re.sub(r"<script[^>]*>.*?</script>", "", html_content, flags=re.DOTALL | re.IGNORECASE)
    text = re.sub(r"<style[^>]*>.*?</style>", "", text, flags=re.DOTALL | re.IGNORECASE)

    # Replace common block elements with newlines
    for tag in ("br", "p", "div", "li", "tr", "h1", "h2", "h3", "h4", "h5", "h6"):
        text = re.sub(rf"</?{tag}[^>]*>", "\n", text, flags=re.IGNORECASE)

    # Remove all remaining HTML tags
    text = re.sub(r"<[^>]+>", "", text)

    # Decode HTML entities
    text = html.unescape(text)

    # Collapse multiple newlines/spaces
    text = re.sub(r"\n{3,}", "\n\n", text)
    text = re.sub(r"[ \t]+", " ", text)

    return text.strip()


def fetch_url(url: str, max_chars: int = 10000) -> str:
    """Fetch a URL and return its content as text."""
    if not url.startswith(("http://", "https://")):
        url = "https://" + url

    try:
        req = urllib.request.Request(
            url,
            headers={
                "User-Agent": "zdxai/0.1 (local AI assistant)",
                "Accept": "text/html,application/xhtml+xml,text/plain,application/json",
            },
        )
        with urllib.request.urlopen(req, timeout=FETCH_TIMEOUT) as resp:
            content_type = resp.headers.get("Content-Type", "")
            raw = resp.read(MAX_FETCH_SIZE)

        # Determine encoding
        charset = "utf-8"
        if "charset=" in content_type:
            charset = content_type.split("charset=")[-1].split(";")[0].strip()

        text = raw.decode(charset, errors="replace")

        # Convert HTML to text
        if "html" in content_type.lower():
            text = _html_to_text(text)

        # Truncate
        if len(text) > max_chars:
            text = text[:max_chars] + "\n\n[Content truncated]"

        return f"Content from {url}:\n\n{text}"

    except Exception as e:
        return f"Error fetching {url}: {e}"


TOOLS = [
    ToolDefinition(
        name="web.fetch",
        description="Fetch a URL and return its content as text",
        parameters={
            "type": "object",
            "properties": {
                "url": {"type": "string", "description": "URL to fetch"},
                "max_chars": {"type": "integer", "description": "Max characters to return (default: 10000)"},
            },
            "required": ["url"],
        },
        handler=lambda url, max_chars=10000: fetch_url(url, int(max_chars)),
    ),
]
