"""Workflow tools — expose the workflow engine as MCP tools."""

from __future__ import annotations

from typing import TYPE_CHECKING

from zdxai.mcp.registry import ToolDefinition

if TYPE_CHECKING:
    from zdxai.mcp.workflows import WorkflowEngine


def create_workflow_tools(workflow_engine: WorkflowEngine) -> list[ToolDefinition]:
    """Create workflow tool definitions with a bound engine reference."""

    def run_workflow(name: str, context: dict | None = None) -> str:
        workflow = workflow_engine.get_workflow(name)
        if not workflow:
            available = [w.name for w in workflow_engine.list_workflows()]
            return (
                f"Error: Unknown workflow '{name}'. "
                f"Available workflows: {', '.join(available) or 'none'}"
            )

        result = workflow_engine.execute(workflow, initial_context=context or {})

        lines = [f"Workflow '{result.workflow_name}': {'Completed' if result.success else 'Failed'}"]
        for sr in result.steps:
            status = "SKIP" if sr.skipped else ("OK" if sr.success else "FAIL")
            # Truncate long outputs
            output = sr.output[:500] if len(sr.output) > 500 else sr.output
            lines.append(f"  [{status}] {sr.tool_name}: {output}")

        if result.error:
            lines.append(f"  Error: {result.error}")

        return "\n".join(lines)

    def list_workflows() -> str:
        workflows = workflow_engine.list_workflows()
        if not workflows:
            return "No workflows registered."

        lines = ["Available workflows:"]
        for wf in workflows:
            lines.append(f"  {wf.name} — {wf.description} ({len(wf.steps)} steps)")
        return "\n".join(lines)

    return [
        ToolDefinition(
            name="workflow.run",
            description="Execute a named workflow (multi-step tool chain)",
            parameters={
                "type": "object",
                "properties": {
                    "name": {
                        "type": "string",
                        "description": "Name of the workflow to execute",
                    },
                    "context": {
                        "type": "object",
                        "description": "Initial context variables for the workflow",
                    },
                },
                "required": ["name"],
            },
            handler=lambda name, context=None: run_workflow(name, context),
            requires_permission=True,
        ),
        ToolDefinition(
            name="workflow.list",
            description="List all available workflows",
            parameters={
                "type": "object",
                "properties": {},
                "required": [],
            },
            handler=list_workflows,
            requires_permission=False,
        ),
    ]
