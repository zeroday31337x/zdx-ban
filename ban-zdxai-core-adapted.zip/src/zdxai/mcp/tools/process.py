"""Process management tools."""

from __future__ import annotations

import os
import signal

from zdxai.mcp.registry import ToolDefinition


def list_processes(filter_name: str = "") -> str:
    """List running processes, optionally filtered by name."""
    try:
        import psutil
    except ImportError:
        return "Error: psutil not installed. Install with: pip install 'zdxai[mcp]'"

    procs = []
    for proc in psutil.process_iter(["pid", "name", "cpu_percent", "memory_percent", "status"]):
        try:
            info = proc.info
            if filter_name and filter_name.lower() not in info["name"].lower():
                continue
            procs.append(info)
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            continue

    if not procs:
        return "No matching processes found."

    # Sort by CPU usage
    procs.sort(key=lambda p: p.get("cpu_percent", 0) or 0, reverse=True)

    lines = [f"{'PID':>7}  {'CPU%':>5}  {'MEM%':>5}  {'STATUS':<12}  NAME"]
    for p in procs[:30]:
        lines.append(
            f"{p['pid']:>7}  {p.get('cpu_percent', 0) or 0:>5.1f}  "
            f"{p.get('memory_percent', 0) or 0:>5.1f}  "
            f"{p.get('status', '?'):<12}  {p['name']}"
        )

    if len(procs) > 30:
        lines.append(f"  ... and {len(procs) - 30} more")

    return "\n".join(lines)


def kill_process(pid: int, sig: str = "TERM") -> str:
    """Send a signal to a process."""
    signal_map = {
        "TERM": signal.SIGTERM,
        "KILL": signal.SIGKILL,
        "INT": signal.SIGINT,
        "HUP": signal.SIGHUP,
    }

    sig_upper = sig.upper()
    if sig_upper not in signal_map:
        return f"Error: Unknown signal '{sig}'. Use: TERM, KILL, INT, HUP"

    try:
        os.kill(pid, signal_map[sig_upper])
        return f"Sent SIG{sig_upper} to process {pid}"
    except ProcessLookupError:
        return f"Error: Process {pid} not found"
    except PermissionError:
        return f"Error: Permission denied to signal process {pid}"


TOOLS = [
    ToolDefinition(
        name="process.list",
        description="List running processes with CPU/memory usage",
        parameters={
            "type": "object",
            "properties": {
                "filter_name": {"type": "string", "description": "Filter by process name"},
            },
            "required": [],
        },
        handler=lambda filter_name="": list_processes(filter_name),
        requires_permission=False,
    ),
    ToolDefinition(
        name="process.kill",
        description="Send a signal to a process (TERM, KILL, INT, HUP)",
        parameters={
            "type": "object",
            "properties": {
                "pid": {"type": "integer", "description": "Process ID"},
                "signal": {"type": "string", "description": "Signal to send (default: TERM)"},
            },
            "required": ["pid"],
        },
        handler=lambda pid, signal="TERM": kill_process(int(pid), signal),
    ),
]
