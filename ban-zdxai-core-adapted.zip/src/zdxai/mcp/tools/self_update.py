"""Self-update tool — check for and apply zdxai updates."""

from __future__ import annotations

import json
import logging
import subprocess
import sys
from urllib.request import Request, urlopen

from zdxai.constants import APP_VERSION
from zdxai.mcp.registry import ToolDefinition

log = logging.getLogger(__name__)


def check_for_updates(update_url: str = "") -> str:
    """Check if zdxai updates are available.

    Checks a configured URL first, then falls back to pip.
    """
    if update_url:
        return _check_url(update_url)
    return _check_pip()


def _check_pip() -> str:
    """Check pip for available updates."""
    try:
        result = subprocess.run(
            [sys.executable, "-m", "pip", "index", "versions", "zdxai"],
            capture_output=True, text=True, timeout=15,
        )
        if result.returncode == 0 and result.stdout.strip():
            lines = result.stdout.strip().splitlines()
            return f"Current: {APP_VERSION}. pip output: {lines[0]}"
        # pip index may not be available; try pip show
        result = subprocess.run(
            [sys.executable, "-m", "pip", "show", "zdxai"],
            capture_output=True, text=True, timeout=15,
        )
        if result.returncode == 0:
            for line in result.stdout.splitlines():
                if line.startswith("Version:"):
                    installed = line.split(":", 1)[1].strip()
                    return f"Installed version: {installed} (current: {APP_VERSION})"
        return f"zdxai version {APP_VERSION}. Could not check for newer versions via pip."
    except subprocess.TimeoutExpired:
        return f"Update check timed out. Current version: {APP_VERSION}"
    except Exception as e:
        return f"Update check failed: {e}. Current version: {APP_VERSION}"


def _check_url(update_url: str) -> str:
    """Check a configured URL for version info."""
    try:
        req = Request(
            update_url,
            headers={"User-Agent": f"zdxai/{APP_VERSION}"},
        )
        with urlopen(req, timeout=10) as resp:
            data = json.loads(resp.read().decode())

        latest = data.get("version", "unknown")
        if latest != APP_VERSION:
            changelog = data.get("changelog", "")
            msg = f"Update available: {latest} (current: {APP_VERSION})."
            if changelog:
                msg += f" Changes: {changelog[:200]}"
            return msg
        return f"zdxai is up to date (version {APP_VERSION})."
    except Exception as e:
        return f"Update check failed: {e}. Current version: {APP_VERSION}"


def apply_update() -> str:
    """Apply zdxai update via pip upgrade."""
    try:
        result = subprocess.run(
            [sys.executable, "-m", "pip", "install", "--upgrade", "zdxai"],
            capture_output=True, text=True, timeout=120,
        )
        if result.returncode == 0:
            output = result.stdout[-500:] if len(result.stdout) > 500 else result.stdout
            return f"Update applied successfully. Restart zdxai to use the new version.\n{output}"
        else:
            error = result.stderr[-500:] if len(result.stderr) > 500 else result.stderr
            return f"Update failed (exit code {result.returncode}):\n{error}"
    except subprocess.TimeoutExpired:
        return "Update timed out after 120 seconds."
    except Exception as e:
        return f"Update failed: {e}"


TOOLS = [
    ToolDefinition(
        name="self.update_check",
        description="Check if zdxai updates are available",
        parameters={
            "type": "object",
            "properties": {},
            "required": [],
        },
        handler=lambda: check_for_updates(),
        requires_permission=False,
    ),
    ToolDefinition(
        name="self.update_apply",
        description="Download and apply the latest zdxai update via pip",
        parameters={
            "type": "object",
            "properties": {},
            "required": [],
        },
        handler=lambda: apply_update(),
        requires_permission=True,
    ),
]
