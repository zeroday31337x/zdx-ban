"""Sandboxed shell command execution."""

from __future__ import annotations

import shlex
import subprocess

from zdxai.mcp.registry import ToolDefinition

# Commands that are never allowed
BLOCKED_COMMANDS = {
    "rm -rf /", "rm -rf /*", "dd", "mkfs", "fdisk",
    "shutdown", "reboot", "halt", "poweroff",
    "passwd", "useradd", "userdel", "usermod",
    "visudo", "chown -R /", "chmod -R 777 /",
}

# Command prefixes that are blocked
BLOCKED_PREFIXES = (
    "rm -rf /",
    "dd if=",
    "mkfs.",
    "> /dev/",
    "curl | sh",
    "curl | bash",
    "wget -O - | sh",
)

DEFAULT_TIMEOUT = 30  # seconds
MAX_TIMEOUT = 120
MAX_OUTPUT = 50000  # chars


def _is_blocked(command: str) -> str | None:
    """Check if a command is blocked. Returns reason if blocked, None if allowed."""
    cmd_lower = command.strip().lower()

    for blocked in BLOCKED_COMMANDS:
        if cmd_lower == blocked:
            return f"Blocked command: {blocked}"

    for prefix in BLOCKED_PREFIXES:
        if cmd_lower.startswith(prefix):
            return f"Blocked command pattern: {prefix}..."

    return None


def execute_command(command: str, timeout: int = DEFAULT_TIMEOUT, cwd: str | None = None) -> str:
    """Execute a shell command with sandboxing."""
    blocked = _is_blocked(command)
    if blocked:
        return f"Error: {blocked}"

    timeout = min(timeout, MAX_TIMEOUT)

    try:
        result = subprocess.run(
            command,
            shell=True,
            capture_output=True,
            text=True,
            timeout=timeout,
            cwd=cwd,
        )

        output_parts = []
        if result.stdout:
            stdout = result.stdout[:MAX_OUTPUT]
            if len(result.stdout) > MAX_OUTPUT:
                stdout += "\n[stdout truncated]"
            output_parts.append(stdout)
        if result.stderr:
            stderr = result.stderr[:MAX_OUTPUT]
            if len(result.stderr) > MAX_OUTPUT:
                stderr += "\n[stderr truncated]"
            output_parts.append(f"stderr:\n{stderr}")

        output = "\n".join(output_parts) if output_parts else "(no output)"

        if result.returncode != 0:
            output = f"Exit code: {result.returncode}\n{output}"

        return output

    except subprocess.TimeoutExpired:
        return f"Error: Command timed out after {timeout}s"
    except Exception as e:
        return f"Error executing command: {e}"


TOOLS = [
    ToolDefinition(
        name="shell.execute",
        description="Execute a shell command. Some dangerous commands are blocked.",
        parameters={
            "type": "object",
            "properties": {
                "command": {"type": "string", "description": "Shell command to execute"},
                "timeout": {"type": "integer", "description": "Timeout in seconds (max 120)"},
                "cwd": {"type": "string", "description": "Working directory"},
            },
            "required": ["command"],
        },
        handler=lambda command, timeout=DEFAULT_TIMEOUT, cwd=None: execute_command(
            command, int(timeout), cwd
        ),
    ),
]
