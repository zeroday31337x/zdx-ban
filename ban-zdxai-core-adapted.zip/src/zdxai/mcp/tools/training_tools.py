"""Training tools — expose adapter management as MCP tools."""

from __future__ import annotations

from typing import TYPE_CHECKING

from zdxai.mcp.registry import ToolDefinition

if TYPE_CHECKING:
    from zdxai.core.engine import Engine


def create_training_tools(engine: Engine) -> list[ToolDefinition]:
    """Create training/adapter tool definitions with a bound engine reference."""

    def list_adapters() -> str:
        if engine.adapter_manager is None:
            return "Adapter manager not initialized."

        adapters = engine.adapter_manager.list_adapters()
        if not adapters:
            return "No adapters found. Use /train to create one."

        lines = ["Available adapters:"]
        for a in adapters:
            size_mb = a.size_bytes / (1024 * 1024)
            active = " [ACTIVE]" if a.is_active else ""
            base = f" (base: {a.base_model})" if a.base_model else ""
            lines.append(f"  {a.name}{active} — {size_mb:.1f}MB{base}")
        return "\n".join(lines)

    def activate_adapter(name: str) -> str:
        if engine.adapter_manager is None:
            return "Adapter manager not initialized."

        try:
            engine.activate_adapter(name)
            return f"Adapter '{name}' activated. Model reloaded with adapter."
        except FileNotFoundError:
            return f"Adapter '{name}' not found."
        except Exception as e:
            return f"Failed to activate adapter: {e}"

    def deactivate_adapter() -> str:
        if engine.adapter_manager is None:
            return "Adapter manager not initialized."

        try:
            engine.deactivate_adapter()
            return "Adapter deactivated. Model reloaded without adapter."
        except Exception as e:
            return f"Failed to deactivate adapter: {e}"

    return [
        ToolDefinition(
            name="training.list_adapters",
            description="List available LoRA adapters",
            parameters={
                "type": "object",
                "properties": {},
                "required": [],
            },
            handler=list_adapters,
            requires_permission=False,
        ),
        ToolDefinition(
            name="training.activate_adapter",
            description="Activate a LoRA adapter for inference",
            parameters={
                "type": "object",
                "properties": {
                    "name": {
                        "type": "string",
                        "description": "Name of the adapter to activate",
                    },
                },
                "required": ["name"],
            },
            handler=lambda name: activate_adapter(name),
            requires_permission=True,
        ),
        ToolDefinition(
            name="training.deactivate_adapter",
            description="Deactivate the current LoRA adapter",
            parameters={
                "type": "object",
                "properties": {},
                "required": [],
            },
            handler=deactivate_adapter,
            requires_permission=True,
        ),
    ]
