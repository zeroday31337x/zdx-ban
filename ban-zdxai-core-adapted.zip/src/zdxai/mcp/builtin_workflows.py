"""Built-in workflow definitions for zdxai."""

from zdxai.mcp.workflows import WorkflowDefinition, WorkflowStep

BUILTIN_WORKFLOWS = [
    WorkflowDefinition(
        name="system_health_check",
        description="Run a comprehensive system health check (info, disk, top processes)",
        steps=[
            WorkflowStep(
                tool_name="system.info",
                arguments={},
                description="Gather system information",
            ),
            WorkflowStep(
                tool_name="system.disk",
                arguments={"path": "/"},
                description="Check root disk usage",
            ),
            WorkflowStep(
                tool_name="process.list",
                arguments={},
                description="List top processes by CPU usage",
            ),
        ],
    ),
    WorkflowDefinition(
        name="search_and_fetch",
        description="Search the web for a query and fetch the first result",
        steps=[
            WorkflowStep(
                tool_name="web.search",
                arguments={"query": "${context.query}"},
                description="Search the web",
            ),
            WorkflowStep(
                tool_name="web.fetch",
                arguments={"url": "${context.url}"},
                description="Fetch a URL from the search results",
                condition="success",
            ),
        ],
    ),
    WorkflowDefinition(
        name="project_overview",
        description="List files and read README in a directory",
        steps=[
            WorkflowStep(
                tool_name="filesystem.list",
                arguments={"path": "${context.path}"},
                description="List directory contents",
            ),
            WorkflowStep(
                tool_name="filesystem.search",
                arguments={
                    "path": "${context.path}",
                    "pattern": "README*",
                },
                description="Find README files",
                on_error="skip",
            ),
            WorkflowStep(
                tool_name="filesystem.read",
                arguments={"path": "${context.readme_path}"},
                description="Read the README",
                condition="success",
                on_error="skip",
            ),
        ],
    ),
]
