"""Deny-by-default permission system for MCP tools."""

from __future__ import annotations

import json
import logging
import uuid
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Callable

from zdxai.storage.database import Database

log = logging.getLogger(__name__)


@dataclass
class Permission:
    tool_name: str
    permission: str  # 'allow', 'deny', 'ask'
    scope: dict | None  # e.g. {"paths": ["/home/user/Documents"]}


class PermissionManager:
    """Deny-by-default permission system for MCP tools.

    Each tool has one of three permission states:
    - allow: tool can execute without user confirmation
    - deny: tool is blocked
    - ask: prompt user for confirmation before each invocation
    """

    def __init__(self, db: Database, prompt_fn: Callable[[str], bool] | None = None) -> None:
        self._db = db
        self._prompt_fn = prompt_fn or self._default_prompt

    @staticmethod
    def _default_prompt(message: str) -> bool:
        """Default CLI prompt for permission requests."""
        try:
            resp = input(f"\n[Permission] {message} (y/n): ").strip().lower()
            return resp in ("y", "yes")
        except (EOFError, KeyboardInterrupt):
            return False

    def get_permission(self, tool_name: str) -> Permission:
        """Get the permission for a tool. Default is 'ask'."""
        row = self._db.execute(
            "SELECT tool_name, permission, scope FROM tool_permissions WHERE tool_name = ?",
            (tool_name,),
        ).fetchone()

        if row is None:
            return Permission(tool_name=tool_name, permission="ask", scope=None)

        scope = json.loads(row["scope"]) if row["scope"] else None
        return Permission(
            tool_name=row["tool_name"],
            permission=row["permission"],
            scope=scope,
        )

    def set_permission(
        self,
        tool_name: str,
        permission: str,
        scope: dict | None = None,
        granted_by: str = "user",
    ) -> None:
        """Set or update a tool's permission."""
        now = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%fZ")
        scope_json = json.dumps(scope) if scope else None

        self._db.execute(
            "INSERT INTO tool_permissions (id, tool_name, permission, scope, granted_at, granted_by) "
            "VALUES (?, ?, ?, ?, ?, ?) "
            "ON CONFLICT(tool_name) DO UPDATE SET "
            "permission=excluded.permission, scope=excluded.scope, "
            "granted_at=excluded.granted_at, granted_by=excluded.granted_by",
            (uuid.uuid4().hex, tool_name, permission, scope_json, now, granted_by),
        )
        self._db.commit()

    def check_permission(
        self,
        tool_name: str,
        action_description: str,
        context: dict | None = None,
    ) -> bool:
        """Check if a tool is allowed to execute. May prompt the user.

        Args:
            tool_name: The tool identifier.
            action_description: Human-readable description of what the tool will do.
            context: Optional dict with tool-specific context for scope checking
                     (e.g. {"path": "/home/user/file"} or {"command": "ls -la"}).
        """
        perm = self.get_permission(tool_name)

        if perm.permission == "deny":
            log.info("Tool '%s' is denied.", tool_name)
            return False

        if perm.permission == "allow":
            # Enforce scope restrictions even for allowed tools
            if perm.scope and context:
                if not self._check_scope(perm.scope, context):
                    log.info("Tool '%s' denied by scope restriction.", tool_name)
                    return False
            return True

        # permission == "ask"
        granted = self._prompt_fn(
            f"Tool '{tool_name}' wants to: {action_description}. Allow?"
        )
        return granted

    @staticmethod
    def _check_scope(scope: dict, context: dict) -> bool:
        """Check if a tool invocation is within the allowed scope.

        Supported scope types:
        - {"paths": ["/home/user/Documents"]} — restrict filesystem access
        - {"commands": ["ls", "cat", "grep"]} — restrict shell commands
        """
        from pathlib import Path as _Path

        # Path scope
        if "paths" in scope and "path" in context:
            target = _Path(context["path"]).resolve()
            allowed = [_Path(p).resolve() for p in scope["paths"]]
            if not any(target == a or a in target.parents for a in allowed):
                return False

        # Command scope
        if "commands" in scope and "command" in context:
            cmd_str = context["command"].strip()
            cmd_first = cmd_str.split()[0] if cmd_str else ""
            if cmd_first not in scope["commands"]:
                return False

        return True

    def log_invocation(
        self,
        tool_name: str,
        action: str,
        input_summary: str = "",
        output_summary: str = "",
        conversation_id: str | None = None,
    ) -> None:
        """Log a tool invocation to the audit table."""
        now = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%fZ")
        self._db.execute(
            "INSERT INTO tool_audit_log "
            "(id, tool_name, action, input_summary, output_summary, conversation_id, created_at) "
            "VALUES (?, ?, ?, ?, ?, ?, ?)",
            (
                uuid.uuid4().hex, tool_name, action,
                input_summary[:500], output_summary[:500],
                conversation_id, now,
            ),
        )
        self._db.commit()

    def list_permissions(self) -> list[Permission]:
        """List all configured permissions."""
        rows = self._db.execute(
            "SELECT tool_name, permission, scope FROM tool_permissions"
        ).fetchall()
        return [
            Permission(
                tool_name=r["tool_name"],
                permission=r["permission"],
                scope=json.loads(r["scope"]) if r["scope"] else None,
            )
            for r in rows
        ]
