"""MCP server and tool call execution engine.

Handles parsing tool calls from model output, executing them through
the registry with permissions, and formatting results for re-inference.
"""

from __future__ import annotations

import json
import logging
import re
from dataclasses import dataclass
from typing import TYPE_CHECKING

from zdxai.mcp.permissions import PermissionManager
from zdxai.mcp.registry import ToolDefinition, ToolRegistry
from zdxai.storage.database import Database

# Import all static tool modules
from zdxai.mcp.tools import (
    filesystem, system_info, shell, process,
    web_search, web_fetch, self_update,
)

if TYPE_CHECKING:
    from zdxai.core.engine import Engine

log = logging.getLogger(__name__)

# Regex to match <tool_call>...</tool_call> blocks
TOOL_CALL_RE = re.compile(
    r"<tool_call>\s*(\{.*?\})\s*</tool_call>",
    re.DOTALL,
)


@dataclass
class ToolCallRequest:
    name: str
    arguments: dict


@dataclass
class ToolCallResult:
    name: str
    output: str
    success: bool


class MCPServer:
    """Tool execution server for zdxai.

    Parses tool calls from model output, checks permissions,
    executes tools, and returns results.
    """

    def __init__(
        self,
        db: Database,
        prompt_fn=None,
        engine: Engine | None = None,
    ) -> None:
        self.registry = ToolRegistry()
        self.permissions = PermissionManager(db, prompt_fn=prompt_fn)
        self._db = db
        self._engine = engine
        self.workflow_engine = None  # set after registration
        self._register_all_tools()

    def _register_all_tools(self) -> None:
        """Register all built-in and dynamic tools."""
        # Static tools (module-level TOOLS lists)
        static_modules = [
            filesystem, system_info, shell, process,
            web_search, web_fetch, self_update,
        ]
        for module in static_modules:
            for tool in getattr(module, "TOOLS", []):
                self.registry.register(tool)

        # Workflow engine + tools
        from zdxai.mcp.workflows import WorkflowEngine
        self.workflow_engine = WorkflowEngine(self, self._db)

        from zdxai.mcp.tools.workflow_tools import create_workflow_tools
        for tool in create_workflow_tools(self.workflow_engine):
            self.registry.register(tool)

        # Engine-dependent tools (memory, training)
        if self._engine is not None:
            from zdxai.mcp.tools.memory import create_memory_tools
            for tool in create_memory_tools(self._engine):
                self.registry.register(tool)

            from zdxai.mcp.tools.training_tools import create_training_tools
            for tool in create_training_tools(self._engine):
                self.registry.register(tool)

        # Register built-in workflows
        from zdxai.mcp.builtin_workflows import BUILTIN_WORKFLOWS
        for wf in BUILTIN_WORKFLOWS:
            self.workflow_engine.register_workflow(wf)

    def get_tools_prompt(self) -> str:
        """Get the tool definitions formatted for the system prompt."""
        return self.registry.format_tools_for_prompt()

    def parse_tool_calls(self, text: str) -> list[ToolCallRequest]:
        """Parse <tool_call> blocks from model output."""
        calls = []
        for match in TOOL_CALL_RE.finditer(text):
            try:
                data = json.loads(match.group(1))
                name = data.get("name", "")
                args = data.get("arguments", {})
                if name:
                    calls.append(ToolCallRequest(name=name, arguments=args))
            except (json.JSONDecodeError, AttributeError) as e:
                log.warning("Failed to parse tool call: %s", e)
        return calls

    def has_tool_calls(self, text: str) -> bool:
        """Check if text contains any tool call blocks."""
        return bool(TOOL_CALL_RE.search(text))

    def strip_tool_calls(self, text: str) -> str:
        """Remove tool call blocks from text, returning the non-tool content."""
        return TOOL_CALL_RE.sub("", text).strip()

    def _validate_arguments(
        self,
        tool: ToolDefinition,
        arguments: dict,
    ) -> tuple[bool, str, dict]:
        """Validate and coerce tool call arguments against the JSON Schema.

        Returns (is_valid, error_message, coerced_arguments).
        """
        schema = tool.parameters
        properties = schema.get("properties", {})
        required = schema.get("required", [])

        # Check required parameters
        for req_param in required:
            if req_param not in arguments:
                return False, f"Missing required parameter: '{req_param}'", {}

        # Type coercion and validation
        coerced = {}
        for param_name, param_value in arguments.items():
            if param_name not in properties:
                coerced[param_name] = param_value
                continue
            expected_type = properties[param_name].get("type", "string")
            try:
                coerced[param_name] = self._coerce_type(param_value, expected_type)
            except (ValueError, TypeError):
                return (
                    False,
                    f"Invalid type for '{param_name}': expected {expected_type}, "
                    f"got {type(param_value).__name__}",
                    {},
                )

        return True, "", coerced

    @staticmethod
    def _coerce_type(value, expected_type: str):
        """Coerce a value to the expected JSON Schema type."""
        if expected_type == "integer":
            return int(value)
        elif expected_type == "number":
            return float(value)
        elif expected_type == "boolean":
            if isinstance(value, str):
                return value.lower() in ("true", "1", "yes")
            return bool(value)
        elif expected_type == "string":
            return str(value)
        elif expected_type == "object":
            if isinstance(value, dict):
                return value
            if isinstance(value, str):
                return json.loads(value)
            raise TypeError(f"Cannot coerce {type(value).__name__} to object")
        return value

    def _extract_scope_context(self, tool_name: str, arguments: dict) -> dict | None:
        """Extract scope-checkable context from tool arguments."""
        if tool_name.startswith("filesystem."):
            path = arguments.get("path")
            if path:
                return {"path": path}
        elif tool_name == "shell.execute":
            command = arguments.get("command")
            if command:
                return {"command": command}
        elif tool_name == "web.fetch":
            url = arguments.get("url")
            if url:
                return {"url": url}
        return None

    def execute_tool(
        self,
        call: ToolCallRequest,
        conversation_id: str | None = None,
    ) -> ToolCallResult:
        """Execute a single tool call with permission checking."""
        tool = self.registry.get(call.name)
        if tool is None:
            return ToolCallResult(
                name=call.name,
                output=f"Error: Unknown tool '{call.name}'",
                success=False,
            )

        # Validate arguments
        is_valid, error_msg, coerced_args = self._validate_arguments(tool, call.arguments)
        if not is_valid:
            return ToolCallResult(
                name=call.name,
                output=f"Validation error for {call.name}: {error_msg}",
                success=False,
            )

        # Check permission (with scope context)
        if tool.requires_permission:
            action_desc = f"{call.name}({json.dumps(coerced_args, default=str)[:200]})"
            scope_context = self._extract_scope_context(call.name, coerced_args)
            if not self.permissions.check_permission(call.name, action_desc, context=scope_context):
                self.permissions.log_invocation(
                    call.name, "denied",
                    input_summary=json.dumps(coerced_args, default=str),
                    conversation_id=conversation_id,
                )
                return ToolCallResult(
                    name=call.name,
                    output=f"Permission denied for tool '{call.name}'.",
                    success=False,
                )

        # Execute with coerced arguments
        try:
            output = tool.handler(**coerced_args)
            self.permissions.log_invocation(
                call.name, "executed",
                input_summary=json.dumps(coerced_args, default=str),
                output_summary=str(output)[:500],
                conversation_id=conversation_id,
            )
            return ToolCallResult(name=call.name, output=str(output), success=True)
        except Exception as e:
            log.exception("Tool execution failed: %s", call.name)
            self.permissions.log_invocation(
                call.name, "error",
                input_summary=json.dumps(coerced_args, default=str),
                output_summary=str(e),
                conversation_id=conversation_id,
            )
            return ToolCallResult(
                name=call.name,
                output=f"Error executing {call.name}: {e}",
                success=False,
            )

    def execute_all(
        self,
        text: str,
        conversation_id: str | None = None,
    ) -> list[ToolCallResult]:
        """Parse and execute all tool calls in text."""
        calls = self.parse_tool_calls(text)
        return [self.execute_tool(c, conversation_id) for c in calls]

    def format_tool_results(self, results: list[ToolCallResult]) -> str:
        """Format tool results for injection back into the conversation."""
        parts = []
        for r in results:
            status = "Success" if r.success else "Failed"
            parts.append(
                f"<tool_result>\n"
                f"Tool: {r.name} ({status})\n"
                f"{r.output}\n"
                f"</tool_result>"
            )
        return "\n\n".join(parts)
