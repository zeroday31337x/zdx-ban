"""Tool registration and discovery for MCP."""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Any, Callable

log = logging.getLogger(__name__)


@dataclass
class ToolDefinition:
    """Definition of an MCP tool."""
    name: str
    description: str
    parameters: dict[str, Any]  # JSON Schema for parameters
    handler: Callable[..., str]  # Function that executes the tool
    requires_permission: bool = True


class ToolRegistry:
    """Registry for MCP tools."""

    def __init__(self) -> None:
        self._tools: dict[str, ToolDefinition] = {}

    def register(self, tool: ToolDefinition) -> None:
        """Register a tool."""
        self._tools[tool.name] = tool
        log.info("Registered tool: %s", tool.name)

    def get(self, name: str) -> ToolDefinition | None:
        return self._tools.get(name)

    def list_tools(self) -> list[ToolDefinition]:
        return list(self._tools.values())

    def tool_names(self) -> list[str]:
        return list(self._tools.keys())

    def get_tools_schema(self) -> list[dict]:
        """Return tool definitions in a format suitable for the system prompt."""
        schemas = []
        for tool in self._tools.values():
            schemas.append({
                "name": tool.name,
                "description": tool.description,
                "parameters": tool.parameters,
            })
        return schemas

    def format_tools_for_prompt(self) -> str:
        """Format tool definitions as text for injection into the system prompt."""
        if not self._tools:
            return ""

        lines = ["## Available Tools", ""]
        for tool in self._tools.values():
            lines.append(f"### {tool.name}")
            lines.append(tool.description)
            params = tool.parameters.get("properties", {})
            if params:
                lines.append("Parameters:")
                for pname, pdef in params.items():
                    ptype = pdef.get("type", "string")
                    pdesc = pdef.get("description", "")
                    required = pname in tool.parameters.get("required", [])
                    req_tag = " (required)" if required else ""
                    lines.append(f"  - {pname} ({ptype}{req_tag}): {pdesc}")
            lines.append("")

        lines.extend([
            "## How to Use Tools",
            "To use a tool, output a tool call block in this exact format:",
            "<tool_call>",
            '{"name": "tool_name", "arguments": {"param": "value"}}',
            "</tool_call>",
            "",
            "Wait for the tool result before continuing your response.",
            "",
        ])

        return "\n".join(lines)
