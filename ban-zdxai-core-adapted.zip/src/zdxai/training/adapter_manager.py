"""Adapter management — list, activate, deactivate, delete, register."""

from __future__ import annotations

import json
import logging
import uuid
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path

from zdxai.config import Config
from zdxai.storage.database import Database

log = logging.getLogger(__name__)


@dataclass
class AdapterInfo:
    """Information about a trained adapter."""
    name: str
    path: Path
    size_bytes: int
    created_at: str
    is_active: bool
    base_model: str | None = None
    training_config: dict | None = None


class AdapterManager:
    """Manage LoRA adapters — list, activate, deactivate, delete."""

    def __init__(self, config: Config, db: Database) -> None:
        self._config = config
        self._db = db

    def list_adapters(self) -> list[AdapterInfo]:
        """List all adapters found in the adapters directory."""
        adapters_dir = self._config.adapters_dir
        if not adapters_dir.exists():
            return []

        # Get active adapter from model_registry
        active_rows = self._db.execute(
            "SELECT name FROM model_registry WHERE model_type = 'adapter' AND is_active = 1"
        ).fetchall()
        active_names = {r["name"] for r in active_rows}

        adapters = []
        for entry in sorted(adapters_dir.iterdir()):
            if not entry.is_dir():
                continue

            # Check for adapter files (PEFT safetensors or GGUF)
            has_peft = (entry / "adapter_config.json").exists()
            has_gguf = any(entry.glob("*.gguf"))
            if not has_peft and not has_gguf:
                continue

            # Calculate total size
            size = sum(f.stat().st_size for f in entry.rglob("*") if f.is_file())

            # Read training config if available
            training_config = None
            base_model = None
            config_file = entry / "training_config.json"
            if config_file.exists():
                try:
                    with open(config_file) as f:
                        training_config = json.load(f)
                    base_model = training_config.get("hf_model_id")
                except (json.JSONDecodeError, OSError):
                    pass

            # Get creation time
            stat = entry.stat()
            created_at = datetime.fromtimestamp(
                stat.st_ctime, tz=timezone.utc
            ).strftime("%Y-%m-%dT%H:%M:%SZ")

            adapters.append(AdapterInfo(
                name=entry.name,
                path=entry,
                size_bytes=size,
                created_at=created_at,
                is_active=entry.name in active_names,
                base_model=base_model,
                training_config=training_config,
            ))

        return adapters

    def register_adapter(
        self,
        name: str,
        adapter_path: Path,
        base_model: str | None = None,
        training_config: dict | None = None,
    ) -> str:
        """Register a trained adapter in the model_registry table."""
        adapter_id = uuid.uuid4().hex
        size = sum(f.stat().st_size for f in adapter_path.rglob("*") if f.is_file())

        version_info = None
        if training_config:
            version_info = json.dumps({
                "epochs": training_config.get("num_epochs"),
                "lora_r": training_config.get("lora_r"),
                "final_loss": training_config.get("final_loss"),
            })

        self._db.execute(
            "INSERT INTO model_registry "
            "(id, name, file_path, model_type, quantization, size_bytes, version, is_active) "
            "VALUES (?, ?, ?, 'adapter', 'lora', ?, ?, 0)",
            (adapter_id, name, str(adapter_path), size, version_info),
        )
        self._db.commit()

        log.info("Registered adapter '%s' (id=%s)", name, adapter_id[:8])
        return adapter_id

    def activate_adapter(self, name: str) -> Path:
        """Set an adapter as active for inference."""
        adapter_path = self.get_adapter_path(name)
        if adapter_path is None:
            raise FileNotFoundError(f"Adapter '{name}' not found.")

        # Deactivate all adapters first
        self._db.execute(
            "UPDATE model_registry SET is_active = 0 WHERE model_type = 'adapter'"
        )

        # Activate this one
        self._db.execute(
            "UPDATE model_registry SET is_active = 1 WHERE name = ? AND model_type = 'adapter'",
            (name,),
        )
        self._db.commit()

        # Find the GGUF file if available, otherwise use the PEFT directory
        gguf_files = list(adapter_path.glob("*.gguf"))
        if gguf_files:
            self._config.adapter_path = str(gguf_files[0])
        else:
            self._config.adapter_path = str(adapter_path)

        log.info("Activated adapter '%s'", name)
        return adapter_path

    def deactivate_adapter(self) -> None:
        """Deactivate the current adapter."""
        self._db.execute(
            "UPDATE model_registry SET is_active = 0 WHERE model_type = 'adapter'"
        )
        self._db.commit()
        self._config.adapter_path = None
        log.info("All adapters deactivated.")

    def delete_adapter(self, name: str) -> None:
        """Remove adapter files and registry entry."""
        adapter_path = self.get_adapter_path(name)
        if adapter_path is None:
            raise FileNotFoundError(f"Adapter '{name}' not found.")

        # Remove from registry
        self._db.execute(
            "DELETE FROM model_registry WHERE name = ? AND model_type = 'adapter'",
            (name,),
        )
        self._db.commit()

        # Remove files
        import shutil
        if adapter_path.exists():
            shutil.rmtree(adapter_path)

        log.info("Deleted adapter '%s'", name)

    def get_adapter_path(self, name: str) -> Path | None:
        """Resolve adapter name to filesystem path."""
        adapter_path = self._config.adapters_dir / name
        if adapter_path.is_dir():
            return adapter_path
        return None

    def export_adapter_gguf(self, name: str) -> Path:
        """Convert a PEFT adapter to GGUF LoRA format.

        Returns the path to the generated GGUF file.
        """
        adapter_path = self.get_adapter_path(name)
        if adapter_path is None:
            raise FileNotFoundError(f"Adapter '{name}' not found.")

        output_path = adapter_path / f"{name}-lora.gguf"

        from zdxai.training.converter import convert_peft_to_gguf_lora

        # Read base model ID from training config
        base_model_id = None
        config_file = adapter_path / "training_config.json"
        if config_file.exists():
            with open(config_file) as f:
                tc = json.load(f)
            base_model_id = tc.get("hf_model_id")

        convert_peft_to_gguf_lora(adapter_path, output_path, base_model_id)
        log.info("Exported GGUF LoRA: %s", output_path)
        return output_path
