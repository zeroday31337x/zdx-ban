"""Dataset builder for training — extracts data from conversations and documents."""

from __future__ import annotations

import json
import logging
from dataclasses import dataclass
from pathlib import Path

from zdxai.config import Config
from zdxai.storage.conversations import ConversationStore
from zdxai.storage.database import Database
from zdxai.storage.documents import DocumentStore

log = logging.getLogger(__name__)


@dataclass
class TrainingExample:
    """A single training example in instruction/output format."""
    instruction: str
    input_text: str  # additional context (can be empty)
    output: str
    source_type: str  # 'conversation', 'document', or 'file'
    source_id: str


class DatasetBuilder:
    """Build training datasets from conversations, documents, or JSONL files."""

    def __init__(self, db: Database, config: Config) -> None:
        self._conversations = ConversationStore(db)
        self._documents = DocumentStore(db)
        self._config = config

    def from_conversations(
        self,
        conversation_ids: list[str] | None = None,
        min_turns: int = 2,
    ) -> list[TrainingExample]:
        """Convert conversation history to instruction/response training pairs.

        Each user message becomes the instruction and the following assistant
        message becomes the output. Tool messages are skipped.
        """
        examples: list[TrainingExample] = []

        if conversation_ids:
            convs = [
                self._conversations.get_conversation(cid)
                for cid in conversation_ids
            ]
            convs = [c for c in convs if c is not None]
        else:
            convs = self._conversations.list_conversations(limit=500)

        for conv in convs:
            if conv.message_count < min_turns:
                continue

            messages = self._conversations.get_messages(conv.id)
            # Filter to user/assistant pairs only
            filtered = [m for m in messages if m.role in ("user", "assistant")]

            i = 0
            while i < len(filtered) - 1:
                if filtered[i].role == "user" and filtered[i + 1].role == "assistant":
                    user_content = filtered[i].content.strip()
                    asst_content = filtered[i + 1].content.strip()
                    if user_content and asst_content:
                        examples.append(TrainingExample(
                            instruction=user_content,
                            input_text="",
                            output=asst_content,
                            source_type="conversation",
                            source_id=conv.id,
                        ))
                    i += 2
                else:
                    i += 1

        log.info("Extracted %d examples from %d conversations.", len(examples), len(convs))
        return examples

    def from_documents(
        self,
        document_ids: list[str] | None = None,
    ) -> list[TrainingExample]:
        """Convert document content to context-based training examples.

        Each document chunk becomes a context, with a generated instruction
        asking the model to summarize or answer based on the content.
        """
        examples: list[TrainingExample] = []

        if document_ids:
            docs = [self._documents.get(did) for did in document_ids]
            docs = [d for d in docs if d is not None]
        else:
            docs = self._documents.list_all(limit=500)

        for doc in docs:
            content = doc.content.strip()
            if not content:
                continue

            # Split into chunks for training
            chunks = self._chunk_content(content, max_chars=1024)
            for i, chunk in enumerate(chunks):
                if len(chunk) < 50:
                    continue
                examples.append(TrainingExample(
                    instruction="Based on the following text, provide a helpful and accurate summary.",
                    input_text=chunk,
                    output=self._generate_summary_target(chunk),
                    source_type="document",
                    source_id=doc.id,
                ))

        log.info("Extracted %d examples from %d documents.", len(examples), len(docs))
        return examples

    def from_jsonl(self, file_path: Path) -> list[TrainingExample]:
        """Load pre-formatted training examples from a JSONL file.

        Expected format per line:
            {"instruction": "...", "input": "...", "output": "..."}
        """
        examples: list[TrainingExample] = []
        path = Path(file_path)

        if not path.exists():
            raise FileNotFoundError(f"Training data file not found: {path}")

        with open(path) as f:
            for line_num, line in enumerate(f, 1):
                line = line.strip()
                if not line:
                    continue
                try:
                    data = json.loads(line)
                    examples.append(TrainingExample(
                        instruction=data.get("instruction", ""),
                        input_text=data.get("input", ""),
                        output=data.get("output", ""),
                        source_type="file",
                        source_id=str(path),
                    ))
                except json.JSONDecodeError as e:
                    log.warning("Skipping invalid JSON at line %d: %s", line_num, e)

        log.info("Loaded %d examples from %s.", len(examples), path.name)
        return examples

    def build_dataset(
        self,
        examples: list[TrainingExample],
        output_path: Path,
        format: str = "alpaca",
    ) -> Path:
        """Format examples and write to a JSONL file for training.

        Args:
            examples: List of training examples.
            output_path: Path to write the JSONL file.
            format: 'alpaca' or 'chatml'.

        Returns:
            Path to the written file.
        """
        if not examples:
            raise ValueError("No training examples to write.")

        formatter = self._format_alpaca if format == "alpaca" else self._format_chatml

        output_path.parent.mkdir(parents=True, exist_ok=True)
        with open(output_path, "w") as f:
            for example in examples:
                record = formatter(example)
                f.write(json.dumps(record, ensure_ascii=False) + "\n")

        log.info(
            "Wrote %d examples to %s (format=%s).",
            len(examples), output_path, format,
        )
        return output_path

    @staticmethod
    def _format_alpaca(example: TrainingExample) -> dict:
        """Format as Alpaca-style instruction tuning."""
        return {
            "instruction": example.instruction,
            "input": example.input_text,
            "output": example.output,
        }

    @staticmethod
    def _format_chatml(example: TrainingExample) -> dict:
        """Format as ChatML conversation."""
        messages = [{"role": "user", "content": example.instruction}]
        if example.input_text:
            messages[0]["content"] += f"\n\nContext:\n{example.input_text}"
        messages.append({"role": "assistant", "content": example.output})
        return {"messages": messages}

    @staticmethod
    def _chunk_content(content: str, max_chars: int = 1024) -> list[str]:
        """Split content into chunks at paragraph boundaries."""
        paragraphs = content.split("\n\n")
        chunks: list[str] = []
        current = ""

        for para in paragraphs:
            if len(current) + len(para) + 2 > max_chars and current:
                chunks.append(current.strip())
                current = para
            else:
                current = current + "\n\n" + para if current else para

        if current.strip():
            chunks.append(current.strip())

        return chunks

    @staticmethod
    def _generate_summary_target(chunk: str) -> str:
        """Generate a simple extractive summary target from a chunk.

        Uses the first and last sentences as a rough summary.
        A local LLM would produce better targets, but this works
        as a bootstrap without requiring inference.
        """
        sentences = []
        for sep in (".", "!", "?"):
            chunk = chunk.replace(sep, sep + "|||")
        parts = [s.strip() for s in chunk.split("|||") if s.strip()]

        if len(parts) <= 2:
            return " ".join(parts)

        # First sentence + last sentence
        return f"{parts[0]} {parts[-1]}"
