"""Convert PEFT LoRA adapters to GGUF LoRA format for llama-cpp-python."""

from __future__ import annotations

import json
import logging
from pathlib import Path

log = logging.getLogger(__name__)


def convert_peft_to_gguf_lora(
    peft_adapter_dir: Path,
    output_path: Path,
    base_model_id: str | None = None,
) -> Path:
    """Convert a PEFT LoRA adapter (safetensors) to GGUF LoRA format.

    This uses the gguf Python library (a dependency of llama-cpp-python)
    to write the LoRA tensors in GGUF format compatible with
    llama-cpp-python's lora_path parameter.

    Falls back to instructions for manual conversion if dependencies
    are missing or conversion fails.

    Args:
        peft_adapter_dir: Directory containing adapter_config.json and
                          adapter_model.safetensors.
        output_path: Path for the output .gguf file.
        base_model_id: Optional HuggingFace model ID for the base model.

    Returns:
        Path to the generated GGUF file.
    """
    adapter_config_path = peft_adapter_dir / "adapter_config.json"
    if not adapter_config_path.exists():
        raise FileNotFoundError(
            f"No adapter_config.json found in {peft_adapter_dir}. "
            "Is this a valid PEFT adapter directory?"
        )

    # Try to find the adapter weights file
    safetensors_path = peft_adapter_dir / "adapter_model.safetensors"
    bin_path = peft_adapter_dir / "adapter_model.bin"

    if not safetensors_path.exists() and not bin_path.exists():
        raise FileNotFoundError(
            f"No adapter weights found in {peft_adapter_dir}. "
            "Expected adapter_model.safetensors or adapter_model.bin."
        )

    try:
        return _convert_with_gguf_lib(
            peft_adapter_dir, output_path, adapter_config_path,
            safetensors_path if safetensors_path.exists() else bin_path,
            base_model_id,
        )
    except Exception as e:
        log.warning("Programmatic GGUF conversion failed: %s", e)
        log.info("Falling back to manual conversion instructions.")
        raise RuntimeError(
            f"Automatic GGUF conversion failed: {e}\n\n"
            "Manual conversion:\n"
            "1. Clone llama.cpp: git clone https://github.com/ggerganov/llama.cpp\n"
            "2. Run: python llama.cpp/convert_lora_to_gguf.py "
            f"  --base {base_model_id or '<base-model-id>'} "
            f"  --outfile {output_path} "
            f"  {peft_adapter_dir}\n"
        ) from e


def _convert_with_gguf_lib(
    adapter_dir: Path,
    output_path: Path,
    config_path: Path,
    weights_path: Path,
    base_model_id: str | None,
) -> Path:
    """Attempt conversion using the gguf Python library."""
    import numpy as np

    try:
        import gguf
    except ImportError:
        raise ImportError(
            "The 'gguf' library is required for GGUF conversion. "
            "It should be installed with llama-cpp-python. "
            "Install with: pip install gguf"
        )

    # Load adapter config
    with open(config_path) as f:
        adapter_config = json.load(f)

    lora_r = adapter_config.get("r", 8)
    lora_alpha = adapter_config.get("lora_alpha", 16)
    scaling = lora_alpha / lora_r

    # Load adapter weights
    if weights_path.suffix == ".safetensors":
        try:
            from safetensors import safe_open
            tensors = {}
            with safe_open(weights_path, framework="numpy") as f:
                for key in f.keys():
                    tensors[key] = f.get_tensor(key)
        except ImportError:
            raise ImportError(
                "The 'safetensors' library is required. "
                "Install with: pip install safetensors"
            )
    else:
        import torch
        state_dict = torch.load(weights_path, map_location="cpu", weights_only=True)
        tensors = {k: v.numpy() for k, v in state_dict.items()}

    # Create GGUF writer
    writer = gguf.GGUFWriter(str(output_path), arch="llama")

    # Add metadata
    writer.add_string("general.type", "adapter")
    writer.add_string("general.architecture", "llama")
    if base_model_id:
        writer.add_string("adapter.type", "lora")
        writer.add_float32("adapter.lora.alpha", float(lora_alpha))

    # Map PEFT tensor names to GGUF tensor names and add them
    for peft_name, tensor in tensors.items():
        gguf_name = _map_peft_to_gguf_name(peft_name)
        if gguf_name is None:
            log.debug("Skipping unmapped tensor: %s", peft_name)
            continue

        # Apply scaling to lora_B tensors
        if ".lora_B." in peft_name:
            tensor = tensor * scaling

        tensor = tensor.astype(np.float32)
        writer.add_tensor(gguf_name, tensor)

    writer.write_header_to_file()
    writer.write_kv_data_to_file()
    writer.write_tensors_to_file()
    writer.close()

    log.info("GGUF LoRA written to %s", output_path)
    return output_path


def _map_peft_to_gguf_name(peft_name: str) -> str | None:
    """Map a PEFT tensor name to the GGUF LoRA tensor name convention.

    PEFT names look like:
        base_model.model.model.layers.0.self_attn.q_proj.lora_A.weight
    GGUF LoRA names look like:
        blk.0.attn_q.weight.loraA
    """
    # Remove common PEFT prefixes
    name = peft_name
    for prefix in ("base_model.model.", "model."):
        if name.startswith(prefix):
            name = name[len(prefix):]

    # Detect LoRA component
    if ".lora_A." in name:
        lora_suffix = ".loraA"
    elif ".lora_B." in name:
        lora_suffix = ".loraB"
    else:
        return None

    # Remove lora_A/B.weight
    name = name.replace(".lora_A.weight", "").replace(".lora_B.weight", "")
    name = name.replace(".lora_A.default.weight", "").replace(".lora_B.default.weight", "")

    # Map module paths
    # model.layers.N.self_attn.q_proj -> blk.N.attn_q.weight
    LAYER_MAPPINGS = {
        "self_attn.q_proj": "attn_q",
        "self_attn.k_proj": "attn_k",
        "self_attn.v_proj": "attn_v",
        "self_attn.o_proj": "attn_output",
        "mlp.gate_proj": "ffn_gate",
        "mlp.up_proj": "ffn_up",
        "mlp.down_proj": "ffn_down",
    }

    # Try to extract layer number and module
    import re
    layer_match = re.match(r"model\.layers\.(\d+)\.(.+)", name)
    if layer_match:
        layer_num = layer_match.group(1)
        module_path = layer_match.group(2)
        gguf_module = LAYER_MAPPINGS.get(module_path)
        if gguf_module:
            return f"blk.{layer_num}.{gguf_module}.weight{lora_suffix}"

    log.debug("Could not map PEFT name to GGUF: %s", peft_name)
    return None
