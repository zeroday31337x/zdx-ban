"""LoRA fine-tuning trainer using PEFT and transformers."""

from __future__ import annotations

import json
import logging
import time
from collections.abc import Callable
from dataclasses import dataclass, field
from pathlib import Path

from zdxai.config import Config
from zdxai.constants import (
    TRAINING_DEFAULT_BATCH_SIZE,
    TRAINING_DEFAULT_EPOCHS,
    TRAINING_DEFAULT_GRAD_ACCUM,
    TRAINING_DEFAULT_LORA_ALPHA,
    TRAINING_DEFAULT_LORA_DROPOUT,
    TRAINING_DEFAULT_LORA_R,
    TRAINING_DEFAULT_LR,
    TRAINING_DEFAULT_MAX_SEQ_LEN,
    TRAINING_DEFAULT_SAVE_STEPS,
    TRAINING_DEFAULT_WARMUP_STEPS,
)

log = logging.getLogger(__name__)


@dataclass
class TrainingConfig:
    """Training hyperparameters."""
    hf_model_id: str
    adapter_name: str
    lora_r: int = TRAINING_DEFAULT_LORA_R
    lora_alpha: int = TRAINING_DEFAULT_LORA_ALPHA
    lora_dropout: float = TRAINING_DEFAULT_LORA_DROPOUT
    target_modules: list[str] = field(default_factory=lambda: ["q_proj", "v_proj"])
    learning_rate: float = TRAINING_DEFAULT_LR
    num_epochs: int = TRAINING_DEFAULT_EPOCHS
    batch_size: int = TRAINING_DEFAULT_BATCH_SIZE
    gradient_accumulation_steps: int = TRAINING_DEFAULT_GRAD_ACCUM
    max_seq_length: int = TRAINING_DEFAULT_MAX_SEQ_LEN
    warmup_steps: int = TRAINING_DEFAULT_WARMUP_STEPS
    save_steps: int = TRAINING_DEFAULT_SAVE_STEPS
    fp16: bool = False
    device: str = ""  # auto-detect if empty


@dataclass
class TrainingProgress:
    """Progress report from the training loop."""
    epoch: int
    total_epochs: int
    step: int
    total_steps: int
    loss: float
    learning_rate: float
    elapsed_seconds: float


class LoRATrainer:
    """LoRA fine-tuning using PEFT and transformers.

    Produces a PEFT adapter in safetensors format that can be
    converted to GGUF LoRA for use with llama-cpp-python.
    """

    def __init__(
        self,
        training_config: TrainingConfig,
        app_config: Config,
        progress_callback: Callable[[TrainingProgress], None] | None = None,
    ) -> None:
        self._tcfg = training_config
        self._app_config = app_config
        self._progress_callback = progress_callback
        self._device = training_config.device or self._detect_device()

    @staticmethod
    def _detect_device() -> str:
        """Detect the best available device."""
        try:
            import torch
            if torch.cuda.is_available():
                return "cuda"
            if hasattr(torch.backends, "mps") and torch.backends.mps.is_available():
                return "mps"
        except ImportError:
            pass
        return "cpu"

    def _check_dependencies(self) -> None:
        """Verify training dependencies are installed."""
        missing = []
        for pkg in ("torch", "transformers", "peft"):
            try:
                __import__(pkg)
            except ImportError:
                missing.append(pkg)
        if missing:
            raise ImportError(
                f"Training requires: {', '.join(missing)}. "
                f"Install with: pip install 'zdxai[training]'"
            )

    def train(self, dataset_path: Path) -> Path:
        """Run LoRA training and return the path to the saved adapter.

        Args:
            dataset_path: Path to a JSONL training file (alpaca format).

        Returns:
            Path to the saved adapter directory.
        """
        self._check_dependencies()

        import torch
        from transformers import AutoModelForCausalLM, AutoTokenizer
        from peft import LoraConfig, get_peft_model, TaskType

        adapter_dir = self._app_config.adapters_dir / self._tcfg.adapter_name
        adapter_dir.mkdir(parents=True, exist_ok=True)

        log.info("Loading base model: %s", self._tcfg.hf_model_id)
        log.info("Device: %s", self._device)

        # Load tokenizer
        tokenizer = AutoTokenizer.from_pretrained(
            self._tcfg.hf_model_id,
            trust_remote_code=False,
        )
        if tokenizer.pad_token is None:
            tokenizer.pad_token = tokenizer.eos_token

        # Load model
        model_kwargs = {"torch_dtype": torch.float32}
        if self._device == "cuda":
            model_kwargs["torch_dtype"] = torch.float16
            self._tcfg.fp16 = True

        model = AutoModelForCausalLM.from_pretrained(
            self._tcfg.hf_model_id,
            trust_remote_code=False,
            **model_kwargs,
        )
        model.to(self._device)

        # Apply LoRA
        lora_config = LoraConfig(
            task_type=TaskType.CAUSAL_LM,
            r=self._tcfg.lora_r,
            lora_alpha=self._tcfg.lora_alpha,
            lora_dropout=self._tcfg.lora_dropout,
            target_modules=self._tcfg.target_modules,
        )
        model = get_peft_model(model, lora_config)

        trainable, total = model.get_nb_trainable_parameters()
        log.info(
            "Trainable parameters: %s / %s (%.2f%%)",
            f"{trainable:,}", f"{total:,}", 100 * trainable / total,
        )

        # Load and tokenize dataset
        dataset = self._load_dataset(dataset_path, tokenizer)
        if not dataset:
            raise ValueError("Dataset is empty after tokenization.")

        dataloader = torch.utils.data.DataLoader(
            dataset,
            batch_size=self._tcfg.batch_size,
            shuffle=True,
        )

        total_steps = (
            len(dataloader) * self._tcfg.num_epochs
            // self._tcfg.gradient_accumulation_steps
        )

        # Optimizer and scheduler
        optimizer = torch.optim.AdamW(
            model.parameters(),
            lr=self._tcfg.learning_rate,
            weight_decay=0.01,
        )

        warmup_steps = min(self._tcfg.warmup_steps, total_steps // 4)
        scheduler = torch.optim.lr_scheduler.LinearLR(
            optimizer,
            start_factor=0.1,
            end_factor=1.0,
            total_iters=warmup_steps,
        )

        # Training loop
        log.info("Starting training: %d epochs, %d steps", self._tcfg.num_epochs, total_steps)
        model.train()
        global_step = 0
        start_time = time.monotonic()

        for epoch in range(self._tcfg.num_epochs):
            epoch_loss = 0.0
            optimizer.zero_grad()

            for batch_idx, batch in enumerate(dataloader):
                input_ids = batch["input_ids"].to(self._device)
                attention_mask = batch["attention_mask"].to(self._device)
                labels = batch["labels"].to(self._device)

                outputs = model(
                    input_ids=input_ids,
                    attention_mask=attention_mask,
                    labels=labels,
                )
                loss = outputs.loss / self._tcfg.gradient_accumulation_steps
                loss.backward()

                epoch_loss += loss.item() * self._tcfg.gradient_accumulation_steps

                if (batch_idx + 1) % self._tcfg.gradient_accumulation_steps == 0:
                    torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
                    optimizer.step()
                    scheduler.step()
                    optimizer.zero_grad()
                    global_step += 1

                    # Progress callback
                    if self._progress_callback:
                        self._progress_callback(TrainingProgress(
                            epoch=epoch + 1,
                            total_epochs=self._tcfg.num_epochs,
                            step=global_step,
                            total_steps=total_steps,
                            loss=loss.item() * self._tcfg.gradient_accumulation_steps,
                            learning_rate=scheduler.get_last_lr()[0],
                            elapsed_seconds=time.monotonic() - start_time,
                        ))

                    # Periodic save
                    if self._tcfg.save_steps and global_step % self._tcfg.save_steps == 0:
                        checkpoint_dir = adapter_dir / f"checkpoint-{global_step}"
                        model.save_pretrained(checkpoint_dir)
                        log.info("Checkpoint saved at step %d", global_step)

            avg_loss = epoch_loss / max(len(dataloader), 1)
            log.info("Epoch %d/%d — avg loss: %.4f", epoch + 1, self._tcfg.num_epochs, avg_loss)

        # Save final adapter
        model.save_pretrained(adapter_dir)
        tokenizer.save_pretrained(adapter_dir)

        # Save training config for reference
        config_path = adapter_dir / "training_config.json"
        with open(config_path, "w") as f:
            json.dump({
                "hf_model_id": self._tcfg.hf_model_id,
                "adapter_name": self._tcfg.adapter_name,
                "lora_r": self._tcfg.lora_r,
                "lora_alpha": self._tcfg.lora_alpha,
                "lora_dropout": self._tcfg.lora_dropout,
                "target_modules": self._tcfg.target_modules,
                "learning_rate": self._tcfg.learning_rate,
                "num_epochs": self._tcfg.num_epochs,
                "batch_size": self._tcfg.batch_size,
                "max_seq_length": self._tcfg.max_seq_length,
                "device": self._device,
                "total_steps": total_steps,
                "final_loss": avg_loss,
            }, f, indent=2)

        elapsed = time.monotonic() - start_time
        log.info(
            "Training complete. Adapter saved to %s (%.1f seconds)",
            adapter_dir, elapsed,
        )
        return adapter_dir

    def _load_dataset(self, dataset_path: Path, tokenizer) -> list[dict]:
        """Load a JSONL dataset and tokenize for causal LM training."""
        import torch

        samples = []
        with open(dataset_path) as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                data = json.loads(line)

                # Build prompt text from alpaca or chatml format
                if "messages" in data:
                    # ChatML format
                    text = ""
                    for msg in data["messages"]:
                        role = msg["role"]
                        content = msg["content"]
                        text += f"<|{role}|>\n{content}\n"
                    text += "<|end|>"
                else:
                    # Alpaca format
                    instruction = data.get("instruction", "")
                    input_text = data.get("input", "")
                    output = data.get("output", "")
                    if input_text:
                        text = (
                            f"### Instruction:\n{instruction}\n\n"
                            f"### Input:\n{input_text}\n\n"
                            f"### Response:\n{output}"
                        )
                    else:
                        text = (
                            f"### Instruction:\n{instruction}\n\n"
                            f"### Response:\n{output}"
                        )

                # Tokenize
                encoded = tokenizer(
                    text,
                    truncation=True,
                    max_length=self._tcfg.max_seq_length,
                    padding="max_length",
                    return_tensors="pt",
                )

                input_ids = encoded["input_ids"].squeeze(0)
                attention_mask = encoded["attention_mask"].squeeze(0)
                # Labels = input_ids (causal LM), with padding tokens set to -100
                labels = input_ids.clone()
                labels[attention_mask == 0] = -100

                samples.append({
                    "input_ids": input_ids,
                    "attention_mask": attention_mask,
                    "labels": labels,
                })

        log.info("Tokenized %d samples (max_seq_length=%d)", len(samples), self._tcfg.max_seq_length)
        return samples
