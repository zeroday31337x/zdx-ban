"""zdxai setup scripts."""
