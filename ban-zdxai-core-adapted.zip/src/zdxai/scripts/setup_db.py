#!/usr/bin/env python3
"""Initialize the zdxai database with schema migrations.

Usage:
    python -m zdxai.scripts.setup_db [--base-dir DIR]
"""

from __future__ import annotations

import argparse
import logging
from pathlib import Path

logging.basicConfig(level=logging.INFO, format="%(message)s")


def main() -> None:
    parser = argparse.ArgumentParser(description="Initialize zdxai database")
    parser.add_argument("--base-dir", type=Path, default=None)
    args = parser.parse_args()

    try:
        from zdxai.platform.paths import get_base_dir
        base = args.base_dir or get_base_dir()
    except ImportError:
        base = args.base_dir or Path.home() / ".zdxai"

    from zdxai.storage.database import Database

    db_path = base / "data" / "zdxai.db"
    db_path.parent.mkdir(parents=True, exist_ok=True)

    db = Database(db_path)
    db.open()
    db.migrate()
    db.close()

    print(f"Database initialized at: {db_path}")


if __name__ == "__main__":
    main()
