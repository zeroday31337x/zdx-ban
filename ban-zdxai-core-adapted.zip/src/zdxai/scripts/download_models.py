#!/usr/bin/env python3
"""Download required GGUF models from HuggingFace.

Usage:
    python -m zdxai.scripts.download_models [--base-dir DIR] [--all | --model NAME]
"""

from __future__ import annotations

import argparse
import hashlib
import sys
import urllib.request
from pathlib import Path

# Import from package if available, otherwise define locally
try:
    from zdxai.constants import MODEL_URLS, MODEL_SMOLLM2, MODEL_EMBEDDING
    from zdxai.platform.paths import get_base_dir
except ImportError:
    MODEL_SMOLLM2 = "smollm2-1.7b-q4_k_m.gguf"
    MODEL_TINYLLAMA = "tinyllama-1.1b-q4_k_m.gguf"
    MODEL_EMBEDDING = "all-minilm-l6-v2.gguf"
    MODEL_URLS = {
        MODEL_SMOLLM2: "https://huggingface.co/bartowski/SmolLM2-1.7B-Instruct-GGUF/resolve/main/SmolLM2-1.7B-Instruct-Q4_K_M.gguf",
        MODEL_TINYLLAMA: "https://huggingface.co/TheBloke/TinyLlama-1.1B-Chat-v1.0-GGUF/resolve/main/tinyllama-1.1b-chat-v1.0.Q4_K_M.gguf",
        MODEL_EMBEDDING: "https://huggingface.co/leliuga/all-MiniLM-L6-v2-GGUF/resolve/main/all-MiniLM-L6-v2.F16.gguf",
    }

    def get_base_dir():
        return Path.home() / ".zdxai"


# Default models to download (primary + embedding)
DEFAULT_MODELS = [MODEL_SMOLLM2, MODEL_EMBEDDING]


def download_file(url: str, dest: Path) -> None:
    """Download a file with progress reporting."""
    if dest.exists():
        print(f"  Already exists: {dest.name} ({dest.stat().st_size / 1e6:.1f} MB)")
        return

    print(f"  Downloading: {url}")
    print(f"  Destination: {dest}")

    dest.parent.mkdir(parents=True, exist_ok=True)
    tmp = dest.with_suffix(".tmp")

    try:
        req = urllib.request.Request(url, headers={"User-Agent": "zdxai/0.1"})
        with urllib.request.urlopen(req) as resp:
            total = int(resp.headers.get("Content-Length", 0))
            downloaded = 0
            chunk_size = 1024 * 1024  # 1 MB

            with open(tmp, "wb") as f:
                while True:
                    chunk = resp.read(chunk_size)
                    if not chunk:
                        break
                    f.write(chunk)
                    downloaded += len(chunk)
                    if total > 0:
                        pct = downloaded / total * 100
                        mb = downloaded / 1e6
                        total_mb = total / 1e6
                        print(
                            f"\r  Progress: {mb:.1f}/{total_mb:.1f} MB ({pct:.0f}%)",
                            end="", flush=True,
                        )
            print()  # newline after progress

        tmp.rename(dest)
        size_mb = dest.stat().st_size / 1e6
        print(f"  Done: {dest.name} ({size_mb:.1f} MB)")

    except Exception:
        if tmp.exists():
            tmp.unlink()
        raise


def main() -> None:
    parser = argparse.ArgumentParser(description="Download zdxai models")
    parser.add_argument(
        "--base-dir", type=Path, default=None,
        help="Override base directory",
    )
    parser.add_argument(
        "--all", action="store_true",
        help="Download all models (including TinyLlama fallback)",
    )
    parser.add_argument(
        "--model", type=str, default=None,
        help="Download a specific model by filename",
    )
    args = parser.parse_args()

    base_dir = args.base_dir or get_base_dir()
    models_dir = base_dir / "models"
    models_dir.mkdir(parents=True, exist_ok=True)

    if args.model:
        if args.model not in MODEL_URLS:
            print(f"Unknown model: {args.model}")
            print(f"Available: {', '.join(MODEL_URLS.keys())}")
            sys.exit(1)
        targets = [args.model]
    elif args.all:
        targets = list(MODEL_URLS.keys())
    else:
        targets = DEFAULT_MODELS

    print(f"Models directory: {models_dir}")
    print(f"Models to download: {len(targets)}\n")

    for name in targets:
        url = MODEL_URLS[name]
        dest = models_dir / name
        print(f"[{name}]")
        try:
            download_file(url, dest)
        except Exception as e:
            print(f"  FAILED: {e}")
            sys.exit(1)
        print()

    print("All downloads complete.")


if __name__ == "__main__":
    main()
