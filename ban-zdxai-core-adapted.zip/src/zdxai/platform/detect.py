"""Platform detection utilities."""

from __future__ import annotations

import os
import platform
import sys
from enum import Enum


class Platform(Enum):
    LINUX = "linux"
    MACOS = "macos"
    WINDOWS = "windows"
    TERMUX = "termux"
    UNKNOWN = "unknown"


def detect_platform() -> Platform:
    """Detect the current platform."""
    system = platform.system().lower()

    if system == "linux":
        # Check for Termux
        if "TERMUX_VERSION" in os.environ or "/data/data/com.termux" in sys.prefix:
            return Platform.TERMUX
        return Platform.LINUX
    elif system == "darwin":
        return Platform.MACOS
    elif system == "windows":
        return Platform.WINDOWS
    return Platform.UNKNOWN


def get_total_ram_bytes() -> int | None:
    """Get total system RAM in bytes."""
    try:
        import psutil
        return psutil.virtual_memory().total
    except ImportError:
        pass

    try:
        with open("/proc/meminfo") as f:
            for line in f:
                if line.startswith("MemTotal:"):
                    return int(line.split()[1]) * 1024
    except (OSError, ValueError):
        pass

    return None


def get_cpu_count() -> int:
    """Get number of CPU cores."""
    return os.cpu_count() or 1
