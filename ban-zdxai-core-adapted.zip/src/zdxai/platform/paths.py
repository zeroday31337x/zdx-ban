"""Platform-aware directory resolution."""

from __future__ import annotations

import os
from pathlib import Path

from zdxai.platform.detect import Platform, detect_platform


def get_base_dir(platform: Platform | None = None) -> Path:
    """Return the base directory for zdxai data, respecting XDG and platform conventions."""
    if platform is None:
        platform = detect_platform()

    # Environment override always wins
    env_dir = os.environ.get("ZDXAI_HOME")
    if env_dir:
        return Path(env_dir)

    home = Path.home()

    if platform == Platform.TERMUX:
        return home / ".zdxai"
    elif platform == Platform.MACOS:
        return home / "Library" / "Application Support" / "zdxai"
    elif platform == Platform.WINDOWS:
        local = os.environ.get("LOCALAPPDATA", str(home / "AppData" / "Local"))
        return Path(local) / "zdxai"
    else:
        # Linux: respect XDG_DATA_HOME
        xdg = os.environ.get("XDG_DATA_HOME", str(home / ".local" / "share"))
        return Path(xdg) / "zdxai"


def get_config_dir(platform: Platform | None = None) -> Path:
    """Return the config directory for zdxai."""
    if platform is None:
        platform = detect_platform()

    env_dir = os.environ.get("ZDXAI_CONFIG")
    if env_dir:
        return Path(env_dir)

    home = Path.home()

    if platform in (Platform.TERMUX, Platform.LINUX):
        xdg = os.environ.get("XDG_CONFIG_HOME", str(home / ".config"))
        return Path(xdg) / "zdxai"
    elif platform == Platform.MACOS:
        return home / "Library" / "Preferences" / "zdxai"
    elif platform == Platform.WINDOWS:
        local = os.environ.get("LOCALAPPDATA", str(home / "AppData" / "Local"))
        return Path(local) / "zdxai" / "config"
    return home / ".zdxai" / "config"
