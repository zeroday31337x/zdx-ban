"""Token budget management for fitting content into the context window."""

from __future__ import annotations

from zdxai.config import Config
from zdxai.memory.document_loader import CHARS_PER_TOKEN


def estimate_message_tokens(messages: list[dict[str, str]]) -> int:
    """Estimate total tokens for a list of chat messages."""
    total = 0
    for msg in messages:
        # Overhead per message (role tag, delimiters)
        total += 4
        total += len(msg.get("content", "")) // CHARS_PER_TOKEN
    # Priming overhead
    total += 3
    return total


class ContextBudget:
    """Manages token budget allocation across system prompt, RAG context, history, and user input."""

    def __init__(self, config: Config) -> None:
        self._max_tokens = config.context_length
        self._reserve_completion = config.max_tokens

    @property
    def available_tokens(self) -> int:
        """Total tokens available for the prompt (context_length minus reserved completion tokens)."""
        return self._max_tokens - self._reserve_completion

    def compute_budget(
        self,
        system_tokens: int,
        user_input_tokens: int,
    ) -> tuple[int, int]:
        """Compute how many tokens are available for RAG context and history.

        Returns: (rag_budget, history_budget)
        """
        remaining = self.available_tokens - system_tokens - user_input_tokens
        if remaining <= 0:
            return 0, 0

        # Allocate: 30% for RAG context, 70% for conversation history
        rag_budget = int(remaining * 0.3)
        history_budget = remaining - rag_budget
        return rag_budget, history_budget

    def trim_history(
        self,
        messages: list[dict[str, str]],
        budget_tokens: int,
    ) -> list[dict[str, str]]:
        """Trim history messages from the front to fit within budget.

        Always keeps the most recent messages.
        """
        if not messages:
            return []

        total = estimate_message_tokens(messages)
        if total <= budget_tokens:
            return messages

        # Remove oldest messages until we fit
        trimmed = list(messages)
        while trimmed and estimate_message_tokens(trimmed) > budget_tokens:
            trimmed.pop(0)

        return trimmed

    def trim_rag_context(self, context: str, budget_tokens: int) -> str:
        """Trim RAG context to fit within budget."""
        max_chars = budget_tokens * CHARS_PER_TOKEN
        if len(context) <= max_chars:
            return context
        # Truncate at a paragraph or sentence boundary
        truncated = context[:max_chars]
        last_para = truncated.rfind("\n\n")
        if last_para > max_chars // 2:
            return truncated[:last_para]
        last_sent = truncated.rfind(". ")
        if last_sent > max_chars // 2:
            return truncated[:last_sent + 1]
        return truncated
