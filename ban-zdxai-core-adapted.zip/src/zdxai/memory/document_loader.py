"""Ingest user files into chunks for RAG and training.

Supported formats: .txt, .json, .jsonl, .md, .csv, .pdf
Chunks are ~256 tokens with 32-token overlap.
"""

from __future__ import annotations

import csv
import io
import json
import logging
from dataclasses import dataclass
from pathlib import Path

from zdxai.constants import RAG_CHUNK_OVERLAP, RAG_CHUNK_SIZE

log = logging.getLogger(__name__)

# Approximate chars per token for rough token estimation
CHARS_PER_TOKEN = 4


@dataclass
class Chunk:
    text: str
    index: int
    metadata: dict | None = None


def estimate_tokens(text: str) -> int:
    """Rough token count estimate."""
    return max(1, len(text) // CHARS_PER_TOKEN)


def _split_into_chunks(
    text: str,
    chunk_size: int = RAG_CHUNK_SIZE,
    overlap: int = RAG_CHUNK_OVERLAP,
) -> list[str]:
    """Split text into chunks of approximately chunk_size tokens with overlap."""
    char_chunk = chunk_size * CHARS_PER_TOKEN
    char_overlap = overlap * CHARS_PER_TOKEN

    if len(text) <= char_chunk:
        return [text] if text.strip() else []

    chunks = []
    start = 0
    while start < len(text):
        end = start + char_chunk

        # Try to break at a paragraph or sentence boundary
        if end < len(text):
            # Look for paragraph break
            para_break = text.rfind("\n\n", start + char_chunk // 2, end + 100)
            if para_break > start:
                end = para_break + 2
            else:
                # Look for sentence break
                for sep in (". ", ".\n", "! ", "? "):
                    sent_break = text.rfind(sep, start + char_chunk // 2, end + 50)
                    if sent_break > start:
                        end = sent_break + len(sep)
                        break

        chunk = text[start:end].strip()
        if chunk:
            chunks.append(chunk)

        start = end - char_overlap
        if start >= len(text):
            break

    return chunks


def load_text(path: Path) -> tuple[str, list[Chunk]]:
    """Load a plain text file."""
    content = path.read_text(encoding="utf-8", errors="replace")
    raw_chunks = _split_into_chunks(content)
    chunks = [Chunk(text=c, index=i) for i, c in enumerate(raw_chunks)]
    return content, chunks


def load_markdown(path: Path) -> tuple[str, list[Chunk]]:
    """Load a markdown file, splitting by headings when possible."""
    content = path.read_text(encoding="utf-8", errors="replace")
    sections: list[str] = []
    current: list[str] = []

    for line in content.splitlines(keepends=True):
        if line.startswith("#") and current:
            sections.append("".join(current))
            current = [line]
        else:
            current.append(line)

    if current:
        sections.append("".join(current))

    # Further split large sections
    chunks: list[Chunk] = []
    idx = 0
    for section in sections:
        if estimate_tokens(section) > RAG_CHUNK_SIZE * 1.5:
            for sub in _split_into_chunks(section):
                chunks.append(Chunk(text=sub, index=idx))
                idx += 1
        elif section.strip():
            chunks.append(Chunk(text=section.strip(), index=idx))
            idx += 1

    return content, chunks


def load_json(path: Path) -> tuple[str, list[Chunk]]:
    """Load a JSON or JSONL file, extracting text fields."""
    content = path.read_text(encoding="utf-8", errors="replace")

    texts: list[str] = []

    if path.suffix == ".jsonl":
        for line in content.splitlines():
            line = line.strip()
            if not line:
                continue
            try:
                obj = json.loads(line)
                texts.append(_extract_text_from_json(obj))
            except json.JSONDecodeError:
                continue
    else:
        try:
            data = json.loads(content)
            if isinstance(data, list):
                for item in data:
                    texts.append(_extract_text_from_json(item))
            else:
                texts.append(_extract_text_from_json(data))
        except json.JSONDecodeError:
            texts.append(content)

    combined = "\n\n".join(texts)
    raw_chunks = _split_into_chunks(combined)
    chunks = [Chunk(text=c, index=i) for i, c in enumerate(raw_chunks)]
    return content, chunks


def _extract_text_from_json(obj, depth: int = 0) -> str:
    """Recursively extract text values from a JSON object."""
    if depth > 10:
        return ""
    if isinstance(obj, str):
        return obj
    if isinstance(obj, (int, float, bool)):
        return str(obj)
    if isinstance(obj, list):
        parts = [_extract_text_from_json(item, depth + 1) for item in obj]
        return "\n".join(p for p in parts if p)
    if isinstance(obj, dict):
        parts = []
        for key, val in obj.items():
            text = _extract_text_from_json(val, depth + 1)
            if text:
                parts.append(f"{key}: {text}")
        return "\n".join(parts)
    return ""


def load_csv(path: Path) -> tuple[str, list[Chunk]]:
    """Load a CSV file, converting rows to text."""
    content = path.read_text(encoding="utf-8", errors="replace")
    reader = csv.DictReader(io.StringIO(content))

    rows_text: list[str] = []
    for row in reader:
        parts = [f"{k}: {v}" for k, v in row.items() if v]
        rows_text.append(" | ".join(parts))

    combined = "\n".join(rows_text)
    raw_chunks = _split_into_chunks(combined)
    chunks = [Chunk(text=c, index=i) for i, c in enumerate(raw_chunks)]
    return content, chunks


def load_pdf(path: Path) -> tuple[str, list[Chunk]]:
    """Load a PDF file using pymupdf."""
    try:
        import pymupdf
    except ImportError:
        raise ImportError(
            "pymupdf is required for PDF parsing. "
            "Install it with: pip install 'zdxai[pdf]'"
        )

    doc = pymupdf.open(str(path))
    pages: list[str] = []
    for page in doc:
        text = page.get_text()
        if text.strip():
            pages.append(text)
    doc.close()

    content = "\n\n".join(pages)
    raw_chunks = _split_into_chunks(content)
    chunks = [Chunk(text=c, index=i) for i, c in enumerate(raw_chunks)]
    return content, chunks


# File type to loader mapping
LOADERS = {
    ".txt": load_text,
    ".text": load_text,
    ".md": load_markdown,
    ".markdown": load_markdown,
    ".json": load_json,
    ".jsonl": load_json,
    ".csv": load_csv,
    ".pdf": load_pdf,
}

SUPPORTED_EXTENSIONS = set(LOADERS.keys())


def detect_file_type(path: Path) -> str:
    """Map file extension to a type label."""
    ext = path.suffix.lower()
    mapping = {
        ".txt": "text", ".text": "text",
        ".md": "markdown", ".markdown": "markdown",
        ".json": "json", ".jsonl": "json",
        ".csv": "csv",
        ".pdf": "pdf",
    }
    return mapping.get(ext, "text")


def load_file(path: Path) -> tuple[str, list[Chunk]]:
    """Load a file and return (full_content, chunks). Raises ValueError for unsupported types."""
    ext = path.suffix.lower()
    loader = LOADERS.get(ext)
    if loader is None:
        raise ValueError(
            f"Unsupported file type: {ext}. "
            f"Supported: {', '.join(sorted(SUPPORTED_EXTENSIONS))}"
        )
    return loader(path)
