"""Unified RAG pipeline over conversations and user documents."""

from __future__ import annotations

import logging
from pathlib import Path

import numpy as np

from zdxai.config import Config
from zdxai.core.embeddings import EmbeddingEngine
from zdxai.memory.context_window import ContextBudget
from zdxai.memory.document_loader import (
    Chunk,
    detect_file_type,
    estimate_tokens,
    load_file,
)
from zdxai.storage.database import Database
from zdxai.storage.documents import DocumentStore
from zdxai.storage.embeddings_store import EmbeddingStore, SearchResult

log = logging.getLogger(__name__)


class RAGPipeline:
    """Retrieval-augmented generation pipeline."""

    def __init__(
        self,
        config: Config,
        db: Database,
        embedding_engine: EmbeddingEngine,
    ) -> None:
        self.config = config
        self.embedding_engine = embedding_engine
        self.embedding_store = EmbeddingStore(db)
        self.document_store = DocumentStore(db)
        self.context_budget = ContextBudget(config)

    def ingest_document(self, file_path: Path) -> tuple[str, int]:
        """Ingest a file: parse, chunk, embed, store.

        Returns: (document_id, chunk_count)
        """
        log.info("Ingesting document: %s", file_path)

        content, chunks = load_file(file_path)
        file_type = detect_file_type(file_path)
        size_bytes = file_path.stat().st_size

        # Store document record
        doc = self.document_store.add(
            filename=file_path.name,
            file_type=file_type,
            content=content,
            size_bytes=size_bytes,
            metadata={"source_path": str(file_path)},
        )

        # Embed and store each chunk
        if chunks and self.embedding_engine.is_loaded:
            records = []
            for chunk in chunks:
                vec = self.embedding_engine.embed(chunk.text)
                records.append((
                    "document",
                    doc.id,
                    chunk.text[:500],
                    vec,
                    chunk.index,
                    estimate_tokens(chunk.text),
                ))

            self.embedding_store.store_batch(records)
            self.document_store.mark_indexed(doc.id, len(chunks))
            log.info("Ingested %d chunks for %s", len(chunks), file_path.name)
        else:
            log.warning("Embedding model not loaded; document stored but not indexed.")

        return doc.id, len(chunks)

    def embed_message(self, message_id: str, content: str, source_type: str = "message") -> None:
        """Embed and store a single message for RAG retrieval."""
        if not self.embedding_engine.is_loaded:
            return
        if len(content.strip()) < 20:
            return  # Skip very short messages

        vec = self.embedding_engine.embed(content)
        self.embedding_store.store(
            source_type=source_type,
            source_id=message_id,
            content_preview=content[:500],
            embedding=vec,
            token_count=estimate_tokens(content),
        )

    def retrieve(
        self,
        query: str,
        top_k: int | None = None,
        source_types: list[str] | None = None,
    ) -> list[SearchResult]:
        """Retrieve the most relevant chunks for a query."""
        if not self.embedding_engine.is_loaded:
            return []

        k = top_k or self.config.rag_top_k
        query_vec = self.embedding_engine.embed(query)
        return self.embedding_store.search(
            query_embedding=query_vec,
            top_k=k,
            source_types=source_types,
        )

    def build_rag_context(self, query: str) -> str | None:
        """Retrieve relevant context and format it as a text block."""
        results = self.retrieve(query)
        if not results:
            return None

        # Filter by minimum similarity threshold
        filtered = [r for r in results if r.score > 0.3]
        if not filtered:
            return None

        parts: list[str] = []
        for r in filtered:
            source = r.record.source_type
            preview = r.record.content_preview
            score = r.score
            parts.append(f"[{source}, relevance={score:.2f}]\n{preview}")

        context = "\n\n---\n\n".join(parts)

        # Trim to budget
        system_tokens = estimate_tokens(self.config.system_prompt)
        query_tokens = estimate_tokens(query)
        rag_budget, _ = self.context_budget.compute_budget(system_tokens, query_tokens)
        context = self.context_budget.trim_rag_context(context, rag_budget)

        return context

    def delete_document(self, doc_id: str) -> None:
        """Remove a document and its embeddings."""
        self.embedding_store.delete_by_source("document", doc_id)
        self.document_store.delete(doc_id)

    def stats(self) -> dict:
        """Return RAG statistics."""
        return {
            "documents": len(self.document_store.list_all(limit=10000)),
            "message_embeddings": self.embedding_store.count("message"),
            "document_embeddings": self.embedding_store.count("document"),
            "total_embeddings": self.embedding_store.count(),
        }
