"""Starlette web UI for zdxai."""

from __future__ import annotations

import asyncio
import json
import logging
from pathlib import Path
from typing import AsyncIterator

from starlette.applications import Starlette
from starlette.requests import Request
from starlette.responses import HTMLResponse, JSONResponse, StreamingResponse
from starlette.routing import Route

from zdxai.core.engine import Engine

log = logging.getLogger(__name__)

STATIC_DIR = Path(__file__).parent / "static"


def create_app(engine: Engine) -> Starlette:

    async def index(request: Request) -> HTMLResponse:
        html = (STATIC_DIR / "index.html").read_text()
        return HTMLResponse(html)

    async def status(request: Request) -> JSONResponse:
        conv = engine.current_conversation
        return JSONResponse({
            "model": engine.config.model_filename,
            "loaded": engine.inference.is_loaded,
            "conversation_id": conv.id if conv else None,
        })

    async def list_conversations(request: Request) -> JSONResponse:
        convs = engine.conversations.list_conversations()
        return JSONResponse([
            {
                "id": c.id,
                "title": c.title,
                "updated_at": c.updated_at,
                "message_count": c.message_count,
            }
            for c in convs
        ])

    async def new_conversation(request: Request) -> JSONResponse:
        body = await request.json()
        title = body.get("title") if body else None
        conv = engine.new_conversation(title)
        return JSONResponse({"id": conv.id, "title": conv.title})

    async def switch_conversation(request: Request) -> JSONResponse:
        body = await request.json()
        conv_id = body.get("id", "")
        conv = engine.resume_conversation(conv_id)
        if not conv:
            return JSONResponse({"error": "Not found"}, status_code=404)
        return JSONResponse({"id": conv.id, "title": conv.title})

    async def get_messages(request: Request) -> JSONResponse:
        conv_id = request.query_params.get("id", "")
        if not conv_id:
            return JSONResponse({"error": "Missing id"}, status_code=400)
        msgs = engine.conversations.get_recent_messages(conv_id, limit=100)
        return JSONResponse([
            {"role": m["role"], "content": m.get("content", "")}
            for m in msgs
        ])

    async def stream_chat(request: Request) -> StreamingResponse:
        body = await request.json()
        user_input = body.get("message", "").strip()
        if not user_input:
            return JSONResponse({"error": "Empty message"}, status_code=400)

        async def event_generator() -> AsyncIterator[bytes]:
            loop = asyncio.get_event_loop()
            queue: asyncio.Queue[str | None] = asyncio.Queue()

            def produce() -> None:
                try:
                    for token in engine.chat_stream(user_input):
                        loop.call_soon_threadsafe(queue.put_nowait, token)
                except Exception as exc:
                    err_payload = json.dumps({"error": str(exc)})
                    loop.call_soon_threadsafe(
                        queue.put_nowait, f"__ERR__{err_payload}"
                    )
                finally:
                    loop.call_soon_threadsafe(queue.put_nowait, None)

            loop.run_in_executor(None, produce)

            while True:
                token = await queue.get()
                if token is None:
                    yield b"data: [DONE]\n\n"
                    break
                if token.startswith("__ERR__"):
                    yield f"data: {token[7:]}\n\n".encode()
                    yield b"data: [DONE]\n\n"
                    break
                payload = json.dumps({"token": token})
                yield f"data: {payload}\n\n".encode()

        return StreamingResponse(
            event_generator(),
            media_type="text/event-stream",
            headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"},
        )

    routes = [
        Route("/", index),
        Route("/api/status", status),
        Route("/api/conversations", list_conversations),
        Route("/api/conversations/new", new_conversation, methods=["POST"]),
        Route("/api/conversations/switch", switch_conversation, methods=["POST"]),
        Route("/api/conversations/messages", get_messages),
        Route("/api/stream", stream_chat, methods=["POST"]),
    ]

    return Starlette(routes=routes)
