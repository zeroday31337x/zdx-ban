"""ZdxAI Desktop GUI — PyQt6 Application"""

from __future__ import annotations

import json
import sys
from pathlib import Path
from typing import Optional

from PyQt6.QtCore import (
    QEvent, QObject, QSize, Qt, QThread, QTimer, pyqtSignal,
)
from PyQt6.QtGui import (
    QAction, QColor, QFont, QKeySequence, QTextCursor,
)
from PyQt6.QtWidgets import (
    QApplication, QCheckBox, QComboBox, QDialog, QDialogButtonBox,
    QDoubleSpinBox, QFileDialog, QFormLayout, QFrame, QGroupBox,
    QHBoxLayout, QLabel, QLineEdit, QListWidget, QListWidgetItem,
    QMainWindow, QMenuBar, QMessageBox, QPlainTextEdit, QProgressBar,
    QPushButton, QScrollArea, QSizePolicy, QSpinBox, QSplitter,
    QStatusBar, QTabWidget, QTextBrowser, QTextEdit, QToolBar,
    QVBoxLayout, QWidget,
)

# ── Dark Theme ────────────────────────────────────────────────────────────────

STYLESHEET = """
QMainWindow, QDialog, QWidget {
    background-color: #0f0f0f;
    color: #e2e8f0;
    font-family: 'Segoe UI', 'Inter', 'Arial', sans-serif;
    font-size: 13px;
}
QMenuBar {
    background-color: #0a0a0a;
    color: #e2e8f0;
    border-bottom: 1px solid #1e1e1e;
    padding: 2px 4px;
}
QMenuBar::item { padding: 4px 10px; border-radius: 4px; }
QMenuBar::item:selected { background: #1a1a1a; }
QMenu {
    background-color: #1a1a1a;
    color: #e2e8f0;
    border: 1px solid #2e2e2e;
    border-radius: 6px;
    padding: 4px;
}
QMenu::item { padding: 7px 24px 7px 12px; border-radius: 4px; }
QMenu::item:selected { background: #3b82f6; color: white; }
QMenu::separator { height: 1px; background: #2e2e2e; margin: 4px 8px; }
QPushButton {
    background: #1e1e1e;
    color: #e2e8f0;
    border: 1px solid #2e2e2e;
    border-radius: 6px;
    padding: 6px 16px;
    font-size: 13px;
}
QPushButton:hover { background: #2a2a2a; border-color: #3b82f6; }
QPushButton:pressed { background: #141414; }
QPushButton:disabled { color: #475569; border-color: #1e1e1e; }
QPushButton#primaryBtn {
    background: #3b82f6;
    color: white;
    border: none;
    font-weight: 600;
}
QPushButton#primaryBtn:hover { background: #2563eb; }
QPushButton#primaryBtn:pressed { background: #1d4ed8; }
QPushButton#primaryBtn:disabled { background: #1e3a5f; color: #475569; }
QPushButton#dangerBtn { background: #ef4444; color: white; border: none; }
QPushButton#dangerBtn:hover { background: #dc2626; }
QLineEdit, QTextEdit, QPlainTextEdit {
    background: #1a1a1a;
    color: #e2e8f0;
    border: 1px solid #2e2e2e;
    border-radius: 6px;
    padding: 6px 10px;
    selection-background-color: #3b82f6;
}
QLineEdit:focus, QTextEdit:focus, QPlainTextEdit:focus { border-color: #3b82f6; }
QListWidget {
    background: transparent;
    border: none;
    outline: none;
}
QListWidget::item {
    padding: 8px 10px;
    border-radius: 6px;
    color: #94a3b8;
    font-size: 13px;
}
QListWidget::item:hover { background: #141414; color: #e2e8f0; }
QListWidget::item:selected { background: #1e1e1e; color: #e2e8f0; }
QScrollBar:vertical {
    background: transparent;
    width: 6px;
    margin: 0;
}
QScrollBar::handle:vertical {
    background: #2e2e2e;
    border-radius: 3px;
    min-height: 20px;
}
QScrollBar::handle:vertical:hover { background: #3b82f6; }
QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical { height: 0; }
QScrollBar:horizontal {
    background: transparent;
    height: 6px;
    margin: 0;
}
QScrollBar::handle:horizontal {
    background: #2e2e2e;
    border-radius: 3px;
    min-width: 20px;
}
QScrollBar::add-line:horizontal, QScrollBar::sub-line:horizontal { width: 0; }
QGroupBox {
    color: #64748b;
    border: 1px solid #2e2e2e;
    border-radius: 6px;
    margin-top: 16px;
    padding-top: 8px;
    font-size: 11px;
    font-weight: 700;
    letter-spacing: 0.5px;
}
QGroupBox::title {
    subcontrol-origin: margin;
    subcontrol-position: top left;
    left: 10px;
    padding: 0 4px;
}
QComboBox {
    background: #1a1a1a;
    color: #e2e8f0;
    border: 1px solid #2e2e2e;
    border-radius: 6px;
    padding: 6px 10px;
    min-width: 120px;
}
QComboBox:hover { border-color: #3b82f6; }
QComboBox::drop-down { border: none; width: 24px; }
QComboBox QAbstractItemView {
    background: #1a1a1a;
    color: #e2e8f0;
    border: 1px solid #2e2e2e;
    selection-background-color: #3b82f6;
}
QSpinBox, QDoubleSpinBox {
    background: #1a1a1a;
    color: #e2e8f0;
    border: 1px solid #2e2e2e;
    border-radius: 6px;
    padding: 6px 10px;
}
QSpinBox:focus, QDoubleSpinBox:focus { border-color: #3b82f6; }
QCheckBox { spacing: 8px; color: #e2e8f0; }
QCheckBox::indicator {
    width: 16px;
    height: 16px;
    border: 1px solid #2e2e2e;
    border-radius: 4px;
    background: #1a1a1a;
}
QCheckBox::indicator:checked { background: #3b82f6; border-color: #3b82f6; }
QProgressBar {
    background: #1a1a1a;
    border: 1px solid #2e2e2e;
    border-radius: 4px;
    text-align: center;
    color: #e2e8f0;
    height: 18px;
}
QProgressBar::chunk { background: #3b82f6; border-radius: 4px; }
QStatusBar {
    background: #0a0a0a;
    color: #475569;
    border-top: 1px solid #1e1e1e;
    font-size: 12px;
}
QStatusBar::item { border: none; }
QTabWidget::pane {
    border: 1px solid #2e2e2e;
    border-radius: 6px;
    background: #0f0f0f;
}
QTabBar::tab {
    background: transparent;
    color: #64748b;
    padding: 8px 18px;
    border-bottom: 2px solid transparent;
    font-size: 13px;
}
QTabBar::tab:selected { color: #e2e8f0; border-bottom-color: #3b82f6; }
QTabBar::tab:hover { color: #cbd5e1; }
QSplitter::handle { background: #1e1e1e; }
QSplitter::handle:horizontal { width: 1px; }
"""

# ── Worker Threads ────────────────────────────────────────────────────────────

class EngineStartupThread(QThread):
    finished = pyqtSignal(bool, str)
    status   = pyqtSignal(str)

    def __init__(self, config):
        super().__init__()
        self.config = config
        self.engine = None

    def run(self):
        try:
            from zdxai.core.engine import Engine
            self.status.emit("Initializing engine…")
            self.engine = Engine(self.config)
            self.status.emit("Loading models…")
            self.engine.startup()
            self.finished.emit(True, "")
        except Exception as exc:
            self.finished.emit(False, str(exc))


class ChatThread(QThread):
    token    = pyqtSignal(str)
    finished = pyqtSignal(str)
    error    = pyqtSignal(str)

    def __init__(self, engine, user_input: str):
        super().__init__()
        self.engine     = engine
        self.user_input = user_input

    def run(self):
        try:
            full = ""
            for tok in self.engine.chat_stream(self.user_input):
                full += tok
                self.token.emit(tok)
            self.finished.emit(full)
        except Exception as exc:
            self.error.emit(str(exc))


class TrainingThread(QThread):
    progress = pyqtSignal(str)
    finished = pyqtSignal(bool, str)

    def __init__(self, engine, train_type: str, name: str, path: Optional[str] = None):
        super().__init__()
        self.engine     = engine
        self.train_type = train_type
        self.name       = name
        self.path       = path

    def run(self):
        try:
            self.progress.emit(f"Preparing dataset ({self.train_type})…")
            dataset = self.engine.prepare_training_dataset(
                self.train_type, file_path=self.path
            )
            self.progress.emit(f"Training adapter '{self.name}'…")
            self.engine.start_training(self.name, dataset)
            self.finished.emit(True, f"Adapter '{self.name}' trained successfully.")
        except Exception as exc:
            self.finished.emit(False, str(exc))


class IngestThread(QThread):
    finished = pyqtSignal(bool, str, int)  # success, doc_id_or_err, chunks

    def __init__(self, engine, path: str):
        super().__init__()
        self.engine = engine
        self.path   = path

    def run(self):
        try:
            doc_id, chunks = self.engine.ingest_document(self.path)
            self.finished.emit(True, doc_id, chunks)
        except Exception as exc:
            self.finished.emit(False, str(exc), 0)


class ActivateWorker(QObject):
    finished = pyqtSignal(bool, object)  # success, LicenseInfo or str

    def __init__(self, data_dir, email: str, password: str):
        super().__init__()
        self.data_dir = data_dir
        self.email    = email
        self.password = password

    def run(self):
        try:
            from zdxai.licensing import activate
            info = activate(self.data_dir, email=self.email, password=self.password)
            self.finished.emit(True, info)
        except Exception as exc:
            self.finished.emit(False, str(exc))


# ── Helper: small status label ─────────────────────────────────────────────────

def _sep_label(text="|"):
    lbl = QLabel(text)
    lbl.setStyleSheet("color: #2e2e2e; padding: 0 4px;")
    return lbl


# ── License Dialog ─────────────────────────────────────────────────────────────

class LicenseDialog(QDialog):
    activated = pyqtSignal(dict)

    def __init__(self, config, parent=None):
        super().__init__(parent)
        self.config = config
        self.setWindowTitle("License & Account")
        self.setMinimumWidth(480)
        self.setModal(True)
        self._build_ui()
        self._load_current()

    def _build_ui(self):
        layout = QVBoxLayout(self)
        layout.setSpacing(14)
        layout.setContentsMargins(24, 24, 24, 20)

        title = QLabel("License & Account")
        title.setStyleSheet("font-size: 18px; font-weight: 700; color: #e2e8f0;")
        layout.addWidget(title)

        sub = QLabel("Sign in to activate your zdxai license.")
        sub.setStyleSheet("color: #64748b; font-size: 12px;")
        layout.addWidget(sub)

        # Status card
        card = QFrame()
        card.setStyleSheet(
            "background: #141414; border: 1px solid #2e2e2e; border-radius: 8px;"
        )
        cl = QHBoxLayout(card)
        cl.setContentsMargins(14, 10, 14, 10)
        self._status_dot = QLabel("●")
        self._status_dot.setStyleSheet("font-size: 14px; color: #475569;")
        self._status_lbl = QLabel("Not activated")
        self._status_lbl.setStyleSheet("font-size: 13px; font-weight: 600; color: #94a3b8;")
        self._tier_badge = QLabel("")
        self._tier_badge.setStyleSheet(
            "background: #1e1e1e; color: #64748b; border-radius: 10px;"
            "padding: 2px 10px; font-size: 11px; font-weight: 600;"
        )
        self._email_lbl = QLabel("")
        self._email_lbl.setStyleSheet("color: #64748b; font-size: 12px;")
        cl.addWidget(self._status_dot)
        cl.addSpacing(6)
        cl.addWidget(self._status_lbl)
        cl.addStretch()
        cl.addWidget(self._tier_badge)
        layout.addWidget(card)
        layout.addWidget(self._email_lbl)

        # Tabs
        self.tabs = QTabWidget()
        layout.addWidget(self.tabs)

        # ── Sign-in tab
        sign_tab = QWidget()
        sf = QFormLayout(sign_tab)
        sf.setContentsMargins(16, 16, 16, 16)
        sf.setSpacing(12)
        self._email_in = QLineEdit()
        self._email_in.setPlaceholderText("your@email.com")
        sf.addRow("Email", self._email_in)
        self._pw_in = QLineEdit()
        self._pw_in.setEchoMode(QLineEdit.EchoMode.Password)
        self._pw_in.setPlaceholderText("••••••••")
        self._pw_in.returnPressed.connect(self._do_activate)
        sf.addRow("Password", self._pw_in)
        self._login_btn = QPushButton("Activate License")
        self._login_btn.setObjectName("primaryBtn")
        self._login_btn.clicked.connect(self._do_activate)
        sf.addRow("", self._login_btn)
        self._login_err = QLabel("")
        self._login_err.setStyleSheet("color: #ef4444; font-size: 12px;")
        self._login_err.setWordWrap(True)
        sf.addRow("", self._login_err)
        self.tabs.addTab(sign_tab, "Sign In")

        # ── Purchase tab
        pur_tab = QWidget()
        pl = QVBoxLayout(pur_tab)
        pl.setContentsMargins(16, 16, 16, 16)
        pl.setSpacing(10)

        consumer_card = QFrame()
        consumer_card.setStyleSheet(
            "background: #141414; border: 1px solid #2e2e2e; border-radius: 8px;"
        )
        cc = QVBoxLayout(consumer_card)
        cc.setContentsMargins(14, 12, 14, 12)
        cc.addWidget(self._tier_card_header("Consumer", "$6.99 / month",
                                             "Full local AI — online license refresh, 7-day grace period"))
        cbtn = QPushButton("Purchase Consumer Plan")
        cbtn.setObjectName("primaryBtn")
        cbtn.clicked.connect(self._purchase)
        cc.addWidget(cbtn)
        pl.addWidget(consumer_card)

        ent_card = QFrame()
        ent_card.setStyleSheet(
            "background: #141414; border: 1px solid #3b82f6; border-radius: 8px;"
        )
        ec = QVBoxLayout(ent_card)
        ec.setContentsMargins(14, 12, 14, 12)
        ec.addWidget(self._tier_card_header("Enterprise", "$99.99 / month",
                                             "Fully offline — no network calls after activation"))
        ebtn = QPushButton("Purchase Enterprise Plan")
        ebtn.setObjectName("primaryBtn")
        ebtn.clicked.connect(self._purchase)
        ec.addWidget(ebtn)
        pl.addWidget(ent_card)
        pl.addStretch()
        self.tabs.addTab(pur_tab, "Purchase")

        # Bottom row
        bot = QHBoxLayout()
        self._deact_btn = QPushButton("Deactivate License")
        self._deact_btn.setObjectName("dangerBtn")
        self._deact_btn.clicked.connect(self._do_deactivate)
        self._deact_btn.hide()
        bot.addWidget(self._deact_btn)
        bot.addStretch()
        close = QPushButton("Close")
        close.clicked.connect(self.accept)
        bot.addWidget(close)
        layout.addLayout(bot)

    def _tier_card_header(self, name, price, desc):
        w = QWidget()
        l = QVBoxLayout(w)
        l.setContentsMargins(0, 0, 0, 8)
        row = QHBoxLayout()
        n = QLabel(name)
        n.setStyleSheet("font-weight: 700; font-size: 14px;")
        p = QLabel(price)
        p.setStyleSheet("color: #3b82f6; font-weight: 600; font-size: 14px;")
        row.addWidget(n)
        row.addStretch()
        row.addWidget(p)
        l.addLayout(row)
        d = QLabel(desc)
        d.setStyleSheet("color: #64748b; font-size: 12px;")
        l.addWidget(d)
        return w

    def _load_current(self):
        try:
            from zdxai.licensing import verify_license
            info = verify_license(self.config.data_dir)
            if info:
                self._show_active(info)
        except Exception:
            pass

    def _show_active(self, info):
        self._status_dot.setStyleSheet("font-size: 14px; color: #22c55e;")
        self._status_lbl.setText("License active")
        self._status_lbl.setStyleSheet("font-size: 13px; font-weight: 600; color: #22c55e;")
        tier = getattr(info, "tier", "unknown").upper()
        self._tier_badge.setText(tier)
        self._tier_badge.setStyleSheet(
            "background: #14261e; color: #22c55e; border-radius: 10px;"
            "padding: 2px 10px; font-size: 11px; font-weight: 600;"
        )
        email = getattr(info, "email", "")
        self._email_lbl.setText(email)
        self._deact_btn.show()
        self.tabs.setEnabled(False)

    def _do_activate(self):
        email = self._email_in.text().strip()
        pw    = self._pw_in.text()
        if not email or not pw:
            self._login_err.setText("Please enter your email and password.")
            return
        self._login_btn.setEnabled(False)
        self._login_btn.setText("Activating…")
        self._login_err.setText("")

        self._act_thread = QThread()
        self._act_worker = ActivateWorker(self.config.data_dir, email, pw)
        self._act_worker.moveToThread(self._act_thread)
        self._act_thread.started.connect(self._act_worker.run)
        self._act_worker.finished.connect(self._on_activated)
        self._act_worker.finished.connect(self._act_thread.quit)
        self._act_thread.start()

    def _on_activated(self, success, result):
        self._login_btn.setEnabled(True)
        self._login_btn.setText("Activate License")
        if success:
            self._show_active(result)
            self.activated.emit({
                "tier":  getattr(result, "tier", ""),
                "email": getattr(result, "email", ""),
            })
        else:
            self._login_err.setText(f"Error: {result}")

    def _do_deactivate(self):
        if QMessageBox.question(
            self, "Deactivate License",
            "Are you sure you want to deactivate your license?",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
        ) == QMessageBox.StandardButton.Yes:
            try:
                from zdxai.licensing import deactivate
                deactivate(self.config.data_dir)
                self._status_dot.setStyleSheet("font-size: 14px; color: #475569;")
                self._status_lbl.setText("Not activated")
                self._status_lbl.setStyleSheet("font-size: 13px; font-weight: 600; color: #94a3b8;")
                self._tier_badge.setText("")
                self._email_lbl.setText("")
                self._deact_btn.hide()
                self.tabs.setEnabled(True)
            except Exception as exc:
                QMessageBox.warning(self, "Error", str(exc))

    def _purchase(self):
        from zdxai.licensing import purchase_license
        purchase_license()


# ── Training Dialog ────────────────────────────────────────────────────────────

class TrainingDialog(QDialog):
    def __init__(self, engine, start_tab: int = 0, parent=None):
        super().__init__(parent)
        self.engine = engine
        self.setWindowTitle("LoRA Adapter Training")
        self.setMinimumWidth(520)
        self.setModal(True)
        self._build_ui()
        self.tabs.setCurrentIndex(start_tab)

    def _build_ui(self):
        layout = QVBoxLayout(self)
        layout.setSpacing(14)
        layout.setContentsMargins(24, 24, 24, 20)

        title = QLabel("LoRA Adapter Training")
        title.setStyleSheet("font-size: 18px; font-weight: 700;")
        layout.addWidget(title)

        sub = QLabel(
            "Fine-tune a LoRA adapter on your conversations, ingested documents, or a custom JSONL file."
        )
        sub.setStyleSheet("color: #64748b; font-size: 12px;")
        sub.setWordWrap(True)
        layout.addWidget(sub)

        self.tabs = QTabWidget()
        layout.addWidget(self.tabs)

        # ── From Conversations
        conv_w = QWidget()
        conv_f = QFormLayout(conv_w)
        conv_f.setContentsMargins(16, 16, 16, 16)
        conv_f.setSpacing(12)
        self._conv_name = QLineEdit()
        self._conv_name.setPlaceholderText("e.g. my-adapter-v1")
        conv_f.addRow("Adapter name", self._conv_name)
        conv_btn = QPushButton("Start Training")
        conv_btn.setObjectName("primaryBtn")
        conv_btn.clicked.connect(
            lambda: self._start("conversations", self._conv_name.text())
        )
        conv_f.addRow("", conv_btn)
        self.tabs.addTab(conv_w, "From Conversations")

        # ── From Documents
        docs_w = QWidget()
        docs_f = QFormLayout(docs_w)
        docs_f.setContentsMargins(16, 16, 16, 16)
        docs_f.setSpacing(12)
        self._docs_name = QLineEdit()
        self._docs_name.setPlaceholderText("e.g. docs-adapter")
        docs_f.addRow("Adapter name", self._docs_name)
        docs_btn = QPushButton("Start Training")
        docs_btn.setObjectName("primaryBtn")
        docs_btn.clicked.connect(
            lambda: self._start("documents", self._docs_name.text())
        )
        docs_f.addRow("", docs_btn)
        self.tabs.addTab(docs_w, "From Documents")

        # ── From File
        file_w = QWidget()
        file_f = QFormLayout(file_w)
        file_f.setContentsMargins(16, 16, 16, 16)
        file_f.setSpacing(12)
        self._file_name = QLineEdit()
        self._file_name.setPlaceholderText("e.g. custom-adapter")
        file_f.addRow("Adapter name", self._file_name)
        file_row = QHBoxLayout()
        self._file_path = QLineEdit()
        self._file_path.setPlaceholderText("path/to/data.jsonl")
        self._file_path.setReadOnly(True)
        browse = QPushButton("Browse…")
        browse.clicked.connect(self._browse)
        file_row.addWidget(self._file_path)
        file_row.addWidget(browse)
        file_f.addRow("JSONL file", file_row)
        file_btn = QPushButton("Start Training")
        file_btn.setObjectName("primaryBtn")
        file_btn.clicked.connect(
            lambda: self._start("file", self._file_name.text(), self._file_path.text())
        )
        file_f.addRow("", file_btn)
        self.tabs.addTab(file_w, "From File")

        # ── Progress
        grp = QGroupBox("PROGRESS")
        grp_l = QVBoxLayout(grp)
        self._prog_bar = QProgressBar()
        self._prog_bar.setRange(0, 0)
        self._prog_bar.hide()
        self._prog_lbl = QLabel("")
        self._prog_lbl.setStyleSheet("color: #94a3b8; font-size: 12px;")
        grp_l.addWidget(self._prog_bar)
        grp_l.addWidget(self._prog_lbl)
        layout.addWidget(grp)

        close = QPushButton("Close")
        close.clicked.connect(self.accept)
        layout.addWidget(close, alignment=Qt.AlignmentFlag.AlignRight)

    def _browse(self):
        path, _ = QFileDialog.getOpenFileName(
            self, "Select JSONL File", "", "JSONL files (*.jsonl);;All files (*)"
        )
        if path:
            self._file_path.setText(path)

    def _start(self, train_type: str, name: str, path: str = ""):
        if not name.strip():
            QMessageBox.warning(self, "Required", "Please enter an adapter name.")
            return
        if train_type == "file" and not path.strip():
            QMessageBox.warning(self, "Required", "Please select a JSONL file.")
            return
        self._prog_bar.show()
        self._prog_lbl.setStyleSheet("color: #94a3b8; font-size: 12px;")
        self._prog_lbl.setText("Starting…")
        self._train_thread = TrainingThread(
            self.engine, train_type, name.strip(), path.strip() or None
        )
        self._train_thread.progress.connect(self._prog_lbl.setText)
        self._train_thread.finished.connect(self._done)
        self._train_thread.start()

    def _done(self, success: bool, msg: str):
        self._prog_bar.hide()
        if success:
            self._prog_lbl.setStyleSheet("color: #22c55e; font-size: 12px;")
            self._prog_lbl.setText(f"✓ {msg}")
        else:
            self._prog_lbl.setStyleSheet("color: #ef4444; font-size: 12px;")
            self._prog_lbl.setText(f"✗ {msg}")


# ── Adapters Dialog ───────────────────────────────────────────────────────────

class AdaptersDialog(QDialog):
    def __init__(self, engine, parent=None):
        super().__init__(parent)
        self.engine = engine
        self.setWindowTitle("LoRA Adapters")
        self.setMinimumWidth(440)
        self.setModal(True)
        self._build_ui()
        self._load()

    def _build_ui(self):
        layout = QVBoxLayout(self)
        layout.setSpacing(12)
        layout.setContentsMargins(20, 20, 20, 20)

        title = QLabel("LoRA Adapters")
        title.setStyleSheet("font-size: 16px; font-weight: 700;")
        layout.addWidget(title)

        self._list = QListWidget()
        self._list.setMinimumHeight(180)
        self._list.setStyleSheet(
            "QListWidget { background: #141414; border: 1px solid #2e2e2e;"
            "border-radius: 6px; }"
            "QListWidget::item { color: #e2e8f0; padding: 8px 12px; }"
            "QListWidget::item:selected { background: #1e3a5f; }"
        )
        layout.addWidget(self._list)

        btns = QHBoxLayout()
        act_btn = QPushButton("Activate Selected")
        act_btn.setObjectName("primaryBtn")
        act_btn.clicked.connect(self._activate)
        deact_btn = QPushButton("Deactivate")
        deact_btn.clicked.connect(self._deactivate)
        btns.addWidget(act_btn)
        btns.addWidget(deact_btn)
        btns.addStretch()
        close = QPushButton("Close")
        close.clicked.connect(self.accept)
        btns.addWidget(close)
        layout.addLayout(btns)

        self._status = QLabel("")
        self._status.setStyleSheet("color: #94a3b8; font-size: 12px;")
        layout.addWidget(self._status)

    def _load(self):
        self._list.clear()
        try:
            adapters_dir = self.engine.config.adapters_dir
            if adapters_dir.exists():
                for p in sorted(adapters_dir.iterdir()):
                    if p.is_dir():
                        active = (
                            self.engine.config.adapter_path
                            and str(self.engine.config.adapter_path) == str(p)
                        )
                        label = f"{p.name}  [active]" if active else p.name
                        item = QListWidgetItem(label)
                        if active:
                            item.setForeground(QColor("#3b82f6"))
                        self._list.addItem(item)
        except Exception as exc:
            self._status.setText(f"Error: {exc}")

    def _activate(self):
        item = self._list.currentItem()
        if not item:
            return
        name = item.text().replace("  [active]", "").strip()
        try:
            self.engine.activate_adapter(name)
            self._status.setStyleSheet("color: #22c55e; font-size: 12px;")
            self._status.setText(f"Activated: {name}")
            self._load()
        except Exception as exc:
            self._status.setStyleSheet("color: #ef4444; font-size: 12px;")
            self._status.setText(f"Error: {exc}")

    def _deactivate(self):
        try:
            self.engine.deactivate_adapter()
            self._status.setStyleSheet("color: #94a3b8; font-size: 12px;")
            self._status.setText("Adapter deactivated.")
            self._load()
        except Exception as exc:
            self._status.setStyleSheet("color: #ef4444; font-size: 12px;")
            self._status.setText(f"Error: {exc}")


# ── Documents Dialog ──────────────────────────────────────────────────────────

class DocumentsDialog(QDialog):
    def __init__(self, engine, start_tab: int = 0, parent=None):
        super().__init__(parent)
        self.engine = engine
        self.setWindowTitle("Documents & RAG Memory")
        self.setMinimumWidth(580)
        self.setMinimumHeight(440)
        self.setModal(True)
        self._build_ui()
        self.tabs.setCurrentIndex(start_tab)
        self._load_doc_list()

    def _build_ui(self):
        layout = QVBoxLayout(self)
        layout.setSpacing(12)
        layout.setContentsMargins(20, 20, 20, 20)

        title = QLabel("Documents & RAG Memory")
        title.setStyleSheet("font-size: 16px; font-weight: 700;")
        layout.addWidget(title)

        self.tabs = QTabWidget()
        layout.addWidget(self.tabs)

        # ── Ingest
        ingest_w = QWidget()
        il = QVBoxLayout(ingest_w)
        il.setContentsMargins(12, 12, 12, 12)
        il.setSpacing(10)
        il.addWidget(QLabel("Select a document to add to RAG memory:"))
        row = QHBoxLayout()
        self._ing_path = QLineEdit()
        self._ing_path.setPlaceholderText("No file selected…")
        self._ing_path.setReadOnly(True)
        br = QPushButton("Browse…")
        br.clicked.connect(self._browse_ingest)
        row.addWidget(self._ing_path)
        row.addWidget(br)
        il.addLayout(row)
        ing_btn = QPushButton("Ingest Document")
        ing_btn.setObjectName("primaryBtn")
        ing_btn.clicked.connect(self._ingest)
        il.addWidget(ing_btn)
        self._ing_status = QLabel("")
        self._ing_status.setStyleSheet("font-size: 12px; color: #94a3b8;")
        il.addWidget(self._ing_status)
        il.addStretch()
        self.tabs.addTab(ingest_w, "Ingest Document")

        # ── Search
        search_w = QWidget()
        sl = QVBoxLayout(search_w)
        sl.setContentsMargins(12, 12, 12, 12)
        sl.setSpacing(10)
        srow = QHBoxLayout()
        self._search_in = QLineEdit()
        self._search_in.setPlaceholderText("Search memory…")
        self._search_in.returnPressed.connect(self._search)
        sbtn = QPushButton("Search")
        sbtn.setObjectName("primaryBtn")
        sbtn.clicked.connect(self._search)
        srow.addWidget(self._search_in)
        srow.addWidget(sbtn)
        sl.addLayout(srow)
        self._search_out = QTextEdit()
        self._search_out.setReadOnly(True)
        self._search_out.setPlaceholderText("Results will appear here…")
        sl.addWidget(self._search_out)
        self.tabs.addTab(search_w, "Search Memory")

        # ── List
        list_w = QWidget()
        ll = QVBoxLayout(list_w)
        ll.setContentsMargins(12, 12, 12, 12)
        ll.setSpacing(8)
        ref_btn = QPushButton("Refresh")
        ref_btn.clicked.connect(self._load_doc_list)
        ll.addWidget(ref_btn, alignment=Qt.AlignmentFlag.AlignRight)
        self._doc_list = QTextEdit()
        self._doc_list.setReadOnly(True)
        self._doc_list.setPlaceholderText("Ingested documents will appear here…")
        ll.addWidget(self._doc_list)
        self.tabs.addTab(list_w, "Ingested Documents")

        close = QPushButton("Close")
        close.clicked.connect(self.accept)
        layout.addWidget(close, alignment=Qt.AlignmentFlag.AlignRight)

    def _browse_ingest(self):
        path, _ = QFileDialog.getOpenFileName(
            self, "Select Document", "",
            "Documents (*.txt *.md *.json *.jsonl *.csv *.pdf);;All files (*)"
        )
        if path:
            self._ing_path.setText(path)

    def _ingest(self):
        path = self._ing_path.text().strip()
        if not path:
            self._ing_status.setText("Please select a file first.")
            return
        self._ing_status.setStyleSheet("color: #f59e0b; font-size: 12px;")
        self._ing_status.setText("Ingesting…")
        self._ing_thread = IngestThread(self.engine, path)
        self._ing_thread.finished.connect(self._ingest_done)
        self._ing_thread.start()

    def _ingest_done(self, success: bool, msg: str, chunks: int):
        if success:
            self._ing_status.setStyleSheet("color: #22c55e; font-size: 12px;")
            self._ing_status.setText(f"✓ Ingested {chunks} chunks (ID: {msg})")
            self._load_doc_list()
        else:
            self._ing_status.setStyleSheet("color: #ef4444; font-size: 12px;")
            self._ing_status.setText(f"✗ {msg}")

    def _search(self):
        q = self._search_in.text().strip()
        if not q:
            return
        try:
            results = self.engine.rag_search(q)
            if not results:
                self._search_out.setPlainText("No results found.")
                return
            lines = []
            for i, r in enumerate(results, 1):
                lines.append(f"[{i}]  score: {r.get('score', 0):.4f}  |  {r.get('source', 'unknown')}")
                lines.append(r.get("text", "").strip())
                lines.append("─" * 60)
            self._search_out.setPlainText("\n".join(lines))
        except Exception as exc:
            self._search_out.setPlainText(f"Error: {exc}")

    def _load_doc_list(self):
        try:
            docs = self.engine.rag.list_documents() if hasattr(self.engine, "rag") else []
            if docs:
                self._doc_list.setPlainText(
                    "\n".join(f"{d.get('id','')}  {d.get('source','')}" for d in docs)
                )
            else:
                self._doc_list.setPlainText("No documents ingested yet.")
        except Exception:
            self._doc_list.setPlainText("Use the Ingest tab to add documents.")


# ── Settings Dialog ───────────────────────────────────────────────────────────

class SettingsDialog(QDialog):
    def __init__(self, config, parent=None):
        super().__init__(parent)
        self.config = config
        self.setWindowTitle("Settings")
        self.setMinimumWidth(520)
        self.setModal(True)
        self._build_ui()

    def _build_ui(self):
        layout = QVBoxLayout(self)
        layout.setSpacing(14)
        layout.setContentsMargins(24, 24, 24, 20)

        title = QLabel("Settings")
        title.setStyleSheet("font-size: 18px; font-weight: 700;")
        layout.addWidget(title)

        tabs = QTabWidget()
        layout.addWidget(tabs)

        # ── Model
        m = QWidget()
        mf = QFormLayout(m)
        mf.setContentsMargins(16, 16, 16, 16)
        mf.setSpacing(12)
        self._model_edit = QLineEdit(str(getattr(self.config, "model_filename", "")))
        mf.addRow("Model filename", self._model_edit)
        self._threads = QSpinBox()
        self._threads.setRange(1, 64)
        self._threads.setValue(getattr(self.config, "threads", 4))
        mf.addRow("CPU threads", self._threads)
        self._gpu = QSpinBox()
        self._gpu.setRange(0, 200)
        self._gpu.setValue(getattr(self.config, "gpu_layers", 0))
        mf.addRow("GPU layers (offload)", self._gpu)
        self._ctx = QSpinBox()
        self._ctx.setRange(512, 32768)
        self._ctx.setSingleStep(512)
        self._ctx.setValue(getattr(self.config, "context_length", 2048))
        mf.addRow("Context window (tokens)", self._ctx)
        self._maxtok = QSpinBox()
        self._maxtok.setRange(64, 8192)
        self._maxtok.setValue(getattr(self.config, "max_tokens", 512))
        mf.addRow("Max output tokens", self._maxtok)
        tabs.addTab(m, "Model")

        # ── Inference
        inf = QWidget()
        inf_f = QFormLayout(inf)
        inf_f.setContentsMargins(16, 16, 16, 16)
        inf_f.setSpacing(12)
        self._temp = QDoubleSpinBox()
        self._temp.setRange(0.0, 2.0)
        self._temp.setSingleStep(0.05)
        self._temp.setDecimals(2)
        self._temp.setValue(getattr(self.config, "temperature", 0.7))
        inf_f.addRow("Temperature", self._temp)
        self._top_p = QDoubleSpinBox()
        self._top_p.setRange(0.0, 1.0)
        self._top_p.setSingleStep(0.05)
        self._top_p.setDecimals(2)
        self._top_p.setValue(getattr(self.config, "top_p", 0.9))
        inf_f.addRow("Top-P", self._top_p)
        tabs.addTab(inf, "Inference")

        # ── RAG
        rag = QWidget()
        rag_f = QFormLayout(rag)
        rag_f.setContentsMargins(16, 16, 16, 16)
        rag_f.setSpacing(12)
        self._chunk = QSpinBox()
        self._chunk.setRange(64, 4096)
        self._chunk.setValue(getattr(self.config, "rag_chunk_size", 256))
        rag_f.addRow("Chunk size (tokens)", self._chunk)
        self._overlap = QSpinBox()
        self._overlap.setRange(0, 512)
        self._overlap.setValue(getattr(self.config, "rag_chunk_overlap", 32))
        rag_f.addRow("Chunk overlap", self._overlap)
        self._top_k = QSpinBox()
        self._top_k.setRange(1, 20)
        self._top_k.setValue(getattr(self.config, "rag_top_k", 5))
        rag_f.addRow("Top-K results", self._top_k)
        tabs.addTab(rag, "RAG")

        # ── Router
        rtr = QWidget()
        rtr_f = QFormLayout(rtr)
        rtr_f.setContentsMargins(16, 16, 16, 16)
        rtr_f.setSpacing(12)
        self._rtr_on = QCheckBox("Enable Embedding Gravity Wells router")
        self._rtr_on.setChecked(getattr(self.config, "router_enabled", True))
        rtr_f.addRow("", self._rtr_on)
        self._rtr_local = QCheckBox("Prefer local model")
        self._rtr_local.setChecked(getattr(self.config, "router_prefer_local", False))
        rtr_f.addRow("", self._rtr_local)
        self._min_grav = QDoubleSpinBox()
        self._min_grav.setRange(0.0, 1.0)
        self._min_grav.setSingleStep(0.05)
        self._min_grav.setDecimals(2)
        self._min_grav.setValue(getattr(self.config, "router_min_gravity", 0.5))
        rtr_f.addRow("Min gravity threshold", self._min_grav)
        self._split_thr = QDoubleSpinBox()
        self._split_thr.setRange(0.0, 1.0)
        self._split_thr.setSingleStep(0.05)
        self._split_thr.setDecimals(2)
        self._split_thr.setValue(getattr(self.config, "router_well_split_threshold", 0.3))
        rtr_f.addRow("Well split threshold", self._split_thr)
        self._feedback_alpha = QDoubleSpinBox()
        self._feedback_alpha.setRange(0.0, 1.0)
        self._feedback_alpha.setSingleStep(0.01)
        self._feedback_alpha.setDecimals(3)
        self._feedback_alpha.setValue(getattr(self.config, "router_feedback_alpha", 0.05))
        rtr_f.addRow("Feedback alpha (drift)", self._feedback_alpha)
        tabs.addTab(rtr, "Router")

        # ── Web UI
        web = QWidget()
        web_f = QFormLayout(web)
        web_f.setContentsMargins(16, 16, 16, 16)
        web_f.setSpacing(12)
        self._web_host = QLineEdit(getattr(self.config, "web_host", "127.0.0.1"))
        web_f.addRow("Host", self._web_host)
        self._web_port = QSpinBox()
        self._web_port.setRange(1024, 65535)
        self._web_port.setValue(getattr(self.config, "web_port", 8392))
        web_f.addRow("Port", self._web_port)
        tabs.addTab(web, "Web UI")

        btns = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Save | QDialogButtonBox.StandardButton.Cancel
        )
        btns.accepted.connect(self._save)
        btns.rejected.connect(self.reject)
        layout.addWidget(btns)

    def _save(self):
        self.config.model_filename    = self._model_edit.text().strip()
        self.config.threads           = self._threads.value()
        self.config.gpu_layers        = self._gpu.value()
        self.config.context_length    = self._ctx.value()
        self.config.max_tokens        = self._maxtok.value()
        self.config.temperature       = self._temp.value()
        self.config.top_p             = self._top_p.value()
        self.config.rag_chunk_size    = self._chunk.value()
        self.config.rag_chunk_overlap = self._overlap.value()
        self.config.rag_top_k         = self._top_k.value()
        self.config.router_enabled                 = self._rtr_on.isChecked()
        self.config.router_prefer_local            = self._rtr_local.isChecked()
        self.config.router_min_gravity             = self._min_grav.value()
        self.config.router_well_split_threshold    = self._split_thr.value()
        self.config.router_feedback_alpha          = self._feedback_alpha.value()
        self.config.web_host = self._web_host.text().strip()
        self.config.web_port = self._web_port.value()
        self.accept()


# ── Permissions Dialog ────────────────────────────────────────────────────────

class PermissionsDialog(QDialog):
    def __init__(self, engine, parent=None):
        super().__init__(parent)
        self.engine = engine
        self.setWindowTitle("MCP Tool Permissions")
        self.setMinimumWidth(500)
        self.setModal(True)
        self._build_ui()

    def _build_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(20, 20, 20, 20)
        layout.setSpacing(12)

        title = QLabel("MCP Tool Permissions")
        title.setStyleSheet("font-size: 16px; font-weight: 700;")
        layout.addWidget(title)

        desc = QLabel(
            "Controls which MCP tools the AI can use. Deny-by-default — "
            "explicit allow required before any tool runs."
        )
        desc.setStyleSheet("color: #64748b; font-size: 12px;")
        desc.setWordWrap(True)
        layout.addWidget(desc)

        # Tool list with per-tool combo
        self._rows: list[tuple[str, QComboBox]] = []
        tools_frame = QWidget()
        tools_frame.setStyleSheet(
            "background: #141414; border: 1px solid #2e2e2e; border-radius: 6px;"
        )
        tf = QVBoxLayout(tools_frame)
        tf.setContentsMargins(12, 10, 12, 10)
        tf.setSpacing(8)

        try:
            mcp = getattr(self.engine, "mcp", None)
            perms = mcp.get_permissions() if mcp and hasattr(mcp, "get_permissions") else {}
        except Exception:
            perms = {}

        if perms:
            for tool, perm in perms.items():
                row = QHBoxLayout()
                lbl = QLabel(tool)
                lbl.setStyleSheet("color: #e2e8f0; font-size: 13px; min-width: 180px;")
                combo = QComboBox()
                combo.addItems(["allow", "ask", "deny"])
                combo.setCurrentText(str(perm).lower())
                combo.setFixedWidth(100)
                row.addWidget(lbl)
                row.addStretch()
                row.addWidget(combo)
                tf.addLayout(row)
                self._rows.append((tool, combo))
        else:
            tf.addWidget(QLabel("No MCP tools configured."))

        layout.addWidget(tools_frame)

        btns = QHBoxLayout()
        save_btn = QPushButton("Save")
        save_btn.setObjectName("primaryBtn")
        save_btn.clicked.connect(self._save)
        close = QPushButton("Close")
        close.clicked.connect(self.accept)
        btns.addWidget(save_btn)
        btns.addStretch()
        btns.addWidget(close)
        layout.addLayout(btns)

    def _save(self):
        try:
            mcp = getattr(self.engine, "mcp", None)
            if mcp and hasattr(mcp, "set_permission"):
                for tool, combo in self._rows:
                    mcp.set_permission(tool, combo.currentText())
            self.accept()
        except Exception as exc:
            QMessageBox.warning(self, "Error", str(exc))


# ── Workflows Dialog ──────────────────────────────────────────────────────────

class WorkflowsDialog(QDialog):
    def __init__(self, engine, parent=None):
        super().__init__(parent)
        self.engine = engine
        self.setWindowTitle("Workflows")
        self.setMinimumWidth(460)
        self.setMinimumHeight(360)
        self.setModal(True)
        self._build_ui()

    def _build_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(20, 20, 20, 20)
        layout.setSpacing(12)

        title = QLabel("Workflows")
        title.setStyleSheet("font-size: 16px; font-weight: 700;")
        layout.addWidget(title)

        self._wf_list = QListWidget()
        self._wf_list.setMinimumHeight(160)
        self._wf_list.setStyleSheet(
            "QListWidget { background: #141414; border: 1px solid #2e2e2e; border-radius: 6px; }"
            "QListWidget::item { color: #e2e8f0; padding: 8px 12px; }"
            "QListWidget::item:selected { background: #1e3a5f; }"
        )
        layout.addWidget(self._wf_list)

        try:
            wfs = (
                self.engine.get_workflows()
                if hasattr(self.engine, "get_workflows")
                else []
            )
            for wf in wfs:
                self._wf_list.addItem(QListWidgetItem(str(wf)))
            if not wfs:
                self._wf_list.addItem(QListWidgetItem("No workflows defined."))
        except Exception as exc:
            self._wf_list.addItem(QListWidgetItem(f"Error: {exc}"))

        run_btn = QPushButton("Run Selected Workflow")
        run_btn.setObjectName("primaryBtn")
        run_btn.clicked.connect(self._run)
        layout.addWidget(run_btn)

        self._result = QTextEdit()
        self._result.setReadOnly(True)
        self._result.setPlaceholderText("Workflow output will appear here…")
        self._result.setMaximumHeight(120)
        layout.addWidget(self._result)

        close = QPushButton("Close")
        close.clicked.connect(self.accept)
        layout.addWidget(close, alignment=Qt.AlignmentFlag.AlignRight)

    def _run(self):
        item = self._wf_list.currentItem()
        if not item:
            return
        name = item.text().strip()
        try:
            result = (
                self.engine.run_workflow(name)
                if hasattr(self.engine, "run_workflow")
                else "Workflow execution not implemented."
            )
            self._result.setPlainText(str(result))
        except Exception as exc:
            self._result.setPlainText(f"Error: {exc}")


# ── Stats Dialog ──────────────────────────────────────────────────────────────

class StatsDialog(QDialog):
    def __init__(self, engine, parent=None):
        super().__init__(parent)
        self.engine = engine
        self.setWindowTitle("Session Statistics")
        self.setMinimumWidth(460)
        self.setMinimumHeight(340)
        self.setModal(True)
        self._build_ui()

    def _build_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(20, 20, 20, 20)
        layout.setSpacing(12)

        title = QLabel("Session Statistics")
        title.setStyleSheet("font-size: 16px; font-weight: 700;")
        layout.addWidget(title)

        self._stats_box = QTextEdit()
        self._stats_box.setReadOnly(True)
        layout.addWidget(self._stats_box)

        try:
            if hasattr(self.engine, "get_stats"):
                stats = self.engine.get_stats()
                self._stats_box.setPlainText(json.dumps(stats, indent=2))
            else:
                # Build basic stats from what we know
                lines = []
                if hasattr(self.engine, "conversation_store"):
                    cs = self.engine.conversation_store
                    convs = cs.list_conversations(limit=1000) if hasattr(cs, "list_conversations") else []
                    lines.append(f"Total conversations : {len(convs)}")
                if hasattr(self.engine, "router") and self.engine.router:
                    rc = self.engine.router.cache
                    lines.append(f"Routing decisions   : {rc.decision_count()}")
                    lines.append(f"Gravity wells       : {rc.well_count(active_only=True)} active")
                lines.append(f"\nModel : {self.engine.config.model_filename}")
                lines.append(f"Threads : {self.engine.config.threads}")
                lines.append(f"GPU layers : {self.engine.config.gpu_layers}")
                self._stats_box.setPlainText("\n".join(lines))
        except Exception as exc:
            self._stats_box.setPlainText(f"Error loading stats:\n{exc}")

        close = QPushButton("Close")
        close.clicked.connect(self.accept)
        layout.addWidget(close, alignment=Qt.AlignmentFlag.AlignRight)


# ── About Dialog ──────────────────────────────────────────────────────────────

class AboutDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("About zdxai")
        self.setFixedSize(400, 340)
        self.setModal(True)
        self._build_ui()

    def _build_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(32, 36, 32, 32)
        layout.setSpacing(10)
        layout.setAlignment(Qt.AlignmentFlag.AlignCenter)

        name = QLabel("zdxai")
        name.setStyleSheet(
            "font-size: 32px; font-weight: 800; color: #3b82f6; letter-spacing: -1px;"
        )
        name.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(name)

        ver = QLabel("Version 0.1.0")
        ver.setStyleSheet("color: #64748b; font-size: 13px;")
        ver.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(ver)

        sep = QFrame()
        sep.setFrameShape(QFrame.Shape.HLine)
        sep.setStyleSheet("background: #2e2e2e; max-height: 1px; margin: 8px 0;")
        layout.addWidget(sep)

        desc = QLabel(
            "Private local AI assistant.\n"
            "Runs entirely on your device — no cloud, no data leaks.\n\n"
            "Powered by GGUF models via llama.cpp.\n"
            "Features RAG, LoRA fine-tuning, MCP tools,\n"
            "and Embedding Gravity Wells routing."
        )
        desc.setStyleSheet("color: #94a3b8; font-size: 12px; line-height: 1.6;")
        desc.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(desc)

        layout.addStretch()

        copy = QLabel("© 2025 ZeroDriveX. All rights reserved.")
        copy.setStyleSheet("color: #475569; font-size: 11px;")
        copy.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(copy)

        close = QPushButton("Close")
        close.setFixedWidth(100)
        close.clicked.connect(self.accept)
        layout.addWidget(close, alignment=Qt.AlignmentFlag.AlignCenter)


# ── Message Bubble ────────────────────────────────────────────────────────────

class MessageBubble(QFrame):
    """A single chat message row."""

    def __init__(self, role: str, content: str, parent=None):
        super().__init__(parent)
        self.role = role
        layout = QHBoxLayout(self)
        layout.setContentsMargins(20, 4, 20, 4)
        layout.setSpacing(10)

        if role == "user":
            layout.addStretch()
            self._text = self._make_text(content, "#1e3a5f", "#93c5fd")
            layout.addWidget(self._text)
        else:
            avatar = QLabel("Z")
            avatar.setFixedSize(30, 30)
            avatar.setAlignment(Qt.AlignmentFlag.AlignCenter)
            avatar.setStyleSheet(
                "background: #3b82f6; color: white; border-radius: 15px;"
                "font-weight: 700; font-size: 13px;"
            )
            layout.addWidget(avatar, alignment=Qt.AlignmentFlag.AlignTop)
            self._text = self._make_text(content, "#1a1a1a", "#e2e8f0")
            layout.addWidget(self._text)
            layout.addStretch()

    def _make_text(self, content: str, bg: str, fg: str) -> QTextEdit:
        w = QTextEdit()
        w.setReadOnly(True)
        w.setPlainText(content)
        w.setStyleSheet(f"""
            QTextEdit {{
                background: {bg};
                color: {fg};
                border: none;
                border-radius: 12px;
                padding: 10px 14px;
                font-size: 13px;
            }}
        """)
        w.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        w.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        w.setMaximumWidth(640)
        self._resize_text(w)
        return w

    def _resize_text(self, w: QTextEdit):
        w.document().adjustSize()
        h = int(w.document().size().height()) + 24
        w.setFixedHeight(max(h, 44))

    def update_content(self, content: str):
        self._text.setPlainText(content)
        self._resize_text(self._text)


# ── Main Window ───────────────────────────────────────────────────────────────

class ZdxAIWindow(QMainWindow):
    def __init__(self, config):
        super().__init__()
        self.config  = config
        self.engine  = None
        self._streaming_bubble: Optional[MessageBubble] = None
        self._streaming_text   = ""

        self.setWindowTitle("zdxai — Local AI Assistant")
        self.setMinimumSize(1024, 680)
        self.resize(1280, 820)

        self._build_ui()
        self._build_menu()
        self._build_statusbar()
        self._start_engine()

    # ── Build UI ──────────────────────────────────────────────────────────────

    def _build_ui(self):
        central = QWidget()
        self.setCentralWidget(central)
        root = QHBoxLayout(central)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)

        splitter = QSplitter(Qt.Orientation.Horizontal)
        root.addWidget(splitter)

        # ── Sidebar ────────────────────────────────────────────────────────
        sidebar = QWidget()
        sidebar.setFixedWidth(248)
        sidebar.setStyleSheet("background: #080808; border-right: 1px solid #1a1a1a;")
        sb_l = QVBoxLayout(sidebar)
        sb_l.setContentsMargins(12, 16, 12, 16)
        sb_l.setSpacing(8)

        brand = QLabel("zdxai")
        brand.setStyleSheet(
            "font-size: 22px; font-weight: 800; color: #3b82f6;"
            "letter-spacing: -0.5px; padding: 0 4px 8px 4px;"
        )
        sb_l.addWidget(brand)

        new_btn = QPushButton("+ New Chat")
        new_btn.setObjectName("primaryBtn")
        new_btn.setFixedHeight(36)
        new_btn.clicked.connect(self._new_conversation)
        sb_l.addWidget(new_btn)

        conv_hdr = QLabel("CONVERSATIONS")
        conv_hdr.setStyleSheet(
            "color: #374151; font-size: 10px; font-weight: 700;"
            "letter-spacing: 1px; padding: 10px 4px 4px 4px;"
        )
        sb_l.addWidget(conv_hdr)

        self.conv_list = QListWidget()
        self.conv_list.itemClicked.connect(self._switch_conversation)
        sb_l.addWidget(self.conv_list)
        sb_l.addStretch()

        self._sb_license_lbl = QLabel("● No license")
        self._sb_license_lbl.setStyleSheet(
            "color: #374151; font-size: 11px; padding: 4px;"
        )
        sb_l.addWidget(self._sb_license_lbl)

        splitter.addWidget(sidebar)

        # ── Chat area ──────────────────────────────────────────────────────
        chat_area = QWidget()
        chat_area.setStyleSheet("background: #0f0f0f;")
        cv = QVBoxLayout(chat_area)
        cv.setContentsMargins(0, 0, 0, 0)
        cv.setSpacing(0)

        # Header bar
        header = QWidget()
        header.setFixedHeight(52)
        header.setStyleSheet("background: #080808; border-bottom: 1px solid #1a1a1a;")
        hl = QHBoxLayout(header)
        hl.setContentsMargins(20, 0, 20, 0)
        self._chat_title = QLabel("New Conversation")
        self._chat_title.setStyleSheet("font-size: 14px; font-weight: 600; color: #e2e8f0;")
        self._model_tag = QLabel("")
        self._model_tag.setStyleSheet(
            "background: #141414; color: #64748b; border-radius: 10px;"
            "padding: 2px 10px; font-size: 11px; border: 1px solid #1e1e1e;"
        )
        hl.addWidget(self._chat_title)
        hl.addStretch()
        hl.addWidget(self._model_tag)
        cv.addWidget(header)

        # Scroll / messages
        self._scroll = QScrollArea()
        self._scroll.setWidgetResizable(True)
        self._scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self._scroll.setStyleSheet("QScrollArea { border: none; background: #0f0f0f; }")
        self._scroll.verticalScrollBar().setStyleSheet("""
            QScrollBar:vertical { background: transparent; width: 6px; }
            QScrollBar::handle:vertical { background: #2e2e2e; border-radius: 3px; min-height: 20px; }
            QScrollBar::handle:vertical:hover { background: #3b82f6; }
            QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical { height: 0; }
        """)
        self._msg_widget = QWidget()
        self._msg_widget.setStyleSheet("background: #0f0f0f;")
        self._msg_layout = QVBoxLayout(self._msg_widget)
        self._msg_layout.setContentsMargins(0, 20, 0, 20)
        self._msg_layout.setSpacing(4)
        self._msg_layout.addStretch()
        self._scroll.setWidget(self._msg_widget)
        cv.addWidget(self._scroll)

        # Input row
        input_bar = QWidget()
        input_bar.setFixedHeight(88)
        input_bar.setStyleSheet("background: #080808; border-top: 1px solid #1a1a1a;")
        ib_l = QHBoxLayout(input_bar)
        ib_l.setContentsMargins(16, 14, 16, 14)
        ib_l.setSpacing(10)

        self._input = QTextEdit()
        self._input.setFixedHeight(60)
        self._input.setPlaceholderText(
            "Message zdxai…   (Enter to send · Shift+Enter for new line)"
        )
        self._input.setStyleSheet("""
            QTextEdit {
                background: #141414;
                color: #e2e8f0;
                border: 1px solid #2e2e2e;
                border-radius: 10px;
                padding: 10px 14px;
                font-size: 13px;
            }
            QTextEdit:focus { border-color: #3b82f6; }
        """)
        self._input.installEventFilter(self)

        self._send_btn = QPushButton("Send")
        self._send_btn.setObjectName("primaryBtn")
        self._send_btn.setFixedSize(72, 60)
        self._send_btn.setStyleSheet("""
            QPushButton#primaryBtn {
                background: #3b82f6; color: white; border: none;
                border-radius: 10px; font-weight: 600; font-size: 13px;
            }
            QPushButton#primaryBtn:hover { background: #2563eb; }
            QPushButton#primaryBtn:disabled { background: #1e3a5f; color: #475569; }
        """)
        self._send_btn.clicked.connect(self._send_message)

        ib_l.addWidget(self._input)
        ib_l.addWidget(self._send_btn)
        cv.addWidget(input_bar)

        splitter.addWidget(chat_area)
        splitter.setSizes([248, 1032])

    # ── Menu ──────────────────────────────────────────────────────────────────

    def _build_menu(self):
        mb = self.menuBar()

        # File
        file_m = mb.addMenu("File")
        file_m.addAction(self._act("New Chat", self._new_conversation, "Ctrl+N"))
        file_m.addSeparator()
        file_m.addAction(self._act("Settings…", self._open_settings, "Ctrl+,"))
        file_m.addSeparator()
        file_m.addAction(self._act("Exit", self.close, "Ctrl+Q"))

        # Training
        train_m = mb.addMenu("Training")
        train_m.addAction(self._act("Train from Conversations…", self._open_train_conv))
        train_m.addAction(self._act("Train from Documents…",     self._open_train_docs))
        train_m.addAction(self._act("Train from File…",           self._open_train_file))
        train_m.addSeparator()
        train_m.addAction(self._act("Manage Adapters…", self._open_adapters))

        # Documents
        docs_m = mb.addMenu("Documents")
        docs_m.addAction(self._act("Ingest Document…",     lambda: self._open_docs(0)))
        docs_m.addAction(self._act("Search Memory…",       lambda: self._open_docs(1)))
        docs_m.addAction(self._act("List Documents",       lambda: self._open_docs(2)))

        # Tools
        tools_m = mb.addMenu("Tools")
        tools_m.addAction(self._act("MCP Permissions…", self._open_permissions))
        tools_m.addAction(self._act("Workflows…",       self._open_workflows))
        tools_m.addSeparator()
        tools_m.addAction(self._act("Session Stats",    self._open_stats))

        # License
        lic_m = mb.addMenu("License")
        lic_m.addAction(self._act("Account & License…",  self._open_license))
        lic_m.addAction(self._act("Purchase License…",   self._purchase_license))
        lic_m.addSeparator()
        lic_m.addAction(self._act("Deactivate License",  self._deactivate_license))

        # Help
        help_m = mb.addMenu("Help")
        help_m.addAction(self._act("About zdxai", self._open_about))

    def _act(self, text: str, slot, shortcut: Optional[str] = None) -> QAction:
        a = QAction(text, self)
        a.triggered.connect(slot)
        if shortcut:
            a.setShortcut(QKeySequence(shortcut))
        return a

    # ── Status bar ────────────────────────────────────────────────────────────

    def _build_statusbar(self):
        sb = QStatusBar()
        self.setStatusBar(sb)
        sb.setStyleSheet(
            "QStatusBar { background: #080808; color: #374151; "
            "border-top: 1px solid #1a1a1a; font-size: 12px; }"
            "QStatusBar::item { border: none; }"
        )
        self._sb_model   = QLabel("Model: —")
        self._sb_adapter = QLabel("")
        self._sb_lic     = QLabel("License: —")
        self._sb_state   = QLabel("Starting…")
        sb.addWidget(self._sb_model)
        sb.addWidget(_sep_label())
        sb.addWidget(self._sb_adapter)
        sb.addPermanentWidget(self._sb_lic)
        sb.addPermanentWidget(_sep_label())
        sb.addPermanentWidget(self._sb_state)

    # ── Engine startup ────────────────────────────────────────────────────────

    def _start_engine(self):
        self._send_btn.setEnabled(False)
        self._sb_state.setText("Starting…")
        self._sb_state.setStyleSheet("color: #f59e0b; font-size: 12px;")
        self._startup = EngineStartupThread(self.config)
        self._startup.status.connect(lambda s: self._sb_state.setText(s))
        self._startup.finished.connect(self._on_engine_ready)
        self._startup.start()

    def _on_engine_ready(self, success: bool, err: str):
        if success:
            self.engine = self._startup.engine
            self._sb_state.setText("Ready")
            self._sb_state.setStyleSheet("color: #22c55e; font-size: 12px;")
            fname = getattr(self.config, "model_filename", "")
            self._sb_model.setText(f"Model: {fname}")
            self._model_tag.setText(fname.split("-")[0] if fname else "")
            self._send_btn.setEnabled(True)
            self._load_conversations()
            self._refresh_license_ui()
        else:
            self._sb_state.setText("Engine failed")
            self._sb_state.setStyleSheet("color: #ef4444; font-size: 12px;")
            QMessageBox.critical(
                self, "Startup Error",
                f"Failed to start engine:\n\n{err}\n\n"
                "Ensure model files are downloaded (zdxai --download-models).",
            )

    def _refresh_license_ui(self):
        try:
            from zdxai.licensing import verify_license, LicenseError
            info = verify_license(self.config.data_dir)
            tier  = getattr(info, "tier",  "unknown").upper()
            email = getattr(info, "email", "")
            self._sb_lic.setText(f"License: {tier}")
            self._sb_lic.setStyleSheet("color: #22c55e; font-size: 12px;")
            self._sb_license_lbl.setText(f"● {email or tier}")
            self._sb_license_lbl.setStyleSheet("color: #22c55e; font-size: 11px; padding: 4px;")
        except Exception:
            self._sb_lic.setText("License: Inactive")
            self._sb_lic.setStyleSheet("color: #ef4444; font-size: 12px;")
            self._sb_license_lbl.setText("● No license")
            self._sb_license_lbl.setStyleSheet("color: #475569; font-size: 11px; padding: 4px;")

    # ── Conversations ─────────────────────────────────────────────────────────

    def _load_conversations(self):
        if not self.engine:
            return
        self.conv_list.clear()
        try:
            cs = getattr(self.engine, "conversation_store", None)
            convs = cs.list_conversations(limit=30) if cs else []
            for c in convs:
                cid   = c.get("id", "")
                title = c.get("title", "") or cid[:10]
                item  = QListWidgetItem(title)
                item.setData(Qt.ItemDataRole.UserRole, cid)
                self.conv_list.addItem(item)
        except Exception:
            pass

    def _new_conversation(self):
        if not self.engine:
            return
        try:
            self.engine.new_conversation()
            self._clear_messages()
            self._chat_title.setText("New Conversation")
            self._load_conversations()
        except Exception as exc:
            self._sb_state.setText(f"Error: {exc}")

    def _switch_conversation(self, item: QListWidgetItem):
        if not self.engine:
            return
        cid = item.data(Qt.ItemDataRole.UserRole)
        if not cid:
            return
        try:
            cs = getattr(self.engine, "conversation_store", None)
            if cs:
                cs.switch_conversation(cid)
                self._clear_messages()
                msgs = cs.get_messages(cid)
                for m in msgs:
                    self._add_bubble(m.get("role", "user"), m.get("content", ""))
            self._chat_title.setText(item.text())
        except Exception as exc:
            self._sb_state.setText(f"Error: {exc}")

    def _clear_messages(self):
        while self._msg_layout.count() > 1:
            w = self._msg_layout.takeAt(0).widget()
            if w:
                w.deleteLater()

    # ── Chat ──────────────────────────────────────────────────────────────────

    def eventFilter(self, obj: QObject, event) -> bool:
        if obj is self._input and event.type() == QEvent.Type.KeyPress:
            if (
                event.key() == Qt.Key.Key_Return
                and not (event.modifiers() & Qt.KeyboardModifier.ShiftModifier)
            ):
                self._send_message()
                return True
        return super().eventFilter(obj, event)

    def _send_message(self):
        if not self.engine:
            return
        text = self._input.toPlainText().strip()
        if not text:
            return
        self._input.clear()
        self._send_btn.setEnabled(False)
        self._sb_state.setText("Thinking…")
        self._sb_state.setStyleSheet("color: #f59e0b; font-size: 12px;")

        self._add_bubble("user", text)

        self._streaming_text   = ""
        self._streaming_bubble = MessageBubble("assistant", "▋")
        self._msg_layout.insertWidget(
            self._msg_layout.count() - 1, self._streaming_bubble
        )
        self._scroll_bottom()

        self._chat_thread = ChatThread(self.engine, text)
        self._chat_thread.token.connect(self._on_token)
        self._chat_thread.finished.connect(self._on_chat_done)
        self._chat_thread.error.connect(self._on_chat_error)
        self._chat_thread.start()

    def _on_token(self, tok: str):
        self._streaming_text += tok
        if self._streaming_bubble:
            self._streaming_bubble.update_content(self._streaming_text + "▋")
        self._scroll_bottom()

    def _on_chat_done(self, _full: str):
        if self._streaming_bubble:
            self._streaming_bubble.update_content(self._streaming_text)
        self._streaming_bubble = None
        self._streaming_text   = ""
        self._send_btn.setEnabled(True)
        self._sb_state.setText("Ready")
        self._sb_state.setStyleSheet("color: #22c55e; font-size: 12px;")
        self._load_conversations()

    def _on_chat_error(self, err: str):
        if self._streaming_bubble:
            self._streaming_bubble.update_content(f"Error: {err}")
        self._streaming_bubble = None
        self._send_btn.setEnabled(True)
        self._sb_state.setText("Error")
        self._sb_state.setStyleSheet("color: #ef4444; font-size: 12px;")

    def _add_bubble(self, role: str, content: str):
        bubble = MessageBubble(role, content)
        self._msg_layout.insertWidget(self._msg_layout.count() - 1, bubble)
        self._scroll_bottom()

    def _scroll_bottom(self):
        QTimer.singleShot(
            50,
            lambda: self._scroll.verticalScrollBar().setValue(
                self._scroll.verticalScrollBar().maximum()
            ),
        )

    # ── Menu handlers ─────────────────────────────────────────────────────────

    def _open_settings(self):
        SettingsDialog(self.config, self).exec()

    def _open_train_conv(self):
        if not self._require_engine(): return
        TrainingDialog(self.engine, start_tab=0, parent=self).exec()

    def _open_train_docs(self):
        if not self._require_engine(): return
        TrainingDialog(self.engine, start_tab=1, parent=self).exec()

    def _open_train_file(self):
        if not self._require_engine(): return
        TrainingDialog(self.engine, start_tab=2, parent=self).exec()

    def _open_adapters(self):
        if not self._require_engine(): return
        AdaptersDialog(self.engine, self).exec()
        ap = getattr(self.engine.config, "adapter_path", None)
        self._sb_adapter.setText(f"Adapter: {Path(ap).name}" if ap else "")

    def _open_docs(self, tab: int = 0):
        if not self._require_engine(): return
        DocumentsDialog(self.engine, start_tab=tab, parent=self).exec()

    def _open_permissions(self):
        if not self._require_engine(): return
        PermissionsDialog(self.engine, self).exec()

    def _open_workflows(self):
        if not self._require_engine(): return
        WorkflowsDialog(self.engine, self).exec()

    def _open_stats(self):
        if not self._require_engine(): return
        StatsDialog(self.engine, self).exec()

    def _open_license(self):
        dlg = LicenseDialog(self.config, self)
        dlg.activated.connect(self._on_license_activated)
        dlg.exec()

    def _on_license_activated(self, info: dict):
        tier  = info.get("tier", "").upper()
        email = info.get("email", "")
        self._sb_lic.setText(f"License: {tier}")
        self._sb_lic.setStyleSheet("color: #22c55e; font-size: 12px;")
        self._sb_license_lbl.setText(f"● {email or tier}")
        self._sb_license_lbl.setStyleSheet("color: #22c55e; font-size: 11px; padding: 4px;")

    def _purchase_license(self):
        from zdxai.licensing import purchase_license
        purchase_license()

    def _deactivate_license(self):
        if QMessageBox.question(
            self, "Deactivate License",
            "Are you sure you want to deactivate your license?",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
        ) == QMessageBox.StandardButton.Yes:
            try:
                from zdxai.licensing import deactivate
                deactivate(self.config.data_dir)
                self._sb_lic.setText("License: Inactive")
                self._sb_lic.setStyleSheet("color: #ef4444; font-size: 12px;")
                self._sb_license_lbl.setText("● No license")
                self._sb_license_lbl.setStyleSheet("color: #475569; font-size: 11px; padding: 4px;")
            except Exception as exc:
                QMessageBox.warning(self, "Error", str(exc))

    def _open_about(self):
        AboutDialog(self).exec()

    # ── Utilities ─────────────────────────────────────────────────────────────

    def _require_engine(self) -> bool:
        if not self.engine:
            QMessageBox.information(
                self, "Not Ready", "The AI engine is still loading. Please wait."
            )
            return False
        return True

    def closeEvent(self, event):
        if self.engine:
            try:
                self.engine.shutdown()
            except Exception:
                pass
        super().closeEvent(event)


# ── Entry point ───────────────────────────────────────────────────────────────

def run_gui(config=None):
    app = QApplication(sys.argv)
    app.setApplicationName("zdxai")
    app.setOrganizationName("ZeroDriveX")
    app.setStyle("Fusion")
    app.setStyleSheet(STYLESHEET)

    if config is None:
        from zdxai.config import Config
        config = Config()

    win = ZdxAIWindow(config)
    win.show()
    sys.exit(app.exec())


if __name__ == "__main__":
    run_gui()
