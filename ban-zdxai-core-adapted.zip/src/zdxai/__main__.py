"""Entry point for zdxai: python -m zdxai"""

from __future__ import annotations

import argparse
import logging
import sys
from pathlib import Path

from zdxai.config import Config
from zdxai.constants import APP_VERSION


def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        prog="zdxai",
        description="Local, on-device AI assistant",
    )
    parser.add_argument(
        "--version", action="version", version=f"zdxai {APP_VERSION}"
    )
    parser.add_argument(
        "--base-dir",
        type=Path,
        default=None,
        help="Override base data directory (default: ~/.zdxai or platform-specific)",
    )
    parser.add_argument(
        "--model",
        type=str,
        default=None,
        help="Model GGUF filename to use",
    )
    parser.add_argument(
        "--threads",
        type=int,
        default=None,
        help="Number of CPU threads for inference",
    )
    parser.add_argument(
        "--gpu-layers",
        type=int,
        default=0,
        help="Number of layers to offload to GPU",
    )
    parser.add_argument(
        "--context-length",
        type=int,
        default=None,
        help="Context window size in tokens",
    )
    parser.add_argument(
        "--web",
        action="store_true",
        help="Launch web UI instead of CLI",
    )
    parser.add_argument(
        "--port",
        type=int,
        default=8392,
        help="Port for web UI (default: 8392)",
    )
    parser.add_argument(
        "--adapter",
        type=str,
        default=None,
        help="LoRA adapter name to activate on startup",
    )
    parser.add_argument(
        "--verbose", "-v",
        action="store_true",
        help="Enable debug logging",
    )
    parser.add_argument(
        "--activate",
        action="store_true",
        help="Activate license (prompts for email/password)",
    )
    parser.add_argument(
        "--deactivate",
        action="store_true",
        help="Remove stored license",
    )
    parser.add_argument(
        "--purchase",
        action="store_true",
        help="Open browser to purchase a zdxai license",
    )
    parser.add_argument(
        "--gui",
        action="store_true",
        help="Launch desktop GUI (requires PyQt6)",
    )
    return parser.parse_args(argv)


def build_config(args: argparse.Namespace) -> Config:
    """Build Config from CLI arguments + defaults."""
    from zdxai.platform.paths import get_base_dir

    kwargs = {}

    if args.base_dir:
        kwargs["base_dir"] = args.base_dir
    else:
        kwargs["base_dir"] = get_base_dir()

    if args.model:
        kwargs["model_filename"] = args.model
    if args.threads:
        kwargs["threads"] = args.threads
    if args.gpu_layers:
        kwargs["gpu_layers"] = args.gpu_layers
    if args.context_length:
        kwargs["context_length"] = args.context_length
    if args.port:
        kwargs["web_port"] = args.port

    return Config(**kwargs)


def main(argv: list[str] | None = None) -> None:
    args = parse_args(argv)

    # Setup logging
    level = logging.DEBUG if args.verbose else logging.WARNING
    logging.basicConfig(
        level=level,
        format="%(asctime)s %(name)s %(levelname)s %(message)s",
        datefmt="%H:%M:%S",
    )

    config = build_config(args)

    # --- License management ---
    from zdxai.licensing import activate, deactivate, verify_license, purchase_license, LicenseError

    if args.purchase:
        purchase_license()
        sys.exit(0)

    if args.activate:
        try:
            info = activate(config.data_dir)
            print(f"License activated for {info.email} (tier: {info.tier}).")
        except LicenseError as exc:
            print(f"Activation failed: {exc}")
            sys.exit(1)
        return

    if args.deactivate:
        deactivate(config.data_dir)
        print("License deactivated.")
        return

    # Verify license before any engine startup
    try:
        license_info = verify_license(config.data_dir)
        logging.getLogger(__name__).info(
            "License OK — %s (%s)", license_info.email, license_info.tier
        )
    except LicenseError as exc:
        print(f"License error: {exc}")
        sys.exit(1)

    # Resolve adapter name to path if provided
    if args.adapter:
        adapter_dir = config.adapters_dir / args.adapter
        if adapter_dir.is_dir():
            # Check for GGUF file first, then use directory
            gguf_files = list(adapter_dir.glob("*.gguf"))
            config.adapter_path = str(gguf_files[0]) if gguf_files else str(adapter_dir)
            logging.getLogger(__name__).info("Adapter '%s' set from CLI.", args.adapter)
        else:
            print(f"Warning: Adapter '{args.adapter}' not found at {adapter_dir}")

    if args.gui:
        _run_gui(config)
    elif args.web:
        _run_web(config)
    else:
        _run_cli(config)


def _run_gui(config: Config) -> None:
    try:
        from PyQt6.QtWidgets import QApplication  # noqa: F401
    except ImportError:
        print("Desktop GUI requires PyQt6. Install with: pip install 'zdxai[gui]'")
        sys.exit(1)

    from zdxai.gui.app import run_gui
    run_gui(config)


def _run_cli(config: Config) -> None:
    from zdxai.cli.app import CLIApp
    app = CLIApp(config)
    app.run()


def _run_web(config: Config) -> None:
    try:
        import uvicorn
    except ImportError:
        print("Web UI requires uvicorn. Install with: pip install 'zdxai[web]'")
        sys.exit(1)

    from zdxai.core.engine import Engine
    from zdxai.web.app import create_app

    engine = Engine(config)
    engine.startup()
    engine.new_conversation()

    app = create_app(engine)

    url = f"http://{config.web_host}:{config.web_port}"
    print(f"zdxai Web UI → {url}")

    try:
        uvicorn.run(app, host=config.web_host, port=config.web_port, log_level="warning")
    finally:
        engine.shutdown()


if __name__ == "__main__":
    main()
