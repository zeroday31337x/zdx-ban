"""Interactive CLI REPL for zdxai using prompt_toolkit + rich."""

from __future__ import annotations

import logging
import sys

from prompt_toolkit import PromptSession
from prompt_toolkit.history import FileHistory
from prompt_toolkit.auto_suggest import AutoSuggestFromHistory

from zdxai.cli.commands import handle_command
from zdxai.cli.formatter import (
    console,
    print_error,
    print_info,
    print_response,
    print_stats,
    print_streaming_end,
    print_streaming_token,
    print_warning,
    print_welcome,
)
from zdxai.config import Config
from zdxai.core.engine import Engine

log = logging.getLogger(__name__)


class CLIApp:
    """Interactive terminal chat application."""

    def __init__(self, config: Config) -> None:
        self.config = config
        self.engine = Engine(config)
        self._streaming = True

    def run(self) -> None:
        """Main REPL loop."""
        print_welcome()

        # Initialize engine
        try:
            self.engine.startup()
        except Exception as e:
            print_error(f"Failed to start engine: {e}")
            log.exception("Startup failed")
            sys.exit(1)

        if not self.engine.inference.is_loaded:
            print_warning(
                f"Model not found at {self.config.model_path}\n"
                "  Run: python -m zdxai.scripts.download_models"
            )
            sys.exit(1)

        # Start first conversation
        self.engine.new_conversation()

        # Setup prompt session with history
        history_path = self.config.data_dir / "cli_history"
        session: PromptSession = PromptSession(
            history=FileHistory(str(history_path)),
            auto_suggest=AutoSuggestFromHistory(),
        )

        print_info("Ready. Type your message or /help for commands.\n")

        try:
            self._loop(session)
        except (KeyboardInterrupt, EOFError):
            pass
        finally:
            self.engine.shutdown()
            print_info("Goodbye.")

    def _loop(self, session: PromptSession) -> None:
        """Main input loop."""
        while True:
            try:
                user_input = session.prompt("You: ").strip()
            except KeyboardInterrupt:
                continue
            except EOFError:
                break

            if not user_input:
                continue

            # Handle slash commands
            if user_input.startswith("/"):
                try:
                    handle_command(self.engine, user_input)
                except SystemExit:
                    break
                continue

            # Chat
            try:
                if self._streaming:
                    self._handle_streaming(user_input)
                else:
                    self._handle_blocking(user_input)
            except Exception as e:
                print_error(str(e))
                log.exception("Chat error")

            console.print()  # blank line between turns

    def _handle_streaming(self, user_input: str) -> None:
        """Handle a chat turn with streaming output."""
        console.print("[bold]zdxai:[/bold] ", end="")
        token_count = 0
        for token in self.engine.chat_stream(user_input):
            print_streaming_token(token)
            token_count += 1
        print_streaming_end()

    def _handle_blocking(self, user_input: str) -> None:
        """Handle a chat turn with blocking output."""
        response = self.engine.chat(user_input)
        console.print("[bold]zdxai:[/bold]")
        print_response(response.content)
        print_stats(
            response.tokens_prompt,
            response.tokens_completion,
            response.latency_ms,
        )
