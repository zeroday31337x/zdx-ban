"""Markdown rendering and output formatting for the CLI."""

from __future__ import annotations

from rich.console import Console
from rich.markdown import Markdown
from rich.panel import Panel
from rich.text import Text

console = Console()


def print_welcome() -> None:
    """Print the welcome banner."""
    console.print(
        Panel(
            "[bold cyan]zdxai[/bold cyan] — Local AI Assistant\n"
            "Type your message and press Enter. Use /help for commands.",
            border_style="cyan",
        )
    )


def print_response(text: str) -> None:
    """Render assistant response as markdown."""
    md = Markdown(text)
    console.print(md)


def print_streaming_token(token: str) -> None:
    """Print a single token without newline (for streaming)."""
    console.print(token, end="", highlight=False)


def print_streaming_end() -> None:
    """Finalize streaming output."""
    console.print()  # newline


def print_info(msg: str) -> None:
    console.print(f"[dim]{msg}[/dim]")


def print_error(msg: str) -> None:
    console.print(f"[bold red]Error:[/bold red] {msg}")


def print_warning(msg: str) -> None:
    console.print(f"[yellow]Warning:[/yellow] {msg}")


def print_success(msg: str) -> None:
    console.print(f"[green]{msg}[/green]")


def print_conversation_list(conversations: list) -> None:
    """Print a list of conversations."""
    if not conversations:
        print_info("No conversations yet.")
        return

    for i, conv in enumerate(conversations, 1):
        title = conv.title or "(untitled)"
        count = conv.message_count
        date = conv.updated_at[:10] if conv.updated_at else "?"
        console.print(
            f"  [cyan]{i}.[/cyan] {title} "
            f"[dim]({count} msgs, {date})[/dim] "
            f"[dim italic]{conv.id[:8]}[/dim italic]"
        )


def print_stats(tokens_prompt: int, tokens_completion: int, latency_ms: int) -> None:
    console.print(
        f"[dim]({tokens_prompt}+{tokens_completion} tokens, {latency_ms}ms)[/dim]"
    )
