"""Slash command handlers for the CLI."""

from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING

from zdxai.cli.formatter import (
    console,
    print_conversation_list,
    print_error,
    print_info,
    print_success,
    print_warning,
)

if TYPE_CHECKING:
    from zdxai.core.engine import Engine


HELP_TEXT = """\
[bold cyan]Available Commands:[/bold cyan]
  /new              Start a new conversation
  /history          List recent conversations
  /resume <id>      Resume a conversation by ID prefix
  /ingest <path>    Ingest a document for RAG
  /memory <query>   Search RAG memory
  /docs             List ingested documents
  /stats            Show current session stats

  [bold cyan]Training:[/bold cyan]
  /train <name>           Train a LoRA adapter from conversations
  /train-doc <name>       Train from ingested documents
  /train-file <name> <p>  Train from a JSONL file
  /adapters               List available adapters
  /adapter <name>         Activate an adapter
  /adapter-off            Deactivate current adapter

  [bold cyan]Workflows & Permissions:[/bold cyan]
  /workflows              List available workflows
  /workflow <name>        Run a workflow
  /permissions            List tool permissions
  /permit <tool> <perm>   Set tool permission (allow/deny/ask)

  /help             Show this help message
  /quit             Exit zdxai
"""


def handle_command(engine: Engine, command: str) -> bool:
    """Handle a slash command. Returns True if the input was a command."""
    parts = command.strip().split(maxsplit=1)
    cmd = parts[0].lower()
    arg = parts[1] if len(parts) > 1 else ""

    handlers = {
        "/new": lambda: _cmd_new(engine),
        "/history": lambda: _cmd_history(engine),
        "/resume": lambda: _cmd_resume(engine, arg),
        "/ingest": lambda: _cmd_ingest(engine, arg),
        "/memory": lambda: _cmd_memory(engine, arg),
        "/docs": lambda: _cmd_docs(engine),
        "/stats": lambda: _cmd_stats(engine),
        # Training
        "/train": lambda: _cmd_train(engine, arg),
        "/train-doc": lambda: _cmd_train_doc(engine, arg),
        "/train-file": lambda: _cmd_train_file(engine, arg),
        "/adapters": lambda: _cmd_adapters(engine),
        "/adapter": lambda: _cmd_adapter(engine, arg),
        "/adapter-off": lambda: _cmd_adapter_off(engine),
        # Workflows & permissions
        "/workflows": lambda: _cmd_workflow(engine, arg) if arg else _cmd_workflows(engine),
        "/workflow": lambda: _cmd_workflow(engine, arg),
        "/permissions": lambda: _cmd_permissions(engine),
        "/permit": lambda: _cmd_permit(engine, arg),
        # System
        "/help": _cmd_help,
        "/quit": _cmd_quit,
        "/exit": _cmd_quit,
        "/q": _cmd_quit,
    }

    handler = handlers.get(cmd)
    if handler is None:
        print_error(f"Unknown command: {cmd}. Type /help for available commands.")
        return True

    handler()
    return True


# ── Core commands ─────────────────────────────────────────────────────

def _cmd_new(engine: Engine) -> None:
    conv = engine.new_conversation()
    print_success(f"New conversation started. ({conv.id[:8]})")


def _cmd_history(engine: Engine) -> None:
    convs = engine.list_conversations(limit=10)
    print_conversation_list(convs)


def _cmd_resume(engine: Engine, arg: str) -> None:
    if not arg:
        print_error("Usage: /resume <conversation-id-prefix>")
        return

    convs = engine.list_conversations(limit=50)
    matches = [c for c in convs if c.id.startswith(arg)]

    if len(matches) == 0:
        print_error(f"No conversation found matching '{arg}'.")
    elif len(matches) > 1:
        print_error(f"Ambiguous prefix '{arg}'. Matches: {len(matches)}")
        print_conversation_list(matches[:5])
    else:
        conv = engine.resume_conversation(matches[0].id)
        if conv:
            print_success(f"Resumed: {conv.title or '(untitled)'} ({conv.id[:8]})")
        else:
            print_error("Failed to resume conversation.")


def _cmd_ingest(engine: Engine, arg: str) -> None:
    if not arg:
        print_error("Usage: /ingest <file-path>")
        return

    path = Path(arg).expanduser().resolve()
    if not path.exists():
        print_error(f"File not found: {path}")
        return
    if not path.is_file():
        print_error(f"Not a file: {path}")
        return

    try:
        doc_id, chunk_count = engine.ingest_document(path)
        print_success(f"Ingested: {path.name} ({chunk_count} chunks, id={doc_id[:8]})")
    except ValueError as e:
        print_error(str(e))
    except RuntimeError as e:
        print_warning(str(e))
    except Exception as e:
        print_error(f"Failed to ingest: {e}")


def _cmd_memory(engine: Engine, arg: str) -> None:
    if not arg:
        print_error("Usage: /memory <search query>")
        return

    results = engine.rag_search(arg)
    if not results:
        print_info("No relevant results found.")
        return

    for i, r in enumerate(results, 1):
        score = r["score"]
        source = r["source_type"]
        preview = r["content"][:200]
        console.print(
            f"  [cyan]{i}.[/cyan] [{source}] (score={score})\n"
            f"     {preview}"
        )


def _cmd_docs(engine: Engine) -> None:
    if engine.rag is None:
        print_warning("RAG not initialized.")
        return

    docs = engine.rag.document_store.list_all(limit=20)
    if not docs:
        print_info("No documents ingested yet. Use /ingest <path> to add one.")
        return

    for i, doc in enumerate(docs, 1):
        indexed = "indexed" if doc.indexed_at else "not indexed"
        size = f"{doc.size_bytes / 1024:.1f}KB" if doc.size_bytes else "?"
        console.print(
            f"  [cyan]{i}.[/cyan] {doc.filename} "
            f"[dim]({doc.file_type}, {size}, {doc.chunk_count} chunks, {indexed})[/dim] "
            f"[dim italic]{doc.id[:8]}[/dim italic]"
        )


def _cmd_stats(engine: Engine) -> None:
    conv = engine.current_conversation
    if conv is None:
        print_info("No active conversation.")
        return

    msgs = engine.get_history()
    user_msgs = sum(1 for m in msgs if m.role == "user")
    asst_msgs = sum(1 for m in msgs if m.role == "assistant")
    total_tokens = sum(
        (m.tokens_prompt or 0) + (m.tokens_completion or 0)
        for m in msgs
    )

    lines = [
        f"Conversation: {conv.id[:8]}",
        f"Messages: {user_msgs} user, {asst_msgs} assistant",
        f"Total tokens: {total_tokens}",
        f"Model: {engine.config.model_filename}",
    ]

    if engine.config.adapter_path:
        lines.append(f"Adapter: {engine.config.adapter_path}")

    if engine.rag:
        stats = engine.rag.stats()
        lines.append(f"RAG: {stats['total_embeddings']} embeddings, {stats['documents']} documents")

    console.print("\n".join(lines))


# ── Training commands ─────────────────────────────────────────────────

def _cmd_train(engine: Engine, arg: str) -> None:
    if not arg:
        print_error("Usage: /train <adapter-name>")
        return

    adapter_name = arg.strip()
    print_info(f"Preparing training dataset from conversations...")

    try:
        dataset_path, count = engine.prepare_training_dataset()
        print_info(f"Dataset: {count} examples written to {dataset_path}")
    except ValueError as e:
        print_error(str(e))
        return

    def progress(p):
        console.print(
            f"  Epoch {p.epoch}/{p.total_epochs} | "
            f"Step {p.step}/{p.total_steps} | "
            f"Loss: {p.loss:.4f} | "
            f"LR: {p.learning_rate:.2e} | "
            f"{p.elapsed_seconds:.0f}s",
            end="\r",
        )

    print_info("Starting LoRA training (this may take a while)...")
    try:
        adapter_path = engine.start_training(
            adapter_name, dataset_path, progress_callback=progress,
        )
        console.print()  # newline after \r progress
        print_success(f"Training complete! Adapter saved: {adapter_path}")
        print_info(f"Activate with: /adapter {adapter_name}")
    except ImportError as e:
        print_error(str(e))
    except Exception as e:
        print_error(f"Training failed: {e}")


def _cmd_train_doc(engine: Engine, arg: str) -> None:
    if not arg:
        print_error("Usage: /train-doc <adapter-name>")
        return

    adapter_name = arg.strip()
    print_info(f"Preparing training dataset from documents...")

    try:
        dataset_path, count = engine.prepare_training_dataset(document_ids=[])
        print_info(f"Dataset: {count} examples from documents")
    except ValueError as e:
        print_error(str(e))
        return

    print_info("Starting LoRA training...")
    try:
        adapter_path = engine.start_training(adapter_name, dataset_path)
        print_success(f"Training complete! Adapter: {adapter_path}")
    except ImportError as e:
        print_error(str(e))
    except Exception as e:
        print_error(f"Training failed: {e}")


def _cmd_train_file(engine: Engine, arg: str) -> None:
    parts = arg.strip().split(maxsplit=1)
    if len(parts) < 2:
        print_error("Usage: /train-file <adapter-name> <path-to-jsonl>")
        return

    adapter_name, file_path = parts
    path = Path(file_path).expanduser().resolve()

    if not path.exists():
        print_error(f"File not found: {path}")
        return

    print_info(f"Preparing training dataset from {path.name}...")
    try:
        dataset_path, count = engine.prepare_training_dataset(jsonl_path=str(path))
        print_info(f"Dataset: {count} examples loaded")
    except (ValueError, FileNotFoundError) as e:
        print_error(str(e))
        return

    print_info("Starting LoRA training...")
    try:
        adapter_path = engine.start_training(adapter_name, dataset_path)
        print_success(f"Training complete! Adapter: {adapter_path}")
    except ImportError as e:
        print_error(str(e))
    except Exception as e:
        print_error(f"Training failed: {e}")


def _cmd_adapters(engine: Engine) -> None:
    if engine.adapter_manager is None:
        print_warning("Adapter manager not initialized.")
        return

    adapters = engine.adapter_manager.list_adapters()
    if not adapters:
        print_info("No adapters found. Use /train to create one.")
        return

    for a in adapters:
        size_mb = a.size_bytes / (1024 * 1024)
        active = " [bold green][ACTIVE][/bold green]" if a.is_active else ""
        base = f" (base: {a.base_model})" if a.base_model else ""
        console.print(
            f"  {a.name}{active} — {size_mb:.1f}MB{base} "
            f"[dim]{a.created_at}[/dim]"
        )


def _cmd_adapter(engine: Engine, arg: str) -> None:
    if not arg:
        print_error("Usage: /adapter <adapter-name>")
        return

    name = arg.strip()
    try:
        engine.activate_adapter(name)
        print_success(f"Adapter '{name}' activated. Model reloaded.")
    except FileNotFoundError:
        print_error(f"Adapter '{name}' not found. Use /adapters to list available.")
    except Exception as e:
        print_error(f"Failed to activate adapter: {e}")


def _cmd_adapter_off(engine: Engine) -> None:
    try:
        engine.deactivate_adapter()
        print_success("Adapter deactivated. Model reloaded without adapter.")
    except Exception as e:
        print_error(f"Failed to deactivate: {e}")


# ── Workflow commands ─────────────────────────────────────────────────

def _cmd_workflows(engine: Engine) -> None:
    if engine.mcp is None or engine.mcp.workflow_engine is None:
        print_warning("Workflow engine not initialized.")
        return

    workflows = engine.mcp.workflow_engine.list_workflows()
    if not workflows:
        print_info("No workflows registered.")
        return

    for wf in workflows:
        console.print(f"  [cyan]{wf.name}[/cyan] — {wf.description} ({len(wf.steps)} steps)")


def _cmd_workflow(engine: Engine, arg: str) -> None:
    if not arg:
        print_error("Usage: /workflow <name> [key=value ...]")
        return

    if engine.mcp is None or engine.mcp.workflow_engine is None:
        print_warning("Workflow engine not initialized.")
        return

    parts = arg.strip().split()
    name = parts[0]
    context = {}
    for part in parts[1:]:
        if "=" in part:
            k, v = part.split("=", 1)
            context[k] = v

    workflow = engine.mcp.workflow_engine.get_workflow(name)
    if workflow is None:
        print_error(f"Unknown workflow '{name}'. Use /workflows to list available.")
        return

    def on_step(result):
        status = "SKIP" if result.skipped else ("OK" if result.success else "FAIL")
        console.print(f"  [{status}] {result.tool_name}")

    print_info(f"Running workflow '{name}'...")
    conv_id = engine.current_conversation.id if engine.current_conversation else None
    result = engine.mcp.workflow_engine.execute(
        workflow,
        initial_context=context,
        conversation_id=conv_id,
        progress_callback=on_step,
    )

    if result.success:
        print_success(f"Workflow '{name}' completed.")
    else:
        print_error(f"Workflow '{name}' failed: {result.error}")

    # Show final step outputs
    for sr in result.steps:
        if not sr.skipped:
            output = sr.output[:300] if len(sr.output) > 300 else sr.output
            console.print(f"  [dim]{sr.tool_name}:[/dim] {output}")


# ── Permission commands ───────────────────────────────────────────────

def _cmd_permissions(engine: Engine) -> None:
    if engine.mcp is None:
        print_warning("MCP server not initialized.")
        return

    perms = engine.mcp.permissions.list_permissions()
    if not perms:
        print_info("No tool permissions configured (all tools default to 'ask').")
        return

    for p in perms:
        scope_str = f" scope={p.scope}" if p.scope else ""
        console.print(f"  {p.tool_name}: [bold]{p.permission}[/bold]{scope_str}")


def _cmd_permit(engine: Engine, arg: str) -> None:
    parts = arg.strip().split()
    if len(parts) < 2:
        print_error("Usage: /permit <tool-name> <allow|deny|ask>")
        return

    tool_name = parts[0]
    permission = parts[1].lower()

    if permission not in ("allow", "deny", "ask"):
        print_error(f"Invalid permission '{permission}'. Use: allow, deny, or ask.")
        return

    if engine.mcp is None:
        print_warning("MCP server not initialized.")
        return

    engine.mcp.permissions.set_permission(tool_name, permission)
    print_success(f"Set {tool_name} = {permission}")


# ── System commands ───────────────────────────────────────────────────

def _cmd_help() -> None:
    console.print(HELP_TEXT)


def _cmd_quit() -> None:
    raise SystemExit(0)
