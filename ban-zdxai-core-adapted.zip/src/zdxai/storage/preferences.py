"""Key-value preference store backed by SQLite."""

from __future__ import annotations

import json
from datetime import datetime, timezone

from zdxai.storage.database import Database


class PreferenceStore:
    """Simple key-value config store."""

    def __init__(self, db: Database) -> None:
        self._db = db

    def get(self, key: str, default: str | None = None) -> str | None:
        row = self._db.execute(
            "SELECT value FROM preferences WHERE key = ?", (key,)
        ).fetchone()
        if row is None:
            return default
        return row["value"]

    def get_json(self, key: str, default=None):
        """Get a preference and parse it as JSON."""
        raw = self.get(key)
        if raw is None:
            return default
        return json.loads(raw)

    def set(self, key: str, value: str) -> None:
        now = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%fZ")
        self._db.execute(
            "INSERT INTO preferences (key, value, updated_at) VALUES (?, ?, ?) "
            "ON CONFLICT(key) DO UPDATE SET value = excluded.value, "
            "updated_at = excluded.updated_at",
            (key, value, now),
        )
        self._db.commit()

    def set_json(self, key: str, value) -> None:
        self.set(key, json.dumps(value))

    def delete(self, key: str) -> None:
        self._db.execute("DELETE FROM preferences WHERE key = ?", (key,))
        self._db.commit()

    def all(self) -> dict[str, str]:
        rows = self._db.execute("SELECT key, value FROM preferences").fetchall()
        return {r["key"]: r["value"] for r in rows}
