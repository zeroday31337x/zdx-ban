"""SQLite database connection manager with WAL mode and migrations."""

from __future__ import annotations

import logging
import sqlite3
from pathlib import Path

from zdxai.storage.schema import MIGRATIONS

log = logging.getLogger(__name__)


class Database:
    """SQLite connection manager with WAL mode and schema migrations."""

    def __init__(self, db_path: Path) -> None:
        self._db_path = db_path
        self._conn: sqlite3.Connection | None = None

    @property
    def conn(self) -> sqlite3.Connection:
        if self._conn is None:
            raise RuntimeError("Database not open. Call open() first.")
        return self._conn

    def open(self) -> None:
        """Open the database connection and apply pragmas."""
        self._db_path.parent.mkdir(parents=True, exist_ok=True)
        self._conn = sqlite3.connect(
            str(self._db_path),
            check_same_thread=False,
        )
        self._conn.row_factory = sqlite3.Row
        self._conn.execute("PRAGMA journal_mode=WAL")
        self._conn.execute("PRAGMA foreign_keys=ON")
        self._conn.execute("PRAGMA busy_timeout=5000")
        log.info("Database opened: %s", self._db_path)

    def close(self) -> None:
        """Close the database connection."""
        if self._conn:
            self._conn.close()
            self._conn = None
            log.info("Database closed.")

    def migrate(self) -> None:
        """Apply pending schema migrations."""
        # Ensure schema_version table exists (bootstrap)
        self.conn.execute(
            "CREATE TABLE IF NOT EXISTS schema_version ("
            "  version INTEGER PRIMARY KEY,"
            "  applied_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),"
            "  description TEXT"
            ")"
        )

        row = self.conn.execute(
            "SELECT COALESCE(MAX(version), 0) AS v FROM schema_version"
        ).fetchone()
        current_version = row["v"]

        for version in sorted(MIGRATIONS.keys()):
            if version <= current_version:
                continue
            ddl, description = MIGRATIONS[version]
            log.info("Applying migration v%d: %s", version, description)
            self.conn.executescript(ddl)
            self.conn.execute(
                "INSERT INTO schema_version (version, description) VALUES (?, ?)",
                (version, description),
            )
            self.conn.commit()
            log.info("Migration v%d applied.", version)

    def execute(
        self, sql: str, params: tuple | dict = ()
    ) -> sqlite3.Cursor:
        return self.conn.execute(sql, params)

    def executemany(
        self, sql: str, params_seq: list[tuple]
    ) -> sqlite3.Cursor:
        return self.conn.executemany(sql, params_seq)

    def commit(self) -> None:
        self.conn.commit()
