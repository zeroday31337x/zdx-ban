"""Conversation and message CRUD operations."""

from __future__ import annotations

import uuid
from dataclasses import dataclass
from datetime import datetime, timezone

from zdxai.storage.database import Database


def _now_iso() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%fZ")


def _new_id() -> str:
    return uuid.uuid4().hex


@dataclass
class Message:
    id: str
    conversation_id: str
    role: str
    content: str
    tool_call_id: str | None = None
    tool_name: str | None = None
    tool_input: str | None = None
    tool_output: str | None = None
    tokens_prompt: int | None = None
    tokens_completion: int | None = None
    model_id: str | None = None
    latency_ms: int | None = None
    created_at: str = ""


@dataclass
class Conversation:
    id: str
    title: str | None
    created_at: str
    updated_at: str
    summary: str | None = None
    message_count: int = 0
    is_archived: bool = False


class ConversationStore:
    """CRUD for conversations and messages."""

    def __init__(self, db: Database) -> None:
        self._db = db

    def create_conversation(self, title: str | None = None) -> Conversation:
        """Create a new conversation and return it."""
        conv_id = _new_id()
        now = _now_iso()
        self._db.execute(
            "INSERT INTO conversations (id, title, created_at, updated_at) "
            "VALUES (?, ?, ?, ?)",
            (conv_id, title, now, now),
        )
        self._db.commit()
        return Conversation(
            id=conv_id, title=title, created_at=now,
            updated_at=now, message_count=0,
        )

    def get_conversation(self, conv_id: str) -> Conversation | None:
        row = self._db.execute(
            "SELECT * FROM conversations WHERE id = ?", (conv_id,)
        ).fetchone()
        if not row:
            return None
        return Conversation(
            id=row["id"], title=row["title"],
            created_at=row["created_at"], updated_at=row["updated_at"],
            summary=row["summary"], message_count=row["message_count"],
            is_archived=bool(row["is_archived"]),
        )

    def list_conversations(self, limit: int = 20, offset: int = 0) -> list[Conversation]:
        rows = self._db.execute(
            "SELECT * FROM conversations WHERE is_archived = 0 "
            "ORDER BY updated_at DESC LIMIT ? OFFSET ?",
            (limit, offset),
        ).fetchall()
        return [
            Conversation(
                id=r["id"], title=r["title"],
                created_at=r["created_at"], updated_at=r["updated_at"],
                summary=r["summary"], message_count=r["message_count"],
                is_archived=bool(r["is_archived"]),
            )
            for r in rows
        ]

    def update_conversation(
        self, conv_id: str, title: str | None = None, summary: str | None = None
    ) -> None:
        parts = ["updated_at = ?"]
        params: list = [_now_iso()]
        if title is not None:
            parts.append("title = ?")
            params.append(title)
        if summary is not None:
            parts.append("summary = ?")
            params.append(summary)
        params.append(conv_id)
        self._db.execute(
            f"UPDATE conversations SET {', '.join(parts)} WHERE id = ?",
            tuple(params),
        )
        self._db.commit()

    def delete_conversation(self, conv_id: str) -> None:
        self._db.execute("DELETE FROM conversations WHERE id = ?", (conv_id,))
        self._db.commit()

    def add_message(
        self,
        conversation_id: str,
        role: str,
        content: str,
        *,
        tool_call_id: str | None = None,
        tool_name: str | None = None,
        tool_input: str | None = None,
        tool_output: str | None = None,
        tokens_prompt: int | None = None,
        tokens_completion: int | None = None,
        model_id: str | None = None,
        latency_ms: int | None = None,
    ) -> Message:
        """Add a message to a conversation."""
        msg_id = _new_id()
        now = _now_iso()
        self._db.execute(
            "INSERT INTO messages "
            "(id, conversation_id, role, content, tool_call_id, tool_name, "
            " tool_input, tool_output, tokens_prompt, tokens_completion, "
            " model_id, latency_ms, created_at) "
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
            (
                msg_id, conversation_id, role, content,
                tool_call_id, tool_name, tool_input, tool_output,
                tokens_prompt, tokens_completion, model_id, latency_ms, now,
            ),
        )
        # Update conversation metadata
        self._db.execute(
            "UPDATE conversations SET updated_at = ?, "
            "message_count = message_count + 1 WHERE id = ?",
            (_now_iso(), conversation_id),
        )
        self._db.commit()
        return Message(
            id=msg_id, conversation_id=conversation_id,
            role=role, content=content,
            tool_call_id=tool_call_id, tool_name=tool_name,
            tool_input=tool_input, tool_output=tool_output,
            tokens_prompt=tokens_prompt, tokens_completion=tokens_completion,
            model_id=model_id, latency_ms=latency_ms, created_at=now,
        )

    def get_messages(
        self, conversation_id: str, limit: int | None = None
    ) -> list[Message]:
        """Get messages for a conversation, ordered by creation time."""
        sql = (
            "SELECT * FROM messages WHERE conversation_id = ? "
            "ORDER BY created_at ASC"
        )
        params: list = [conversation_id]
        if limit is not None:
            sql += " LIMIT ?"
            params.append(limit)
        rows = self._db.execute(sql, tuple(params)).fetchall()
        return [
            Message(
                id=r["id"], conversation_id=r["conversation_id"],
                role=r["role"], content=r["content"],
                tool_call_id=r["tool_call_id"], tool_name=r["tool_name"],
                tool_input=r["tool_input"], tool_output=r["tool_output"],
                tokens_prompt=r["tokens_prompt"],
                tokens_completion=r["tokens_completion"],
                model_id=r["model_id"], latency_ms=r["latency_ms"],
                created_at=r["created_at"],
            )
            for r in rows
        ]

    def get_recent_messages(
        self, conversation_id: str, limit: int = 20
    ) -> list[Message]:
        """Get the most recent N messages, returned in chronological order."""
        rows = self._db.execute(
            "SELECT * FROM ("
            "  SELECT * FROM messages WHERE conversation_id = ? "
            "  ORDER BY created_at DESC LIMIT ?"
            ") ORDER BY created_at ASC",
            (conversation_id, limit),
        ).fetchall()
        return [
            Message(
                id=r["id"], conversation_id=r["conversation_id"],
                role=r["role"], content=r["content"],
                tool_call_id=r["tool_call_id"], tool_name=r["tool_name"],
                tool_input=r["tool_input"], tool_output=r["tool_output"],
                tokens_prompt=r["tokens_prompt"],
                tokens_completion=r["tokens_completion"],
                model_id=r["model_id"], latency_ms=r["latency_ms"],
                created_at=r["created_at"],
            )
            for r in rows
        ]
