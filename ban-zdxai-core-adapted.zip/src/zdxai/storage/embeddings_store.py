"""Vector storage and cosine similarity search using SQLite BLOBs."""

from __future__ import annotations

import struct
import uuid
from dataclasses import dataclass
from datetime import datetime, timezone

import numpy as np

from zdxai.constants import EMBEDDING_DIM
from zdxai.storage.database import Database


def _new_id() -> str:
    return uuid.uuid4().hex


def _now_iso() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%fZ")


def embedding_to_blob(vec: np.ndarray) -> bytes:
    """Convert a float32 numpy array to bytes for SQLite BLOB storage."""
    return vec.astype(np.float32).tobytes()


def blob_to_embedding(blob: bytes) -> np.ndarray:
    """Convert a SQLite BLOB back to a float32 numpy array."""
    return np.frombuffer(blob, dtype=np.float32)


@dataclass
class EmbeddingRecord:
    id: str
    source_type: str
    source_id: str
    chunk_index: int
    content_preview: str
    embedding: np.ndarray
    token_count: int | None
    created_at: str


@dataclass
class SearchResult:
    record: EmbeddingRecord
    score: float  # cosine similarity


class EmbeddingStore:
    """Store and search embeddings in SQLite."""

    def __init__(self, db: Database) -> None:
        self._db = db

    def store(
        self,
        source_type: str,
        source_id: str,
        content_preview: str,
        embedding: np.ndarray,
        chunk_index: int = 0,
        token_count: int | None = None,
    ) -> str:
        """Store an embedding and return its ID."""
        emb_id = _new_id()
        self._db.execute(
            "INSERT INTO embeddings "
            "(id, source_type, source_id, chunk_index, content_preview, "
            " embedding, token_count, created_at) "
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
            (
                emb_id, source_type, source_id, chunk_index,
                content_preview[:500], embedding_to_blob(embedding),
                token_count, _now_iso(),
            ),
        )
        self._db.commit()
        return emb_id

    def store_batch(
        self,
        records: list[tuple[str, str, str, np.ndarray, int, int | None]],
    ) -> list[str]:
        """Store multiple embeddings. Each tuple: (source_type, source_id, preview, vec, chunk_idx, token_count)."""
        ids = []
        now = _now_iso()
        for source_type, source_id, preview, vec, chunk_idx, tok_count in records:
            emb_id = _new_id()
            ids.append(emb_id)
            self._db.execute(
                "INSERT INTO embeddings "
                "(id, source_type, source_id, chunk_index, content_preview, "
                " embedding, token_count, created_at) "
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                (
                    emb_id, source_type, source_id, chunk_idx,
                    preview[:500], embedding_to_blob(vec), tok_count, now,
                ),
            )
        self._db.commit()
        return ids

    def search(
        self,
        query_embedding: np.ndarray,
        top_k: int = 5,
        source_types: list[str] | None = None,
    ) -> list[SearchResult]:
        """Find the top-k most similar embeddings via cosine similarity."""
        if source_types:
            placeholders = ",".join("?" for _ in source_types)
            rows = self._db.execute(
                f"SELECT * FROM embeddings WHERE source_type IN ({placeholders})",
                tuple(source_types),
            ).fetchall()
        else:
            rows = self._db.execute("SELECT * FROM embeddings").fetchall()

        if not rows:
            return []

        # Compute cosine similarity in batch
        query_norm = query_embedding / (np.linalg.norm(query_embedding) + 1e-10)
        results: list[SearchResult] = []

        for row in rows:
            vec = blob_to_embedding(row["embedding"])
            vec_norm = vec / (np.linalg.norm(vec) + 1e-10)
            score = float(np.dot(query_norm, vec_norm))

            record = EmbeddingRecord(
                id=row["id"],
                source_type=row["source_type"],
                source_id=row["source_id"],
                chunk_index=row["chunk_index"],
                content_preview=row["content_preview"],
                embedding=vec,
                token_count=row["token_count"],
                created_at=row["created_at"],
            )
            results.append(SearchResult(record=record, score=score))

        results.sort(key=lambda r: r.score, reverse=True)
        return results[:top_k]

    def delete_by_source(self, source_type: str, source_id: str) -> int:
        """Delete all embeddings for a given source. Returns count deleted."""
        cursor = self._db.execute(
            "DELETE FROM embeddings WHERE source_type = ? AND source_id = ?",
            (source_type, source_id),
        )
        self._db.commit()
        return cursor.rowcount

    def count(self, source_type: str | None = None) -> int:
        if source_type:
            row = self._db.execute(
                "SELECT COUNT(*) AS c FROM embeddings WHERE source_type = ?",
                (source_type,),
            ).fetchone()
        else:
            row = self._db.execute("SELECT COUNT(*) AS c FROM embeddings").fetchone()
        return row["c"]
