"""User document store for RAG and training."""

from __future__ import annotations

import json
import uuid
from dataclasses import dataclass
from datetime import datetime, timezone

from zdxai.storage.database import Database


def _new_id() -> str:
    return uuid.uuid4().hex


def _now_iso() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%fZ")


@dataclass
class Document:
    id: str
    filename: str
    file_type: str
    content: str
    chunk_count: int
    size_bytes: int | None
    metadata: dict | None
    indexed_at: str | None
    created_at: str


class DocumentStore:
    """CRUD for user-uploaded documents."""

    def __init__(self, db: Database) -> None:
        self._db = db

    def add(
        self,
        filename: str,
        file_type: str,
        content: str,
        chunk_count: int = 0,
        size_bytes: int | None = None,
        metadata: dict | None = None,
    ) -> Document:
        doc_id = _new_id()
        now = _now_iso()
        meta_json = json.dumps(metadata) if metadata else None
        self._db.execute(
            "INSERT INTO documents "
            "(id, filename, file_type, content, chunk_count, size_bytes, metadata, created_at) "
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
            (doc_id, filename, file_type, content, chunk_count, size_bytes, meta_json, now),
        )
        self._db.commit()
        return Document(
            id=doc_id, filename=filename, file_type=file_type,
            content=content, chunk_count=chunk_count,
            size_bytes=size_bytes, metadata=metadata,
            indexed_at=None, created_at=now,
        )

    def get(self, doc_id: str) -> Document | None:
        row = self._db.execute(
            "SELECT * FROM documents WHERE id = ?", (doc_id,)
        ).fetchone()
        if not row:
            return None
        return self._row_to_doc(row)

    def list_all(self, limit: int = 50) -> list[Document]:
        rows = self._db.execute(
            "SELECT * FROM documents ORDER BY created_at DESC LIMIT ?", (limit,)
        ).fetchall()
        return [self._row_to_doc(r) for r in rows]

    def mark_indexed(self, doc_id: str, chunk_count: int) -> None:
        now = _now_iso()
        self._db.execute(
            "UPDATE documents SET indexed_at = ?, chunk_count = ? WHERE id = ?",
            (now, chunk_count, doc_id),
        )
        self._db.commit()

    def delete(self, doc_id: str) -> None:
        self._db.execute("DELETE FROM documents WHERE id = ?", (doc_id,))
        self._db.commit()

    def _row_to_doc(self, row) -> Document:
        meta = None
        if row["metadata"]:
            meta = json.loads(row["metadata"])
        return Document(
            id=row["id"], filename=row["filename"],
            file_type=row["file_type"], content=row["content"],
            chunk_count=row["chunk_count"], size_bytes=row["size_bytes"],
            metadata=meta, indexed_at=row["indexed_at"],
            created_at=row["created_at"],
        )
