"""DDL statements for zdxai SQLite database."""

SCHEMA_V1 = """
-- Conversations
CREATE TABLE IF NOT EXISTS conversations (
    id TEXT PRIMARY KEY,
    title TEXT,
    created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
    updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
    summary TEXT,
    message_count INTEGER NOT NULL DEFAULT 0,
    is_archived INTEGER NOT NULL DEFAULT 0
);

-- Messages
CREATE TABLE IF NOT EXISTS messages (
    id TEXT PRIMARY KEY,
    conversation_id TEXT NOT NULL REFERENCES conversations(id) ON DELETE CASCADE,
    role TEXT NOT NULL CHECK(role IN ('system','user','assistant','tool')),
    content TEXT NOT NULL,
    tool_call_id TEXT,
    tool_name TEXT,
    tool_input TEXT,
    tool_output TEXT,
    tokens_prompt INTEGER,
    tokens_completion INTEGER,
    model_id TEXT,
    latency_ms INTEGER,
    created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);
CREATE INDEX IF NOT EXISTS idx_messages_conversation ON messages(conversation_id, created_at);

-- User documents (for RAG + training)
CREATE TABLE IF NOT EXISTS documents (
    id TEXT PRIMARY KEY,
    filename TEXT NOT NULL,
    file_type TEXT NOT NULL,
    content TEXT NOT NULL,
    chunk_count INTEGER NOT NULL DEFAULT 0,
    size_bytes INTEGER,
    metadata TEXT,
    indexed_at TEXT,
    created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);

-- Embeddings (conversations + documents)
CREATE TABLE IF NOT EXISTS embeddings (
    id TEXT PRIMARY KEY,
    source_type TEXT NOT NULL CHECK(source_type IN ('message','summary','document')),
    source_id TEXT NOT NULL,
    chunk_index INTEGER NOT NULL DEFAULT 0,
    content_preview TEXT NOT NULL,
    embedding BLOB NOT NULL,
    token_count INTEGER,
    created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);
CREATE INDEX IF NOT EXISTS idx_embeddings_source ON embeddings(source_type, source_id);

-- Tool permissions
CREATE TABLE IF NOT EXISTS tool_permissions (
    id TEXT PRIMARY KEY,
    tool_name TEXT NOT NULL UNIQUE,
    permission TEXT NOT NULL CHECK(permission IN ('allow','deny','ask')),
    scope TEXT,
    granted_at TEXT,
    granted_by TEXT
);

-- Tool audit log
CREATE TABLE IF NOT EXISTS tool_audit_log (
    id TEXT PRIMARY KEY,
    tool_name TEXT NOT NULL,
    action TEXT NOT NULL,
    input_summary TEXT,
    output_summary TEXT,
    conversation_id TEXT,
    created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);

-- Model registry
CREATE TABLE IF NOT EXISTS model_registry (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    file_path TEXT NOT NULL,
    model_type TEXT NOT NULL CHECK(model_type IN ('base','embedding','adapter')),
    quantization TEXT,
    size_bytes INTEGER,
    sha256 TEXT,
    version TEXT,
    is_active INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);

-- User preferences
CREATE TABLE IF NOT EXISTS preferences (
    key TEXT PRIMARY KEY,
    value TEXT NOT NULL,
    updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);

-- Schema versioning
CREATE TABLE IF NOT EXISTS schema_version (
    version INTEGER PRIMARY KEY,
    applied_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
    description TEXT
);
"""

SCHEMA_V2 = """
-- Training jobs
CREATE TABLE IF NOT EXISTS training_jobs (
    id TEXT PRIMARY KEY,
    adapter_name TEXT NOT NULL,
    status TEXT NOT NULL CHECK(status IN ('pending','running','completed','failed','cancelled')),
    base_model_id TEXT,
    dataset_path TEXT,
    config_json TEXT,
    examples_count INTEGER,
    current_epoch INTEGER DEFAULT 0,
    total_epochs INTEGER,
    current_step INTEGER DEFAULT 0,
    total_steps INTEGER,
    final_loss REAL,
    error_message TEXT,
    started_at TEXT,
    completed_at TEXT,
    created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);

-- Training data sources
CREATE TABLE IF NOT EXISTS training_sources (
    id TEXT PRIMARY KEY,
    job_id TEXT NOT NULL REFERENCES training_jobs(id) ON DELETE CASCADE,
    source_type TEXT NOT NULL CHECK(source_type IN ('conversation','document','file')),
    source_id TEXT NOT NULL,
    examples_count INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);
CREATE INDEX IF NOT EXISTS idx_training_sources_job ON training_sources(job_id);

-- Workflow definitions
CREATE TABLE IF NOT EXISTS workflows (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL UNIQUE,
    description TEXT,
    steps_json TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
    updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);

-- Workflow execution log
CREATE TABLE IF NOT EXISTS workflow_executions (
    id TEXT PRIMARY KEY,
    workflow_id TEXT REFERENCES workflows(id) ON DELETE SET NULL,
    workflow_name TEXT NOT NULL,
    status TEXT NOT NULL CHECK(status IN ('running','completed','failed','cancelled')),
    steps_completed INTEGER NOT NULL DEFAULT 0,
    total_steps INTEGER NOT NULL,
    context_json TEXT,
    error_message TEXT,
    conversation_id TEXT,
    started_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
    completed_at TEXT
);
"""

SCHEMA_V3 = """
-- Gravity wells: learned routing attractors in embedding space
CREATE TABLE IF NOT EXISTS routing_wells (
    id TEXT PRIMARY KEY,
    centroid_embedding BLOB NOT NULL,
    feature_centroid BLOB NOT NULL,
    verdict_json TEXT NOT NULL,
    mass REAL NOT NULL DEFAULT 1.0,
    quality_ema REAL NOT NULL DEFAULT 0.5,
    sample_count INTEGER NOT NULL DEFAULT 0,
    variance_accumulator REAL NOT NULL DEFAULT 0.0,
    variance_mean REAL NOT NULL DEFAULT 0.0,
    is_active INTEGER NOT NULL DEFAULT 1,
    parent_well_id TEXT,
    created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
    updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);

-- Routing decisions: full audit trail for replay
CREATE TABLE IF NOT EXISTS routing_decisions (
    id TEXT PRIMARY KEY,
    query_text TEXT NOT NULL,
    query_embedding BLOB NOT NULL,
    query_metrics_json TEXT NOT NULL,
    well_id TEXT REFERENCES routing_wells(id) ON DELETE SET NULL,
    verdict_json TEXT NOT NULL,
    gravitational_pull REAL,
    confidence REAL NOT NULL,
    quality_score REAL,
    quality_signals_json TEXT,
    conversation_id TEXT,
    message_id TEXT,
    model_used TEXT,
    latency_ms INTEGER,
    created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);
CREATE INDEX IF NOT EXISTS idx_routing_decisions_well ON routing_decisions(well_id);
CREATE INDEX IF NOT EXISTS idx_routing_decisions_conv ON routing_decisions(conversation_id);
CREATE INDEX IF NOT EXISTS idx_routing_decisions_created ON routing_decisions(created_at);

-- Platform configurations
CREATE TABLE IF NOT EXISTS platform_configs (
    id TEXT PRIMARY KEY,
    platform_name TEXT NOT NULL UNIQUE,
    api_key_env_var TEXT NOT NULL,
    base_url TEXT,
    free_model TEXT,
    paid_model TEXT,
    is_enabled INTEGER NOT NULL DEFAULT 0,
    rate_limit_rpm INTEGER DEFAULT 60,
    rate_limit_remaining INTEGER DEFAULT 60,
    rate_limit_reset_at TEXT,
    total_requests INTEGER NOT NULL DEFAULT 0,
    total_tokens INTEGER NOT NULL DEFAULT 0,
    avg_latency_ms INTEGER,
    quality_ema REAL NOT NULL DEFAULT 0.5,
    created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
    updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);

-- Platform request log
CREATE TABLE IF NOT EXISTS platform_requests (
    id TEXT PRIMARY KEY,
    platform_name TEXT NOT NULL,
    model TEXT NOT NULL,
    tokens_prompt INTEGER,
    tokens_completion INTEGER,
    latency_ms INTEGER,
    status TEXT NOT NULL CHECK(status IN ('success','error','rate_limited','timeout')),
    error_message TEXT,
    decision_id TEXT REFERENCES routing_decisions(id) ON DELETE SET NULL,
    created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);
CREATE INDEX IF NOT EXISTS idx_platform_requests_name ON platform_requests(platform_name, created_at);
"""

SCHEMA_V4 = """
-- BAN semantic memory.  Runtime/provider failures are intentionally stored
-- separately so infrastructure accidents cannot become reasoning lessons.
CREATE TABLE IF NOT EXISTS ban_memories (
    id TEXT PRIMARY KEY,
    content TEXT NOT NULL,
    summary TEXT NOT NULL DEFAULT '',
    tier TEXT NOT NULL,
    category TEXT NOT NULL DEFAULT '',
    strategy TEXT NOT NULL DEFAULT '',
    outcome TEXT NOT NULL DEFAULT '',
    support TEXT NOT NULL DEFAULT 'UNKNOWN',
    authority TEXT NOT NULL DEFAULT 'UNKNOWN',
    failure_relevant INTEGER NOT NULL DEFAULT 0,
    confidence REAL NOT NULL DEFAULT 0.5,
    embedding BLOB,
    provenance_json TEXT NOT NULL DEFAULT '{}',
    created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
    updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
    last_used_at TEXT,
    use_count INTEGER NOT NULL DEFAULT 0,
    superseded_by TEXT,
    is_active INTEGER NOT NULL DEFAULT 1
);
CREATE INDEX IF NOT EXISTS idx_ban_memories_tier ON ban_memories(tier, is_active);
CREATE INDEX IF NOT EXISTS idx_ban_memories_category ON ban_memories(category, is_active);

CREATE TABLE IF NOT EXISTS ban_memory_tags (
    memory_id TEXT NOT NULL REFERENCES ban_memories(id) ON DELETE CASCADE,
    tag TEXT NOT NULL,
    tag_kind TEXT NOT NULL DEFAULT 'context',
    weight REAL NOT NULL DEFAULT 1.0,
    PRIMARY KEY(memory_id, tag_kind, tag)
);
CREATE INDEX IF NOT EXISTS idx_ban_memory_tags_tag ON ban_memory_tags(tag_kind, tag);

CREATE TABLE IF NOT EXISTS ban_memory_relations (
    id TEXT PRIMARY KEY,
    from_memory_id TEXT NOT NULL REFERENCES ban_memories(id) ON DELETE CASCADE,
    to_memory_id TEXT NOT NULL REFERENCES ban_memories(id) ON DELETE CASCADE,
    relation TEXT NOT NULL,
    score REAL NOT NULL DEFAULT 1.0,
    metadata_json TEXT NOT NULL DEFAULT '{}',
    created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);
CREATE INDEX IF NOT EXISTS idx_ban_relations_from ON ban_memory_relations(from_memory_id);
CREATE INDEX IF NOT EXISTS idx_ban_relations_to ON ban_memory_relations(to_memory_id);

CREATE TABLE IF NOT EXISTS ban_memory_retrievals (
    id TEXT PRIMARY KEY,
    run_id TEXT NOT NULL,
    query_hash TEXT NOT NULL,
    memory_id TEXT NOT NULL REFERENCES ban_memories(id) ON DELETE CASCADE,
    relation TEXT NOT NULL DEFAULT 'context_reference',
    total_score REAL NOT NULL,
    semantic_score REAL NOT NULL DEFAULT 0.0,
    tag_score REAL NOT NULL DEFAULT 0.0,
    category_match INTEGER NOT NULL DEFAULT 0,
    strategy_match INTEGER NOT NULL DEFAULT 0,
    failure_relevant INTEGER NOT NULL DEFAULT 0,
    tier TEXT NOT NULL,
    recency REAL NOT NULL DEFAULT 0.0,
    used INTEGER NOT NULL DEFAULT 0,
    rejected INTEGER NOT NULL DEFAULT 0,
    conflicted INTEGER NOT NULL DEFAULT 0,
    effect TEXT NOT NULL DEFAULT 'UNOBSERVABLE',
    created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);
CREATE INDEX IF NOT EXISTS idx_ban_retrievals_run ON ban_memory_retrievals(run_id);
CREATE INDEX IF NOT EXISTS idx_ban_retrievals_memory ON ban_memory_retrievals(memory_id);

CREATE TABLE IF NOT EXISTS ban_memory_events (
    id TEXT PRIMARY KEY,
    event_type TEXT NOT NULL,
    memory_id TEXT REFERENCES ban_memories(id) ON DELETE SET NULL,
    payload_json TEXT NOT NULL DEFAULT '{}',
    created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);

CREATE TABLE IF NOT EXISTS ban_operational_events (
    id TEXT PRIMARY KEY,
    run_id TEXT NOT NULL DEFAULT '',
    provider TEXT NOT NULL,
    code TEXT NOT NULL,
    message TEXT NOT NULL,
    retryable INTEGER NOT NULL DEFAULT 0,
    metadata_json TEXT NOT NULL DEFAULT '{}',
    created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);
CREATE INDEX IF NOT EXISTS idx_ban_operational_run ON ban_operational_events(run_id);
"""

MIGRATIONS = {
    1: (SCHEMA_V1, "Initial schema"),
    2: (SCHEMA_V2, "Training jobs, training sources, workflows"),
    3: (SCHEMA_V3, "Routing wells, decisions, platform configs"),
    4: (SCHEMA_V4, "BAN tiered semantic memory, context references, operational events"),
}
