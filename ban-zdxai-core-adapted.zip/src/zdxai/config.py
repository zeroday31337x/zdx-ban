"""Configuration dataclass for zdxai."""

from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path

from zdxai.constants import (
    DEFAULT_CONTEXT_LENGTH,
    DEFAULT_MAX_TOKENS,
    DEFAULT_SYSTEM_PROMPT,
    DEFAULT_TEMPERATURE,
    DEFAULT_THREADS,
    DEFAULT_TOP_P,
    HF_MODEL_IDS,
    LOW_RAM_THRESHOLD,
    MODEL_CONTEXT_LENGTHS,
    MODEL_EMBEDDING,
    MODEL_SMOLLM2,
    MODEL_TINYLLAMA,
    RAG_CHUNK_OVERLAP,
    RAG_CHUNK_SIZE,
    RAG_TOP_K,
    ROUTER_CENTROID_DRIFT_ALPHA,
    ROUTER_GENESIS_COMPLEXITY_THRESHOLD,
    ROUTER_MIN_GRAVITY_THRESHOLD,
    ROUTER_WELL_SPLIT_VARIANCE_THRESHOLD,
    BAN_MEMORY_TOP_K,
    BAN_MEMORY_MIN_SCORE,
    BAN_WORKING_MEMORY_CHARS,
    BAN_SEMANTIC_WEIGHT,
    BAN_TAG_WEIGHT,
    BAN_CATEGORY_WEIGHT,
    BAN_STRATEGY_WEIGHT,
    BAN_FAILURE_WEIGHT,
    BAN_RECENCY_WEIGHT,
)


def _default_base_dir() -> "Path":
    """Return the platform-correct base directory for zdxai data."""
    try:
        from zdxai.platform.paths import get_base_dir
        return get_base_dir()
    except ImportError:
        return Path.home() / ".zdxai"


def _detect_low_ram() -> bool:
    """Check if system has less than LOW_RAM_THRESHOLD RAM."""
    try:
        import psutil
        return psutil.virtual_memory().total < LOW_RAM_THRESHOLD
    except ImportError:
        # Without psutil, try reading /proc/meminfo on Linux
        try:
            with open("/proc/meminfo") as f:
                for line in f:
                    if line.startswith("MemTotal:"):
                        kb = int(line.split()[1])
                        return kb * 1024 < LOW_RAM_THRESHOLD
        except (OSError, ValueError):
            pass
    return False


@dataclass
class Config:
    """Central configuration for zdxai."""

    # Paths
    base_dir: Path = field(default_factory=lambda: _default_base_dir())
    models_dir: Path | None = None
    data_dir: Path | None = None

    # Model selection
    model_filename: str = ""
    embedding_filename: str = MODEL_EMBEDDING
    adapter_path: str | None = None

    # Inference
    context_length: int = 0  # 0 = auto-select based on model
    max_tokens: int = DEFAULT_MAX_TOKENS
    temperature: float = DEFAULT_TEMPERATURE
    top_p: float = DEFAULT_TOP_P
    threads: int = DEFAULT_THREADS
    gpu_layers: int = 0

    # RAG
    rag_chunk_size: int = RAG_CHUNK_SIZE
    rag_chunk_overlap: int = RAG_CHUNK_OVERLAP
    rag_top_k: int = RAG_TOP_K

    # System prompt
    system_prompt: str = DEFAULT_SYSTEM_PROMPT

    # Router
    router_enabled: bool = True
    router_min_gravity: float = ROUTER_MIN_GRAVITY_THRESHOLD
    router_well_split_threshold: float = ROUTER_WELL_SPLIT_VARIANCE_THRESHOLD
    router_feedback_alpha: float = ROUTER_CENTROID_DRIFT_ALPHA
    router_prefer_local: bool = False
    router_genesis_complexity: float = ROUTER_GENESIS_COMPLEXITY_THRESHOLD

    # BAN memory/reference semantics
    ban_enabled: bool = True
    ban_memory_top_k: int = BAN_MEMORY_TOP_K
    ban_memory_min_score: float = BAN_MEMORY_MIN_SCORE
    ban_working_memory_chars: int = BAN_WORKING_MEMORY_CHARS
    ban_semantic_weight: float = BAN_SEMANTIC_WEIGHT
    ban_tag_weight: float = BAN_TAG_WEIGHT
    ban_category_weight: float = BAN_CATEGORY_WEIGHT
    ban_strategy_weight: float = BAN_STRATEGY_WEIGHT
    ban_failure_weight: float = BAN_FAILURE_WEIGHT
    ban_recency_weight: float = BAN_RECENCY_WEIGHT
    ban_tier_weights: dict[str, float] = field(default_factory=lambda: {
        "TIER_1_BASE": 1.00,
        "TIER_2_DOMAIN": 1.00,
        "TIER_3_EPISODIC": 1.00,
    })
    # Default to strict epistemic gating: model output alone does not become a
    # semantic lesson without a compliant measurement contract.
    ban_require_measurement_for_semantic_memory: bool = True

    # Web UI
    web_host: str = "127.0.0.1"
    web_port: int = 8392

    # Update server
    update_url: str = ""

    # Training
    training_hf_model_id: str = ""

    def __post_init__(self) -> None:
        if self.models_dir is None:
            self.models_dir = self.base_dir / "models"
        if self.data_dir is None:
            self.data_dir = self.base_dir / "data"

        # Auto-select model based on available RAM
        if not self.model_filename:
            if _detect_low_ram():
                self.model_filename = MODEL_TINYLLAMA
            else:
                self.model_filename = MODEL_SMOLLM2

        # Auto-select context length based on model if not explicitly set
        if not self.context_length:
            self.context_length = MODEL_CONTEXT_LENGTHS.get(
                self.model_filename, DEFAULT_CONTEXT_LENGTH
            )

        # Auto-detect HuggingFace model ID for training
        if not self.training_hf_model_id:
            self.training_hf_model_id = HF_MODEL_IDS.get(self.model_filename, "")

        # Detect thread count from CPU
        cpu_count = os.cpu_count()
        if cpu_count and cpu_count < self.threads:
            self.threads = max(1, cpu_count - 1)

    @property
    def model_path(self) -> Path:
        return self.models_dir / self.model_filename

    @property
    def embedding_model_path(self) -> Path:
        return self.models_dir / self.embedding_filename

    @property
    def db_path(self) -> Path:
        return self.data_dir / "zdxai.db"

    @property
    def adapters_dir(self) -> Path:
        return self.models_dir / "adapters"

    def ensure_dirs(self) -> None:
        """Create required directories if they don't exist."""
        self.models_dir.mkdir(parents=True, exist_ok=True)
        self.data_dir.mkdir(parents=True, exist_ok=True)
        self.adapters_dir.mkdir(parents=True, exist_ok=True)
