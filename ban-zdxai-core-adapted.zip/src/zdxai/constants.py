"""Application-wide constants."""

APP_NAME = "zdxai"
APP_VERSION = "0.1.0"

# Model filenames
MODEL_SMOLLM2 = "smollm2-1.7b-q4_k_m.gguf"
MODEL_TINYLLAMA = "tinyllama-1.1b-q4_k_m.gguf"
MODEL_EMBEDDING = "all-minilm-l6-v2.gguf"

# HuggingFace download URLs
MODEL_URLS = {
    MODEL_SMOLLM2: "https://huggingface.co/bartowski/SmolLM2-1.7B-Instruct-GGUF/resolve/main/SmolLM2-1.7B-Instruct-Q4_K_M.gguf",
    MODEL_TINYLLAMA: "https://huggingface.co/TheBloke/TinyLlama-1.1B-Chat-v1.0-GGUF/resolve/main/tinyllama-1.1b-chat-v1.0.Q4_K_M.gguf",
    MODEL_EMBEDDING: "https://huggingface.co/leliuga/all-MiniLM-L6-v2-GGUF/resolve/main/all-MiniLM-L6-v2.F16.gguf",
}

# HuggingFace model IDs corresponding to GGUF filenames (for training)
HF_MODEL_IDS = {
    MODEL_SMOLLM2: "HuggingFaceTB/SmolLM2-1.7B-Instruct",
    MODEL_TINYLLAMA: "TinyLlama/TinyLlama-1.1B-Chat-v1.0",
}

# Inference defaults
DEFAULT_CONTEXT_LENGTH = 2048
DEFAULT_MAX_TOKENS = 512
DEFAULT_TEMPERATURE = 0.7
DEFAULT_TOP_P = 0.9
DEFAULT_THREADS = 4

# Embedding
EMBEDDING_DIM = 384

# RAG
RAG_CHUNK_SIZE = 256  # tokens
RAG_CHUNK_OVERLAP = 32  # tokens
RAG_TOP_K = 5

# MCP
MCP_MAX_TOOL_ITERATIONS = 5

# Training defaults
TRAINING_DEFAULT_LR = 2e-4
TRAINING_DEFAULT_EPOCHS = 3
TRAINING_DEFAULT_BATCH_SIZE = 1
TRAINING_DEFAULT_LORA_R = 8
TRAINING_DEFAULT_LORA_ALPHA = 16
TRAINING_DEFAULT_LORA_DROPOUT = 0.05
TRAINING_DEFAULT_MAX_SEQ_LEN = 512
TRAINING_DEFAULT_GRAD_ACCUM = 4
TRAINING_DEFAULT_WARMUP_STEPS = 10
TRAINING_DEFAULT_SAVE_STEPS = 50

# Workflow limits
WORKFLOW_MAX_STEPS = 20
WORKFLOW_STEP_TIMEOUT = 60  # seconds per step

# Model-specific maximum context lengths
MODEL_CONTEXT_LENGTHS = {
    MODEL_SMOLLM2: 8192,
    MODEL_TINYLLAMA: 2048,
}

# Low RAM threshold (bytes) — use TinyLlama below this
LOW_RAM_THRESHOLD = 6 * 1024 * 1024 * 1024  # 6 GB

# Database
DB_FILENAME = "zdxai.db"
SCHEMA_VERSION = 4

# Router — Embedding Gravity Wells
ROUTER_MIN_GRAVITY_THRESHOLD = 0.5
ROUTER_WELL_SPLIT_VARIANCE_THRESHOLD = 0.3
ROUTER_WELL_MERGE_SIMILARITY_THRESHOLD = 0.95
ROUTER_FEEDBACK_EMA_ALPHA = 0.1
ROUTER_MASS_FLOOR = 0.1
ROUTER_GENESIS_COMPLEXITY_THRESHOLD = 0.6
ROUTER_WELL_MAINTENANCE_INTERVAL = 100
ROUTER_MAX_WELLS = 500
ROUTER_FEATURE_DIM = 8
ROUTER_CENTROID_DRIFT_ALPHA = 0.05

# Licensing
AUTH_BASE_URL = "https://auth.zerodrivex.com"
LICENSE_FILENAME = "license.json"
OFFLINE_GRACE_DAYS = 7

# System prompt
DEFAULT_SYSTEM_PROMPT = (
    "You are zdxai, a helpful local AI assistant running on the user's device. "
    "You are private, fast, and capable. You can help with questions, tasks, "
    "file management, and more. Be concise and accurate."
)


# BAN memory/reference runtime
BAN_MEMORY_SCHEMA_VERSION = "0.1"
BAN_MEMORY_TOP_K = 8
BAN_MEMORY_MIN_SCORE = 0.20
BAN_WORKING_MEMORY_CHARS = 6000
# Relevance weights score relationship usefulness, not equivalence.
BAN_SEMANTIC_WEIGHT = 0.35
BAN_TAG_WEIGHT = 0.30
BAN_CATEGORY_WEIGHT = 0.10
BAN_STRATEGY_WEIGHT = 0.10
BAN_FAILURE_WEIGHT = 0.10
BAN_RECENCY_WEIGHT = 0.05
