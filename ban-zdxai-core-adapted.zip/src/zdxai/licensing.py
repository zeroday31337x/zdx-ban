"""License verification for zdxai.

Tiers:
  - consumer:   Requires periodic online refresh. 7-day offline grace period.
  - enterprise: One-time activation. No online check after initial activation.

Flow:
  1. `zdxai --activate` prompts for email/password, calls auth1 login endpoint.
  2. Server response JWT is decoded to read `premium` and `zdxai_enterprise` claims.
  3. Credentials + metadata are persisted to <data_dir>/license.json.
  4. On every startup, `verify_license()` is called:
     - Enterprise: license file present + valid structure → pass (no network).
     - Premium:    refresh token is used to obtain a new JWT. On network failure,
                   an offline grace period of OFFLINE_GRACE_DAYS applies.
"""

from __future__ import annotations

import base64
import json
import logging
import getpass
from dataclasses import dataclass
from datetime import datetime, timezone, timedelta
from pathlib import Path

import httpx

from zdxai.constants import AUTH_BASE_URL, LICENSE_FILENAME, OFFLINE_GRACE_DAYS

logger = logging.getLogger(__name__)

PURCHASE_URL = f"{AUTH_BASE_URL}/pricing"


@dataclass
class LicenseInfo:
    email: str
    user_id: int
    tenant_id: int
    tier: str  # "consumer" or "enterprise"
    refresh_token: str
    last_verified: str
    activated_at: str


class LicenseError(Exception):
    """Raised when license verification fails."""


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _license_path(data_dir: Path) -> Path:
    return data_dir / LICENSE_FILENAME


def _decode_jwt_payload(token: str) -> dict:
    """Base64-decode the payload section of a JWT. No signature verification."""
    parts = token.split(".")
    if len(parts) != 3:
        raise LicenseError("Malformed JWT returned by auth server.")
    payload_b64 = parts[1]
    # Add padding if needed
    padding = 4 - len(payload_b64) % 4
    if padding != 4:
        payload_b64 += "=" * padding
    try:
        payload_bytes = base64.urlsafe_b64decode(payload_b64)
        return json.loads(payload_bytes)
    except (ValueError, json.JSONDecodeError) as exc:
        raise LicenseError(f"Failed to decode JWT payload: {exc}") from exc


def _determine_tier(claims: dict) -> str:
    """Determine the user tier from JWT claims.

    Returns 'enterprise' if zdxai_enterprise claim is truthy.
    Returns 'consumer' if the premium claim is truthy.
    Raises LicenseError otherwise.
    """
    if claims.get("zdxai_enterprise"):
        return "enterprise"
    if claims.get("premium"):
        return "consumer"
    raise LicenseError(
        "Your account does not have a zdxai subscription.\n"
        f"\nTo purchase a license, run: zdxai --purchase"
        f"\nOr visit: {PURCHASE_URL}"
    )


def _save_license(data_dir: Path, info: LicenseInfo) -> None:
    data_dir.mkdir(parents=True, exist_ok=True)
    path = _license_path(data_dir)
    payload = {
        "email": info.email,
        "user_id": info.user_id,
        "tenant_id": info.tenant_id,
        "tier": info.tier,
        "refresh_token": info.refresh_token,
        "last_verified": info.last_verified,
        "activated_at": info.activated_at,
    }
    path.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    # Restrict permissions: owner read/write only
    path.chmod(0o600)
    logger.info("License saved to %s", path)


def _load_license(data_dir: Path) -> dict:
    path = _license_path(data_dir)
    if not path.exists():
        raise LicenseError(
            "No license found. Run `zdxai --activate` to activate your license.\n"
            f"\nTo purchase a license, run: zdxai --purchase"
            f"\nOr visit: {PURCHASE_URL}"
        )
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError) as exc:
        raise LicenseError(f"Corrupt license file: {exc}") from exc


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def activate(data_dir: Path, email: str | None = None, password: str | None = None,
             auth_url: str = AUTH_BASE_URL) -> LicenseInfo:
    """Prompt for credentials (if not provided), authenticate, and save license."""
    if email is None:
        email = input("Email: ").strip()
    if password is None:
        password = getpass.getpass("Password: ")

    if not email or not password:
        raise LicenseError("Email and password are required.")

    login_url = f"{auth_url}/api/auth/user/login"
    logger.debug("POST %s", login_url)

    try:
        with httpx.Client(timeout=30) as client:
            resp = client.post(login_url, json={"email": email, "password": password})
    except httpx.TransportError as exc:
        raise LicenseError(f"Network error contacting auth server: {exc}") from exc

    if resp.status_code == 401:
        raise LicenseError("Invalid email or password.")
    if resp.status_code != 200:
        raise LicenseError(
            f"Auth server returned HTTP {resp.status_code}: {resp.text[:200]}"
        )

    # auth1 sets tokens as HttpOnly cookies (user-token = AT, rt = RT)
    access_token = resp.cookies.get("user-token") or ""
    refresh_token = resp.cookies.get("rt") or ""

    if not access_token:
        raise LicenseError("Auth server did not return an access token.")

    claims = _decode_jwt_payload(access_token)
    tier = _determine_tier(claims)

    now = datetime.now(timezone.utc).isoformat()
    info = LicenseInfo(
        email=email,
        user_id=claims.get("user_id", claims.get("sub", 0)),
        tenant_id=claims.get("tenant_id", 0),
        tier=tier,
        refresh_token=refresh_token,
        last_verified=now,
        activated_at=now,
    )

    _save_license(data_dir, info)
    return info


def verify_license(data_dir: Path, auth_url: str = AUTH_BASE_URL) -> LicenseInfo:
    """Verify stored license. Called on every startup.

    Enterprise: no network call — presence of a valid license file is sufficient.
    Premium: refresh the token online; fall back to offline grace period on network error.
    """
    raw = _load_license(data_dir)

    # Validate required fields
    for key in ("email", "user_id", "tier", "refresh_token", "last_verified", "activated_at"):
        if key not in raw:
            raise LicenseError(
                f"License file is missing '{key}'. Re-activate with `zdxai --activate`."
            )

    tier = raw["tier"]

    # --- Enterprise: no refresh needed ---
    if tier == "enterprise":
        logger.info("Enterprise license verified (offline-only).")
        return LicenseInfo(
            email=raw["email"],
            user_id=raw["user_id"],
            tenant_id=raw.get("tenant_id", 0),
            tier=tier,
            refresh_token=raw["refresh_token"],
            last_verified=raw["last_verified"],
            activated_at=raw["activated_at"],
        )

    # --- Premium: attempt online refresh ---
    refresh_url = f"{auth_url}/api/auth/tokens/refresh"
    logger.debug("POST %s", refresh_url)

    try:
        with httpx.Client(timeout=30) as client:
            # auth1 refresh expects the RT in body key "rt"
            resp = client.post(refresh_url, json={"rt": raw["refresh_token"]})
    except httpx.TransportError as exc:
        # Network failure — check grace period
        logger.warning("Network error during license refresh: %s", exc)
        return _check_grace_period(raw)

    if resp.status_code == 401:
        raise LicenseError(
            "License refresh denied (token expired or revoked). "
            "Run `zdxai --activate` to re-authenticate.\n"
            f"\nTo purchase a new license, visit: {PURCHASE_URL}"
        )
    if resp.status_code != 200:
        raise LicenseError(
            f"Auth server returned HTTP {resp.status_code} on refresh: {resp.text[:200]}"
        )

    # auth1 returns the new AT in the Authorization response header; RT stays the same
    auth_header = resp.headers.get("authorization", "")
    access_token = auth_header.split(" ", 1)[-1] if auth_header.lower().startswith("bearer ") else ""
    new_refresh = raw["refresh_token"]  # refresh route does not rotate the RT

    if not access_token:
        raise LicenseError("Auth server did not return an access token on refresh.")

    claims = _decode_jwt_payload(access_token)
    tier = _determine_tier(claims)

    now = datetime.now(timezone.utc).isoformat()

    info = LicenseInfo(
        email=raw["email"],
        user_id=raw["user_id"],
        tenant_id=raw.get("tenant_id", 0),
        tier=tier,
        refresh_token=new_refresh,
        last_verified=now,
        activated_at=raw["activated_at"],
    )

    # Persist updated token + timestamp
    _save_license(data_dir, info)
    logger.info("Premium license refreshed successfully.")
    return info


def _check_grace_period(raw: dict) -> LicenseInfo:
    """Allow offline startup within OFFLINE_GRACE_DAYS of last successful verification."""
    try:
        last = datetime.fromisoformat(raw["last_verified"])
    except (ValueError, KeyError) as exc:
        raise LicenseError(
            "Cannot determine last verification date. "
            "Run `zdxai --activate` while online."
        ) from exc

    now = datetime.now(timezone.utc)
    # Ensure last is tz-aware
    if last.tzinfo is None:
        last = last.replace(tzinfo=timezone.utc)

    elapsed = now - last
    if elapsed > timedelta(days=OFFLINE_GRACE_DAYS):
        raise LicenseError(
            f"Offline grace period expired ({OFFLINE_GRACE_DAYS} days). "
            "Connect to the internet and run `zdxai --activate` to re-verify."
        )

    remaining = OFFLINE_GRACE_DAYS - elapsed.days
    logger.warning(
        "Offline mode: license last verified %s (%d day(s) of grace remaining).",
        raw["last_verified"],
        remaining,
    )

    return LicenseInfo(
        email=raw["email"],
        user_id=raw["user_id"],
        tenant_id=raw.get("tenant_id", 0),
        tier=raw["tier"],
        refresh_token=raw["refresh_token"],
        last_verified=raw["last_verified"],
        activated_at=raw["activated_at"],
    )


def purchase_license() -> None:
    """Open the browser to the pricing page to purchase a zdxai license."""
    print(f"Purchase a zdxai license at: {PURCHASE_URL}")
    import webbrowser
    webbrowser.open(PURCHASE_URL)


def deactivate(data_dir: Path) -> None:
    """Remove stored license file."""
    path = _license_path(data_dir)
    if path.exists():
        path.unlink()
        logger.info("License removed: %s", path)
    else:
        logger.info("No license file to remove.")
