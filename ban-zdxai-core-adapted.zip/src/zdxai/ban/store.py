"""SQLite persistence for BAN tiered memory, references, and attribution."""

from __future__ import annotations

import hashlib
import json
import uuid
from datetime import datetime, timezone
from typing import Any

import numpy as np

from zdxai.ban.tags import merge_tags, normalize_tag
from zdxai.ban.types import (
    Authority,
    ContextTag,
    MemoryEffect,
    MemoryRecord,
    MemoryReference,
    MemoryTier,
    OperationalFailure,
    SupportState,
)
from zdxai.storage.database import Database
from zdxai.storage.embeddings_store import blob_to_embedding, embedding_to_blob


def _new_id(prefix: str) -> str:
    return f"{prefix}-{uuid.uuid4().hex}"


def _now_iso() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%fZ")


class BANMemoryStore:
    """Durable BAN memory store.

    Semantic memories and operational/runtime failures are deliberately kept in
    separate tables so infrastructure accidents cannot become reasoning lessons.
    """

    def __init__(self, db: Database) -> None:
        self._db = db

    def put(self, record: MemoryRecord) -> MemoryRecord:
        now = _now_iso()
        if not record.id:
            record.id = _new_id("memory")
        if not record.created_at:
            record.created_at = now
        record.updated_at = now
        record.tags = merge_tags(record.tags)

        embedding_blob = embedding_to_blob(record.embedding) if record.embedding is not None else None
        self._db.execute(
            """
            INSERT INTO ban_memories (
                id, content, summary, tier, category, strategy, outcome,
                support, authority, failure_relevant, confidence, embedding,
                provenance_json, created_at, updated_at, last_used_at, use_count,
                superseded_by, is_active
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ON CONFLICT(id) DO UPDATE SET
                content=excluded.content,
                summary=excluded.summary,
                tier=excluded.tier,
                category=excluded.category,
                strategy=excluded.strategy,
                outcome=excluded.outcome,
                support=excluded.support,
                authority=excluded.authority,
                failure_relevant=excluded.failure_relevant,
                confidence=excluded.confidence,
                embedding=excluded.embedding,
                provenance_json=excluded.provenance_json,
                updated_at=excluded.updated_at,
                superseded_by=excluded.superseded_by,
                is_active=excluded.is_active
            """,
            (
                record.id,
                record.content,
                record.summary,
                record.tier.value,
                record.category,
                record.strategy,
                record.outcome,
                record.support.value,
                record.authority.value,
                int(record.failure_relevant),
                max(0.0, min(1.0, record.confidence)),
                embedding_blob,
                json.dumps(record.provenance, sort_keys=True, separators=(",", ":")),
                record.created_at,
                record.updated_at,
                record.last_used_at,
                record.use_count,
                record.superseded_by,
                int(record.is_active),
            ),
        )
        self._db.execute("DELETE FROM ban_memory_tags WHERE memory_id = ?", (record.id,))
        for tag in record.tags:
            self._db.execute(
                "INSERT INTO ban_memory_tags (memory_id, tag, tag_kind, weight) VALUES (?, ?, ?, ?)",
                (record.id, normalize_tag(tag.value), tag.kind, tag.weight),
            )
        self._db.commit()
        return record

    def get(self, memory_id: str) -> MemoryRecord | None:
        row = self._db.execute("SELECT * FROM ban_memories WHERE id = ?", (memory_id,)).fetchone()
        return self._row_to_record(row) if row else None

    def list_active(self, limit: int = 10000) -> list[MemoryRecord]:
        rows = self._db.execute(
            "SELECT * FROM ban_memories WHERE is_active = 1 ORDER BY created_at DESC LIMIT ?",
            (limit,),
        ).fetchall()
        return [self._row_to_record(row) for row in rows]

    def supersede(self, old_id: str, new_id: str) -> None:
        self._db.execute(
            "UPDATE ban_memories SET superseded_by = ?, is_active = 0, updated_at = ? WHERE id = ?",
            (new_id, _now_iso(), old_id),
        )
        self._db.commit()
        self.record_event("SUPERSEDED", old_id, {"superseded_by": new_id})

    def add_relation(
        self,
        from_memory_id: str,
        to_memory_id: str,
        relation: str,
        score: float = 1.0,
        metadata: dict[str, Any] | None = None,
    ) -> str:
        relation_id = _new_id("relation")
        self._db.execute(
            """
            INSERT INTO ban_memory_relations
                (id, from_memory_id, to_memory_id, relation, score, metadata_json, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?)
            """,
            (
                relation_id,
                from_memory_id,
                to_memory_id,
                relation,
                score,
                json.dumps(metadata or {}, sort_keys=True, separators=(",", ":")),
                _now_iso(),
            ),
        )
        self._db.commit()
        return relation_id

    def record_retrieval(
        self,
        run_id: str,
        query_hash: str,
        reference: MemoryReference,
    ) -> str:
        rid = _new_id("retrieval")
        r = reference.reason
        self._db.execute(
            """
            INSERT INTO ban_memory_retrievals (
                id, run_id, query_hash, memory_id, relation, total_score,
                semantic_score, tag_score, category_match, strategy_match,
                failure_relevant, tier, recency, used, rejected, conflicted,
                effect, created_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                rid,
                run_id,
                query_hash,
                reference.memory.id,
                reference.relation,
                r.score,
                r.semantic_similarity,
                r.tag_similarity,
                int(r.category_match),
                int(r.strategy_match),
                int(r.failure_relevant),
                r.tier.value,
                r.recency,
                int(reference.used),
                int(reference.rejected),
                int(reference.conflicted),
                reference.effect.value,
                _now_iso(),
            ),
        )
        self._db.commit()
        return rid

    def mark_used(self, memory_id: str) -> None:
        self._db.execute(
            "UPDATE ban_memories SET use_count = use_count + 1, last_used_at = ?, updated_at = ? WHERE id = ?",
            (_now_iso(), _now_iso(), memory_id),
        )
        self._db.commit()

    def record_event(self, event_type: str, memory_id: str | None, payload: dict[str, Any]) -> str:
        event_id = _new_id("memory-event")
        self._db.execute(
            "INSERT INTO ban_memory_events (id, event_type, memory_id, payload_json, created_at) VALUES (?, ?, ?, ?, ?)",
            (
                event_id,
                event_type,
                memory_id,
                json.dumps(payload, sort_keys=True, separators=(",", ":")),
                _now_iso(),
            ),
        )
        self._db.commit()
        return event_id

    def record_operational_failure(self, failure: OperationalFailure, run_id: str = "") -> str:
        event_id = _new_id("operational")
        self._db.execute(
            """
            INSERT INTO ban_operational_events
                (id, run_id, provider, code, message, retryable, metadata_json, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                event_id,
                run_id,
                failure.provider,
                failure.code,
                failure.message,
                int(failure.retryable),
                json.dumps(failure.metadata, sort_keys=True, separators=(",", ":")),
                _now_iso(),
            ),
        )
        self._db.commit()
        return event_id

    def snapshot_hash(self) -> str:
        """Stable hash of active semantic memory state for experiments/replay."""
        rows = self._db.execute(
            """
            SELECT id, content, summary, tier, category, strategy, outcome, support,
                   authority, failure_relevant, confidence, provenance_json,
                   superseded_by, is_active
            FROM ban_memories WHERE is_active = 1 ORDER BY id
            """
        ).fetchall()
        state: list[dict[str, Any]] = []
        for row in rows:
            tags = self._db.execute(
                "SELECT tag, tag_kind, weight FROM ban_memory_tags WHERE memory_id = ? ORDER BY tag_kind, tag",
                (row["id"],),
            ).fetchall()
            state.append(
                {
                    "memory": dict(row),
                    "tags": [dict(t) for t in tags],
                }
            )
        raw = json.dumps(state, sort_keys=True, separators=(",", ":")).encode("utf-8")
        return hashlib.sha256(raw).hexdigest()

    def _row_to_record(self, row) -> MemoryRecord:
        tag_rows = self._db.execute(
            "SELECT tag, tag_kind, weight FROM ban_memory_tags WHERE memory_id = ? ORDER BY tag_kind, tag",
            (row["id"],),
        ).fetchall()
        tags = [ContextTag(t["tag"], t["tag_kind"], float(t["weight"])) for t in tag_rows]
        embedding = blob_to_embedding(row["embedding"]) if row["embedding"] is not None else None
        return MemoryRecord(
            id=row["id"],
            content=row["content"],
            summary=row["summary"] or "",
            tier=MemoryTier(row["tier"]),
            category=row["category"] or "",
            strategy=row["strategy"] or "",
            outcome=row["outcome"] or "",
            support=SupportState(row["support"]),
            authority=Authority(row["authority"]),
            failure_relevant=bool(row["failure_relevant"]),
            confidence=float(row["confidence"]),
            tags=tags,
            embedding=embedding,
            provenance=json.loads(row["provenance_json"] or "{}"),
            created_at=row["created_at"],
            updated_at=row["updated_at"],
            last_used_at=row["last_used_at"],
            use_count=int(row["use_count"]),
            superseded_by=row["superseded_by"],
            is_active=bool(row["is_active"]),
        )
