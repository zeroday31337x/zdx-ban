"""BAN tiered memory retrieval and working-context construction."""

from __future__ import annotations

import hashlib
import math
import uuid
from datetime import datetime, timezone
from typing import Iterable

import numpy as np

from zdxai.ban.store import BANMemoryStore
from zdxai.ban.tags import extract_context_tags, merge_tags, tag_similarity
from zdxai.ban.types import (
    ContextTag,
    MemoryRecord,
    MemoryReference,
    MemoryTier,
    RetrievalReason,
    WorkingMemory,
)
from zdxai.config import Config
from zdxai.core.embeddings import EmbeddingEngine

_EPS = 1e-10


def _cosine(a: np.ndarray | None, b: np.ndarray | None) -> float:
    if a is None or b is None:
        return 0.0
    na = float(np.linalg.norm(a))
    nb = float(np.linalg.norm(b))
    if na <= _EPS or nb <= _EPS:
        return 0.0
    # map cosine [-1, 1] to relevance [0, 1]
    return max(0.0, min(1.0, (float(np.dot(a, b) / (na * nb)) + 1.0) / 2.0))


def _recency(created_at: str) -> float:
    if not created_at:
        return 0.0
    try:
        then = datetime.fromisoformat(created_at.replace("Z", "+00:00"))
        age_days = max(0.0, (datetime.now(timezone.utc) - then).total_seconds() / 86400.0)
    except ValueError:
        return 0.0
    # Slow exponential decay: reference relevance halves roughly every 90 days.
    return math.exp(-age_days / 129.84)


class BANMemory:
    """Retrieve historical references without turning similarity into identity."""

    def __init__(
        self,
        config: Config,
        store: BANMemoryStore,
        embedding_engine: EmbeddingEngine,
    ) -> None:
        self.config = config
        self.store = store
        self.embedding_engine = embedding_engine

    def remember(self, record: MemoryRecord) -> MemoryRecord:
        if record.embedding is None and self.embedding_engine.is_loaded:
            record.embedding = self.embedding_engine.embed(record.content)
        return self.store.put(record)

    def retrieve(
        self,
        query: str,
        *,
        supplied_tags: Iterable[ContextTag | str] = (),
        category: str = "",
        strategy: str = "",
        failure_context: bool = False,
        top_k: int | None = None,
        run_id: str | None = None,
    ) -> list[MemoryReference]:
        if not self.embedding_engine.is_loaded:
            return []

        query_embedding = self.embedding_engine.embed(query)
        query_tags = merge_tags(extract_context_tags(query), supplied_tags)
        candidates = self.store.list_active()
        references: list[MemoryReference] = []

        for memory in candidates:
            if memory.tier == MemoryTier.OPERATIONAL:
                continue
            semantic = _cosine(query_embedding, memory.embedding)
            tags = tag_similarity(query_tags, memory.tags)
            category_match = bool(category and memory.category and category == memory.category)
            strategy_match = bool(strategy and memory.strategy and strategy == memory.strategy)
            recency = _recency(memory.created_at)

            # Score relationship relevance, not sameness.  Support state is
            # intentionally not a positive scoring term: contradicted or
            # misleading history must remain retrievable for recovery tests.
            score = (
                self.config.ban_semantic_weight * semantic
                + self.config.ban_tag_weight * tags
                + self.config.ban_category_weight * float(category_match)
                + self.config.ban_strategy_weight * float(strategy_match)
                + self.config.ban_failure_weight * float(failure_context and memory.failure_relevant)
                + self.config.ban_recency_weight * recency
            )
            tier_multiplier = self.config.ban_tier_weights.get(memory.tier.value, 1.0)
            score *= tier_multiplier
            score = max(0.0, min(1.0, score))

            if score < self.config.ban_memory_min_score:
                continue

            references.append(
                MemoryReference(
                    memory=memory,
                    reason=RetrievalReason(
                        semantic_similarity=semantic,
                        tag_similarity=tags,
                        category_match=category_match,
                        strategy_match=strategy_match,
                        failure_relevant=memory.failure_relevant,
                        tier=memory.tier,
                        recency=recency,
                        score=score,
                    ),
                )
            )

        references.sort(key=lambda ref: (-ref.reason.score, ref.memory.id))
        references = references[: (top_k or self.config.ban_memory_top_k)]

        run = run_id or f"ban-{uuid.uuid4().hex}"
        query_hash = hashlib.sha256(query.encode("utf-8")).hexdigest()
        for ref in references:
            self.store.record_retrieval(run, query_hash, ref)
        return references

    def build_working_memory(self, references: list[MemoryReference]) -> WorkingMemory:
        """Build bounded reference context for the model.

        Current evidence has explicit precedence.  Historical records are
        presented with support/authority metadata so the model can use, reject,
        or contradict them rather than inheriting them as facts.
        """
        if not references:
            return WorkingMemory(snapshot_hash=self.store.snapshot_hash())

        header = (
            "## BAN Historical References\n"
            "These are references to prior observations, not declarations that the "
            "current situation is the same. Current measurements/evidence outrank "
            "historical memory. Preserve novel or unknown candidates when history "
            "does not explain the current evidence.\n"
        )
        parts = [header]
        char_budget = max(512, self.config.ban_working_memory_chars)

        for ref in references:
            m = ref.memory
            tag_text = " ".join(f"#{tag.value}" for tag in m.tags[:16])
            relation = ref.relation
            block = (
                f"\n[reference id={m.id} relation={relation} score={ref.reason.score:.3f} "
                f"tier={m.tier.value} support={m.support.value} authority={m.authority.value}]\n"
                f"tags: {tag_text or '(none)'}\n"
                f"category: {m.category or '(unspecified)'}; strategy: {m.strategy or '(unspecified)'}\n"
                f"historical observation: {m.summary or m.content}\n"
            )
            if sum(len(p) for p in parts) + len(block) > char_budget:
                break
            parts.append(block)

        text = "".join(parts)
        guidance_hash = hashlib.sha256(text.encode("utf-8")).hexdigest()
        return WorkingMemory(
            references=references,
            context_text=text,
            guidance_hash=guidance_hash,
            snapshot_hash=self.store.snapshot_hash(),
        )
