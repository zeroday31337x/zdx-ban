"""BAN local-model runtime built on the existing ZDXAI inference wrapper."""

from __future__ import annotations

import logging
import time
import uuid
from collections.abc import Iterable, Iterator
from dataclasses import dataclass

from zdxai.ban.memory import BANMemory
from zdxai.ban.store import BANMemoryStore
from zdxai.ban.tags import merge_tags
from zdxai.ban.types import (
    Authority,
    ContextTag,
    MeasurementContract,
    MemoryRecord,
    MemoryTier,
    OperationalFailure,
    SupportState,
    WorkingMemory,
)
from zdxai.config import Config
from zdxai.core.embeddings import EmbeddingEngine
from zdxai.core.inference import CompletionResult, InferenceEngine
from zdxai.storage.database import Database

log = logging.getLogger(__name__)

BAN_SYSTEM_DIRECTIVE = (
    "You are running inside the BAN reasoning architecture. Historical memory is "
    "guidance, not current evidence. A context reference indicates a relationship, "
    "not equivalence. Prefer current observations and authoritative measurements over "
    "memory. If the present evidence does not fit prior lessons, preserve the novel "
    "candidate rather than forcing it into an old pattern."
)


@dataclass
class BANCompletion:
    result: CompletionResult
    working_memory: WorkingMemory
    run_id: str


class BANRuntime:
    """Direct GGUF runtime with BAN memory/reference semantics.

    This deliberately avoids an Ollama server boundary. llama-cpp-python owns the
    local model directly, while BAN memory/measurement state stays durable in the
    same SQLite database.
    """

    def __init__(self, config: Config) -> None:
        self.config = config
        self.db = Database(config.db_path)
        self.inference = InferenceEngine(config)
        self.embeddings = EmbeddingEngine(config)
        self.memory_store: BANMemoryStore | None = None
        self.memory: BANMemory | None = None

    def startup(self, *, load_model: bool = True, load_embeddings: bool = True) -> None:
        self.config.ensure_dirs()
        self.db.open()
        self.db.migrate()
        self.memory_store = BANMemoryStore(self.db)

        if load_model:
            if not self.config.model_path.exists():
                raise FileNotFoundError(f"BAN model not found: {self.config.model_path}")
            self.inference.load()

        if load_embeddings and self.config.embedding_model_path.exists():
            self.embeddings.load()
        elif load_embeddings:
            log.warning("BAN embedding model not found at %s; memory retrieval disabled.", self.config.embedding_model_path)

        self.memory = BANMemory(self.config, self.memory_store, self.embeddings)

    def shutdown(self) -> None:
        self.inference.unload()
        self.embeddings.unload()
        self.db.close()

    def prepare_working_memory(
        self,
        query: str,
        *,
        tags: Iterable[ContextTag | str] = (),
        category: str = "",
        strategy: str = "",
        failure_context: bool = False,
        run_id: str | None = None,
    ) -> WorkingMemory:
        if self.memory is None:
            raise RuntimeError("BANRuntime not started")
        references = self.memory.retrieve(
            query,
            supplied_tags=merge_tags(tags),
            category=category,
            strategy=strategy,
            failure_context=failure_context,
            run_id=run_id,
        )
        return self.memory.build_working_memory(references)

    def chat(
        self,
        query: str,
        *,
        tags: Iterable[ContextTag | str] = (),
        category: str = "",
        strategy: str = "",
        failure_context: bool = False,
        system_prompt: str | None = None,
    ) -> BANCompletion:
        if not self.inference.is_loaded:
            raise RuntimeError("Model not loaded")
        run_id = f"ban-{uuid.uuid4().hex}"
        working = self.prepare_working_memory(
            query,
            tags=tags,
            category=category,
            strategy=strategy,
            failure_context=failure_context,
            run_id=run_id,
        )
        messages = self._messages(query, working, system_prompt)
        try:
            result = self.inference.chat(messages)
        except Exception as exc:
            self.record_operational_failure(
                OperationalFailure(
                    provider="llama_cpp",
                    code="INFERENCE_ERROR",
                    message=str(exc),
                    retryable=False,
                ),
                run_id=run_id,
            )
            raise
        return BANCompletion(result=result, working_memory=working, run_id=run_id)

    def chat_stream(
        self,
        query: str,
        *,
        tags: Iterable[ContextTag | str] = (),
        category: str = "",
        strategy: str = "",
        failure_context: bool = False,
        system_prompt: str | None = None,
    ) -> Iterator[str]:
        """Genuine model streaming; chunks are yielded as llama.cpp produces them."""
        if not self.inference.is_loaded:
            raise RuntimeError("Model not loaded")
        run_id = f"ban-{uuid.uuid4().hex}"
        working = self.prepare_working_memory(
            query,
            tags=tags,
            category=category,
            strategy=strategy,
            failure_context=failure_context,
            run_id=run_id,
        )
        messages = self._messages(query, working, system_prompt)
        try:
            yield from self.inference.chat_stream(messages)
        except Exception as exc:
            self.record_operational_failure(
                OperationalFailure("llama_cpp", "INFERENCE_STREAM_ERROR", str(exc), False),
                run_id=run_id,
            )
            raise

    def remember_episode(
        self,
        *,
        content: str,
        tags: Iterable[ContextTag | str] = (),
        category: str = "",
        strategy: str = "",
        outcome: str = "",
        support: SupportState = SupportState.UNKNOWN,
        authority: Authority = Authority.UNKNOWN,
        confidence: float = 0.5,
        failure_relevant: bool = False,
        measurement: MeasurementContract | None = None,
        provenance: dict | None = None,
        memory_id: str = "",
    ) -> MemoryRecord | None:
        """Persist a semantic episode only when its epistemic status is explicit.

        Provider/runtime failures must use record_operational_failure() instead.
        If ban_require_measurement_for_semantic_memory is enabled, unverified model
        output cannot silently become learned domain knowledge.
        """
        if self.memory is None:
            raise RuntimeError("BANRuntime not started")
        if self.config.ban_require_measurement_for_semantic_memory:
            if measurement is None or not measurement.compliant:
                return None

        record = MemoryRecord(
            id=memory_id,
            content=content,
            tier=MemoryTier.EPISODIC,
            category=category,
            strategy=strategy,
            outcome=outcome,
            support=support,
            authority=authority,
            failure_relevant=failure_relevant,
            confidence=confidence,
            tags=merge_tags(tags),
            provenance={
                **(provenance or {}),
                "measurement": (
                    {
                        "contract_id": measurement.contract_id,
                        "claim": measurement.claim,
                        "outcome": measurement.outcome,
                        "verification_class": measurement.verification_class,
                        "authority": measurement.authority.value,
                        "repeatable": measurement.repeatable,
                        "method": measurement.method,
                        "evidence": measurement.evidence,
                    }
                    if measurement
                    else None
                ),
            },
        )
        return self.memory.remember(record)

    def record_operational_failure(self, failure: OperationalFailure, run_id: str = "") -> str:
        if self.memory_store is None:
            raise RuntimeError("BANRuntime not started")
        return self.memory_store.record_operational_failure(failure, run_id=run_id)

    @staticmethod
    def _messages(query: str, working: WorkingMemory, system_prompt: str | None) -> list[dict[str, str]]:
        system = system_prompt or BAN_SYSTEM_DIRECTIVE
        if working.context_text:
            system = f"{system}\n\n{working.context_text}"
        return [
            {"role": "system", "content": system},
            {"role": "user", "content": query},
        ]
