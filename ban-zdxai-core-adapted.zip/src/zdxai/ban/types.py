"""Core BAN runtime types.

BAN memory uses historical observations as references.  A retrieved memory is
never an assertion that the current situation is equivalent to the historical
one; current measurements and evidence retain authority.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any

import numpy as np


class MemoryTier(str, Enum):
    """Persistence tier for a BAN memory."""

    BASE = "TIER_1_BASE"
    DOMAIN = "TIER_2_DOMAIN"
    EPISODIC = "TIER_3_EPISODIC"
    OPERATIONAL = "OPERATIONAL"


class SupportState(str, Enum):
    """Recorded support state of a historical memory."""

    SUPPORTED = "SUPPORTED"
    CONTRADICTED = "CONTRADICTED"
    INCONCLUSIVE = "INCONCLUSIVE"
    UNKNOWN = "UNKNOWN"
    UNVERIFIED = "UNVERIFIED"


class Authority(str, Enum):
    """Authority of the evidence that created the memory."""

    AUTHORITATIVE = "AUTHORITATIVE"
    MEASURED = "MEASURED"
    USER_SUPPLIED = "USER_SUPPLIED"
    MODEL_DERIVED = "MODEL_DERIVED"
    UNKNOWN = "UNKNOWN"


class MemoryEffect(str, Enum):
    """Observable behavioral effect of a retrieved memory."""

    HELPFUL = "HELPFUL"
    HARMFUL = "HARMFUL"
    NEUTRAL = "NEUTRAL"
    UNOBSERVABLE = "UNOBSERVABLE"


@dataclass(frozen=True)
class ContextTag:
    """A contextual reference dimension, not an equivalence claim."""

    value: str
    kind: str = "context"
    weight: float = 1.0


@dataclass
class MemoryRecord:
    id: str
    content: str
    tier: MemoryTier = MemoryTier.EPISODIC
    summary: str = ""
    category: str = ""
    strategy: str = ""
    outcome: str = ""
    support: SupportState = SupportState.UNKNOWN
    authority: Authority = Authority.UNKNOWN
    failure_relevant: bool = False
    confidence: float = 0.5
    tags: list[ContextTag] = field(default_factory=list)
    embedding: np.ndarray | None = None
    provenance: dict[str, Any] = field(default_factory=dict)
    created_at: str = ""
    updated_at: str = ""
    last_used_at: str | None = None
    use_count: int = 0
    superseded_by: str | None = None
    is_active: bool = True


@dataclass(frozen=True)
class RetrievalReason:
    semantic_similarity: float = 0.0
    tag_similarity: float = 0.0
    category_match: bool = False
    strategy_match: bool = False
    failure_relevant: bool = False
    tier: MemoryTier = MemoryTier.EPISODIC
    recency: float = 0.0
    score: float = 0.0


@dataclass
class MemoryReference:
    """A memory selected as potentially useful historical context."""

    memory: MemoryRecord
    reason: RetrievalReason
    relation: str = "context_reference"
    used: bool = False
    rejected: bool = False
    conflicted: bool = False
    effect: MemoryEffect = MemoryEffect.UNOBSERVABLE


@dataclass(frozen=True)
class MeasurementContract:
    """Observable measurement metadata used to gate semantic learning."""

    contract_id: str = ""
    claim: str = ""
    outcome: str = ""
    verification_class: str = "UNVERIFIED"
    authority: Authority = Authority.UNKNOWN
    repeatable: bool = False
    method: str = ""
    evidence: dict[str, Any] | None = None

    @property
    def compliant(self) -> bool:
        """Whether this contract provides enough evidence for semantic learning."""
        return bool(
            self.outcome
            and self.outcome.upper() not in {"ERROR", "FAILED", "PROVIDER_FAILURE"}
            and self.verification_class.upper() not in {"", "UNVERIFIED"}
            and self.method
        )


@dataclass(frozen=True)
class OperationalFailure:
    provider: str
    code: str
    message: str
    retryable: bool = False
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class WorkingMemory:
    references: list[MemoryReference] = field(default_factory=list)
    context_text: str = ""
    guidance_hash: str = ""
    snapshot_hash: str = ""
