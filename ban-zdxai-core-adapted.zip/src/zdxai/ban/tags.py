"""Deterministic context-tag normalization and scoring for BAN memory."""

from __future__ import annotations

import re
from collections.abc import Iterable

from zdxai.ban.types import ContextTag

_TOKEN = re.compile(r"[a-z0-9][a-z0-9_.:+/-]{1,63}")
_PATH = re.compile(r"(?:^|[\s\"'])[/~][\w./-]+|[A-Za-z]:\\[\w.\\-]+")
_URL = re.compile(r"https?://", re.I)

_STOP = frozenset(
    {
        "about", "after", "again", "also", "because", "before", "being",
        "between", "could", "does", "from", "have", "into", "just", "like",
        "more", "other", "should", "some", "than", "that", "their", "there",
        "these", "they", "this", "those", "through", "very", "what", "when",
        "where", "which", "while", "with", "would", "your",
    }
)


def normalize_tag(value: str) -> str:
    """Normalize a tag while preserving discriminative separators."""
    value = value.strip().lower().lstrip("#")
    value = re.sub(r"\s+", "_", value)
    value = re.sub(r"[^a-z0-9_.:+/-]+", "", value)
    return value[:96]


def merge_tags(*tag_sets: Iterable[ContextTag | str]) -> list[ContextTag]:
    """Merge tags deterministically, keeping the strongest weight per key."""
    merged: dict[tuple[str, str], ContextTag] = {}
    for tag_set in tag_sets:
        for raw in tag_set:
            tag = raw if isinstance(raw, ContextTag) else ContextTag(normalize_tag(raw))
            value = normalize_tag(tag.value)
            if not value:
                continue
            key = (tag.kind, value)
            candidate = ContextTag(value=value, kind=tag.kind, weight=max(0.0, tag.weight))
            previous = merged.get(key)
            if previous is None or candidate.weight > previous.weight:
                merged[key] = candidate
    return sorted(merged.values(), key=lambda t: (t.kind, t.value))


def extract_context_tags(text: str) -> list[ContextTag]:
    """Extract lightweight deterministic reference tags from current input.

    These tags identify contextual dimensions only.  They do not classify the
    new observation as equivalent to any historical memory.
    """
    lower = text.lower()
    tags: list[ContextTag] = []

    if _PATH.search(text):
        tags.append(ContextTag("path_reference", "structure", 1.0))
    if _URL.search(text):
        tags.append(ContextTag("url_reference", "structure", 1.0))
    if any(ch in text for ch in "{}();[]=><"):
        tags.append(ContextTag("code", "modality", 1.0))
    if any(ch.isdigit() for ch in text) and any(op in text for op in "+-*/=%"):
        tags.append(ContextTag("math", "modality", 0.9))

    domain_markers = {
        "python": ("python", "domain"),
        "golang": ("go", "domain"),
        " go ": ("go", "domain"),
        "sqlite": ("sqlite", "domain"),
        "postgres": ("postgres", "domain"),
        "ollama": ("ollama", "runtime"),
        "llama": ("llama_cpp", "runtime"),
        "gguf": ("gguf", "runtime"),
        "arm64": ("arm64", "platform"),
        "android": ("android", "platform"),
        "termux": ("termux", "platform"),
        "memory": ("memory", "capability"),
        "cache": ("cache", "capability"),
        "debug": ("debugging", "task"),
        "error": ("failure", "task"),
        "failed": ("failure", "task"),
        "benchmark": ("benchmark", "task"),
        "experiment": ("experiment", "task"),
        "measure": ("measurement", "task"),
    }
    padded = f" {lower} "
    for marker, (value, kind) in domain_markers.items():
        if marker in padded:
            tags.append(ContextTag(value, kind, 1.0))

    # Add a bounded set of discriminative lexical references.  They are lower
    # weight than explicit/user supplied tags and structural tags.
    lexical: list[str] = []
    for match in _TOKEN.finditer(lower):
        token = match.group(0).strip("./:+-")
        if len(token) < 4 or token in _STOP or token.isdigit():
            continue
        if token not in lexical:
            lexical.append(token)
        if len(lexical) >= 12:
            break
    tags.extend(ContextTag(token, "lexical", 0.35) for token in lexical)

    return merge_tags(tags)


def tag_similarity(query_tags: Iterable[ContextTag], memory_tags: Iterable[ContextTag]) -> float:
    """Weighted overlap of independent context references.

    More distinct matching tags reduce ambiguity.  Duplicate/near-identical
    tags do not multiply evidence because tags are normalized to unique keys.
    """
    q = {(t.kind, normalize_tag(t.value)): max(0.0, t.weight) for t in query_tags if normalize_tag(t.value)}
    m = {(t.kind, normalize_tag(t.value)): max(0.0, t.weight) for t in memory_tags if normalize_tag(t.value)}
    if not q or not m:
        return 0.0

    keys = set(q) | set(m)
    numerator = sum(min(q.get(k, 0.0), m.get(k, 0.0)) for k in keys)
    denominator = sum(max(q.get(k, 0.0), m.get(k, 0.0)) for k in keys)
    if denominator <= 0.0:
        return 0.0
    return min(1.0, numerator / denominator)
