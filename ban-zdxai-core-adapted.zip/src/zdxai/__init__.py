"""zdxai — Local, on-device AI assistant."""

from zdxai.constants import APP_NAME, APP_VERSION

__version__ = APP_VERSION
