"""System prompt and context assembly for chat completion."""

from __future__ import annotations

from zdxai.config import Config
from zdxai.storage.conversations import Message


def build_messages(
    config: Config,
    history: list[Message],
    user_input: str,
    rag_context: str | None = None,
    tool_results: list[dict[str, str]] | None = None,
) -> list[dict[str, str]]:
    """Assemble the full message list for inference.

    Priority ordering:
    1. System prompt (always)
    2. RAG context (if any, injected into system prompt)
    3. Conversation history (recent messages)
    4. Tool results (if any)
    5. Current user message
    """
    system_content = config.system_prompt

    if rag_context:
        system_content += (
            "\n\n## Relevant Context\n"
            "Use the following information to help answer the user's question:\n\n"
            + rag_context
        )

    messages: list[dict[str, str]] = [
        {"role": "system", "content": system_content}
    ]

    # Add conversation history
    for msg in history:
        if msg.role in ("user", "assistant"):
            messages.append({"role": msg.role, "content": msg.content})
        elif msg.role == "tool" and msg.tool_output:
            # Include tool results in the history
            messages.append({
                "role": "assistant",
                "content": f"[Tool: {msg.tool_name}] {msg.tool_output}",
            })

    # Add any pending tool results
    if tool_results:
        for tr in tool_results:
            messages.append({"role": "assistant", "content": tr["content"]})

    # Add current user message
    messages.append({"role": "user", "content": user_input})

    return messages
