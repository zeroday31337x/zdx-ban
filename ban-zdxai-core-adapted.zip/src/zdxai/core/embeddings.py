"""Embedding generation via llama-cpp-python with the MiniLM model."""

from __future__ import annotations

import logging

import numpy as np

from zdxai.config import Config

log = logging.getLogger(__name__)


class EmbeddingEngine:
    """Generate embeddings using the all-MiniLM-L6-v2 GGUF model."""

    def __init__(self, config: Config) -> None:
        self._config = config
        self._model = None

    @property
    def is_loaded(self) -> bool:
        return self._model is not None

    def load(self) -> None:
        """Load the embedding model."""
        from llama_cpp import Llama

        model_path = str(self._config.embedding_model_path)
        log.info("Loading embedding model: %s", model_path)

        self._model = Llama(
            model_path=model_path,
            n_ctx=512,
            n_threads=max(1, self._config.threads // 2),
            n_gpu_layers=0,
            embedding=True,
            verbose=False,
        )
        log.info("Embedding model loaded.")

    def unload(self) -> None:
        if self._model is not None:
            del self._model
            self._model = None

    def embed(self, text: str) -> np.ndarray:
        """Generate a single embedding vector."""
        if self._model is None:
            raise RuntimeError("Embedding model not loaded. Call load() first.")
        result = self._model.embed(text)
        # llama-cpp-python may return list or list-of-lists
        if isinstance(result[0], list):
            vec = result[0]
        else:
            vec = result
        return np.array(vec, dtype=np.float32)

    def embed_batch(self, texts: list[str]) -> list[np.ndarray]:
        """Generate embeddings for multiple texts."""
        return [self.embed(t) for t in texts]
