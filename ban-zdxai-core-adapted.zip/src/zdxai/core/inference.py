"""llama-cpp-python wrapper for model inference."""

from __future__ import annotations

import logging
import time
from collections.abc import Iterator
from dataclasses import dataclass
from pathlib import Path

from zdxai.config import Config

log = logging.getLogger(__name__)


@dataclass
class CompletionResult:
    content: str
    tokens_prompt: int
    tokens_completion: int
    latency_ms: int
    model_id: str


class InferenceEngine:
    """Wraps llama-cpp-python for chat completion."""

    def __init__(self, config: Config) -> None:
        self._config = config
        self._model = None
        self._model_path: str = ""

    @property
    def is_loaded(self) -> bool:
        return self._model is not None

    def load(self) -> None:
        """Load the GGUF model into memory."""
        from llama_cpp import Llama

        model_path = str(self._config.model_path)
        log.info("Loading model: %s", model_path)
        start = time.monotonic()

        kwargs = {
            "model_path": model_path,
            "n_ctx": self._config.context_length,
            "n_threads": self._config.threads,
            "n_gpu_layers": self._config.gpu_layers,
            "verbose": False,
        }

        # Load LoRA adapter if configured
        if self._config.adapter_path:
            adapter = Path(self._config.adapter_path)
            if adapter.exists():
                kwargs["lora_path"] = str(adapter)
                log.info("Loading LoRA adapter: %s", adapter)

        self._model = Llama(**kwargs)
        self._model_path = model_path
        elapsed = time.monotonic() - start
        log.info("Model loaded in %.1fs", elapsed)

    def unload(self) -> None:
        """Free model from memory."""
        if self._model is not None:
            del self._model
            self._model = None
            self._model_path = ""
            log.info("Model unloaded.")

    def reload_adapter(self, adapter_path: str | None) -> None:
        """Hot-swap LoRA adapter by reloading the model."""
        self._config.adapter_path = adapter_path
        self.unload()
        self.load()

    def chat(self, messages: list[dict[str, str]]) -> CompletionResult:
        """Single-shot chat completion. Returns full result."""
        if self._model is None:
            raise RuntimeError("Model not loaded. Call load() first.")

        start = time.monotonic()
        result = self._model.create_chat_completion(
            messages=messages,
            max_tokens=self._config.max_tokens,
            temperature=self._config.temperature,
            top_p=self._config.top_p,
        )
        elapsed_ms = int((time.monotonic() - start) * 1000)

        content = result["choices"][0]["message"]["content"] or ""
        usage = result.get("usage", {})

        return CompletionResult(
            content=content,
            tokens_prompt=usage.get("prompt_tokens", 0),
            tokens_completion=usage.get("completion_tokens", 0),
            latency_ms=elapsed_ms,
            model_id=self._config.model_filename,
        )

    def chat_stream(
        self, messages: list[dict[str, str]]
    ) -> Iterator[str]:
        """Streaming chat completion. Yields content tokens."""
        if self._model is None:
            raise RuntimeError("Model not loaded. Call load() first.")

        stream = self._model.create_chat_completion(
            messages=messages,
            max_tokens=self._config.max_tokens,
            temperature=self._config.temperature,
            top_p=self._config.top_p,
            stream=True,
        )

        for chunk in stream:
            delta = chunk["choices"][0].get("delta", {})
            token = delta.get("content")
            if token:
                yield token
