"""Main orchestrator tying inference, storage, RAG, and MCP together."""

from __future__ import annotations

import logging
import time
from collections.abc import Iterator
from dataclasses import dataclass
from pathlib import Path

from zdxai.config import Config
from zdxai.constants import MCP_MAX_TOOL_ITERATIONS
from zdxai.core.embeddings import EmbeddingEngine
from zdxai.core.inference import InferenceEngine, CompletionResult
from zdxai.core.prompt_builder import build_messages
from zdxai.memory.rag import RAGPipeline
from zdxai.mcp.server import MCPServer
from zdxai.router.router import QueryRouter
from zdxai.router.platforms.base import PlatformMessage
from zdxai.storage.conversations import ConversationStore, Conversation, Message
from zdxai.storage.database import Database
from zdxai.storage.preferences import PreferenceStore
from zdxai.training.adapter_manager import AdapterManager

log = logging.getLogger(__name__)


@dataclass
class ChatResponse:
    """Response from a chat turn."""
    content: str
    conversation_id: str
    tokens_prompt: int
    tokens_completion: int
    latency_ms: int


class Engine:
    """Central coordinator for zdxai."""

    def __init__(self, config: Config, permission_prompt_fn=None) -> None:
        self.config = config
        self.db = Database(config.db_path)
        self.conversations = ConversationStore(self.db)
        self.preferences = PreferenceStore(self.db)
        self.inference = InferenceEngine(config)
        self.embedding_engine = EmbeddingEngine(config)
        self.rag: RAGPipeline | None = None
        self.mcp: MCPServer | None = None
        self.adapter_manager: AdapterManager | None = None
        self.router: QueryRouter | None = None
        self._permission_prompt_fn = permission_prompt_fn
        self._current_conversation: Conversation | None = None
        # Track feedback signals from the previous turn for deferred evaluation
        self._prev_rag_was_used: bool = False
        self._prev_tool_calls_succeeded: int = 0
        self._prev_tool_calls_failed: int = 0

    @property
    def current_conversation(self) -> Conversation | None:
        return self._current_conversation

    def startup(self) -> None:
        """Initialize database and load models."""
        self.config.ensure_dirs()
        self.db.open()
        self.db.migrate()
        log.info("Database initialized.")

        # Initialize adapter manager
        self.adapter_manager = AdapterManager(self.config, self.db)

        # Initialize MCP server (pass engine for stateful tools)
        self.mcp = MCPServer(
            self.db,
            prompt_fn=self._permission_prompt_fn,
            engine=self,
        )

        if not self.config.model_path.exists():
            log.warning(
                "Model not found at %s. Run 'python -m zdxai.scripts.download_models' first.",
                self.config.model_path,
            )
            return

        self.inference.load()

        # Load embedding model if available
        if self.config.embedding_model_path.exists():
            try:
                self.embedding_engine.load()
                self.rag = RAGPipeline(self.config, self.db, self.embedding_engine)
                log.info("RAG pipeline initialized.")
            except Exception as e:
                log.warning("Failed to load embedding model: %s", e)
        else:
            log.info("Embedding model not found; RAG disabled.")

        # Initialize router (requires embedding engine)
        if self.config.router_enabled and self.embedding_engine.is_loaded:
            try:
                self.router = QueryRouter(self.config, self.db, self.embedding_engine)
                self.router.startup()
            except Exception as e:
                log.warning("Router initialization failed, routing disabled: %s", e)
                self.router = None
        else:
            log.info("Router disabled (router_enabled=False or embedding model missing).")

    def shutdown(self) -> None:
        """Clean up resources."""
        self.inference.unload()
        self.embedding_engine.unload()
        self.db.close()
        log.info("Engine shut down.")

    def new_conversation(self, title: str | None = None) -> Conversation:
        """Start a new conversation."""
        self._current_conversation = self.conversations.create_conversation(title)
        log.info("New conversation: %s", self._current_conversation.id)
        return self._current_conversation

    def resume_conversation(self, conv_id: str) -> Conversation | None:
        """Resume an existing conversation."""
        conv = self.conversations.get_conversation(conv_id)
        if conv:
            self._current_conversation = conv
        return conv

    def _build_system_prompt_with_tools(self) -> str:
        """Build system prompt with tool definitions appended."""
        base = self.config.system_prompt
        if self.mcp:
            tools_text = self.mcp.get_tools_prompt()
            if tools_text:
                return base + "\n\n" + tools_text
        return base

    def chat(self, user_input: str) -> ChatResponse:
        """Process a user message with tool call loop support."""
        if not self.inference.is_loaded:
            raise RuntimeError("Model not loaded.")

        if self._current_conversation is None:
            self.new_conversation()

        conv_id = self._current_conversation.id

        # Save user message
        user_msg = self.conversations.add_message(conv_id, "user", user_input)
        if self.rag:
            self.rag.embed_message(user_msg.id, user_input)

        # Get recent history
        history = self.conversations.get_recent_messages(conv_id, limit=20)
        conversation_depth = max(0, len(history) - 1)

        # Router: retroactively evaluate the previous response, then route this query
        verdict = None
        decision_id: str | None = None
        if self.router:
            self.router.evaluate_previous_response(
                new_user_message=user_input,
                conversation_id=conv_id,
                tool_calls_succeeded=self._prev_tool_calls_succeeded,
                tool_calls_failed=self._prev_tool_calls_failed,
                rag_was_used=self._prev_rag_was_used,
            )
            verdict, decision_id = self.router.route(
                query=user_input,
                conversation_depth=conversation_depth,
                conversation_id=conv_id,
                message_id=user_msg.id,
            )

        use_rag = verdict.use_rag if verdict else True
        use_tools = verdict.use_tools if verdict else True

        # Build RAG context (respect router verdict)
        rag_context = None
        if self.rag and use_rag:
            rag_context = self.rag.build_rag_context(user_input)

        # Build messages (respect router verdict for tools)
        original_prompt = self.config.system_prompt
        if use_tools:
            self.config.system_prompt = self._build_system_prompt_with_tools()
        messages = build_messages(self.config, history[:-1], user_input, rag_context=rag_context)
        self.config.system_prompt = original_prompt

        # Decide execution path: platform vs local
        # Platform routing only applies when tools are not needed (different calling convention)
        use_platform = (
            verdict is not None
            and verdict.target != "local"
            and not use_tools
            and self.router is not None
            and bool(self.router.platform_manager.available_platforms())
        )

        total_prompt_tokens = 0
        total_completion_tokens = 0
        start = time.monotonic()
        final_content = ""
        model_used = self.config.model_filename
        tool_calls_succeeded = 0
        tool_calls_failed = 0

        if use_platform:
            platform_msgs = [
                PlatformMessage(role=m["role"], content=str(m.get("content", "")))
                for m in messages
            ]
            response = self.router.platform_manager.complete_with_fallback(
                messages=platform_msgs,
                preferred_platform=verdict.target,
                model=verdict.platform_model,
                max_tokens=self.config.max_tokens,
                temperature=self.config.temperature,
            )
            if response:
                final_content = response.content
                total_prompt_tokens = response.tokens_prompt
                total_completion_tokens = response.tokens_completion
                model_used = response.model
            else:
                log.warning("All platforms failed; falling back to local inference.")
                use_platform = False

        if not use_platform:
            # Local inference with tool call loop
            for iteration in range(MCP_MAX_TOOL_ITERATIONS + 1):
                result = self.inference.chat(messages)
                total_prompt_tokens += result.tokens_prompt
                total_completion_tokens += result.tokens_completion

                if self.mcp and self.mcp.has_tool_calls(result.content):
                    tool_results = self.mcp.execute_all(result.content, conv_id)
                    tool_output = self.mcp.format_tool_results(tool_results)

                    non_tool_text = self.mcp.strip_tool_calls(result.content)
                    if non_tool_text:
                        self.conversations.add_message(conv_id, "assistant", non_tool_text)

                    for tr in tool_results:
                        if tr.output and not tr.output.startswith("Error"):
                            tool_calls_succeeded += 1
                        else:
                            tool_calls_failed += 1
                        self.conversations.add_message(
                            conv_id, "tool", tr.output,
                            tool_name=tr.name,
                            tool_output=tr.output,
                        )

                    messages.append({"role": "assistant", "content": result.content})
                    messages.append({"role": "user", "content": tool_output})

                    if iteration >= MCP_MAX_TOOL_ITERATIONS:
                        final_content = (
                            f"{non_tool_text}\n\n"
                            "[Reached maximum tool iterations. Providing final answer.]\n\n"
                            f"Tool results:\n{tool_output}"
                        )
                        break
                    continue
                else:
                    final_content = result.content
                    break

        elapsed_ms = int((time.monotonic() - start) * 1000)

        # Record router metrics for this turn
        if self.router and decision_id:
            self.router.record_response_metrics(
                decision_id=decision_id,
                model_used=model_used,
                latency_ms=elapsed_ms,
                tokens_generated=total_completion_tokens,
            )

        # Store feedback signals for next turn's deferred evaluation
        self._prev_rag_was_used = rag_context is not None
        self._prev_tool_calls_succeeded = tool_calls_succeeded
        self._prev_tool_calls_failed = tool_calls_failed

        # Save final assistant message
        asst_msg = self.conversations.add_message(
            conv_id, "assistant", final_content,
            tokens_prompt=total_prompt_tokens,
            tokens_completion=total_completion_tokens,
            model_id=model_used,
            latency_ms=elapsed_ms,
        )
        if self.rag:
            self.rag.embed_message(asst_msg.id, final_content)

        # Auto-title
        if self._current_conversation.title is None:
            title = user_input[:60].strip()
            if len(user_input) > 60:
                title += "..."
            self.conversations.update_conversation(conv_id, title=title)

        return ChatResponse(
            content=final_content,
            conversation_id=conv_id,
            tokens_prompt=total_prompt_tokens,
            tokens_completion=total_completion_tokens,
            latency_ms=elapsed_ms,
        )

    def chat_stream(self, user_input: str) -> Iterator[str]:
        """Process a user message and stream the response tokens.

        Note: Streaming with tool calls falls back to non-streaming for
        the tool call iterations, then streams the final response.
        """
        if not self.inference.is_loaded:
            raise RuntimeError("Model not loaded.")

        if self._current_conversation is None:
            self.new_conversation()

        conv_id = self._current_conversation.id

        # Save user message
        user_msg = self.conversations.add_message(conv_id, "user", user_input)
        if self.rag:
            self.rag.embed_message(user_msg.id, user_input)

        # Get recent history
        history = self.conversations.get_recent_messages(conv_id, limit=20)
        conversation_depth = max(0, len(history) - 1)

        # Router: evaluate previous, then route
        verdict = None
        decision_id: str | None = None
        if self.router:
            self.router.evaluate_previous_response(
                new_user_message=user_input,
                conversation_id=conv_id,
                tool_calls_succeeded=self._prev_tool_calls_succeeded,
                tool_calls_failed=self._prev_tool_calls_failed,
                rag_was_used=self._prev_rag_was_used,
            )
            verdict, decision_id = self.router.route(
                query=user_input,
                conversation_depth=conversation_depth,
                conversation_id=conv_id,
                message_id=user_msg.id,
            )

        use_rag = verdict.use_rag if verdict else True
        use_tools = verdict.use_tools if verdict else True

        # Build RAG context
        rag_context = None
        if self.rag and use_rag:
            rag_context = self.rag.build_rag_context(user_input)

        # Build messages
        original_prompt = self.config.system_prompt
        if use_tools:
            self.config.system_prompt = self._build_system_prompt_with_tools()
        messages = build_messages(self.config, history[:-1], user_input, rag_context=rag_context)
        self.config.system_prompt = original_prompt

        # Platform streaming path (no tools)
        use_platform = (
            verdict is not None
            and verdict.target != "local"
            and not use_tools
            and self.router is not None
            and bool(self.router.platform_manager.available_platforms())
        )

        model_used = self.config.model_filename
        tool_calls_succeeded = 0
        tool_calls_failed = 0

        if use_platform:
            platform_msgs = [
                PlatformMessage(role=m["role"], content=str(m.get("content", "")))
                for m in messages
            ]
            platform_name, stream = self.router.platform_manager.stream_with_fallback(
                messages=platform_msgs,
                preferred_platform=verdict.target,
                model=verdict.platform_model,
                max_tokens=self.config.max_tokens,
                temperature=self.config.temperature,
            )
            if platform_name:
                start = time.monotonic()
                full_response = []
                for token in stream:
                    full_response.append(token)
                    yield token
                elapsed_ms = int((time.monotonic() - start) * 1000)
                content = "".join(full_response)
                model_used = f"{platform_name}/{verdict.platform_model or 'default'}"
            else:
                log.warning("Platform stream failed; falling back to local inference.")
                use_platform = False

        if not use_platform:
            # First pass: check if model wants to use tools (non-streaming)
            first_result = self.inference.chat(messages)

            if self.mcp and self.mcp.has_tool_calls(first_result.content):
                # Tool call detected — handle non-streaming, then stream final
                tool_results = self.mcp.execute_all(first_result.content, conv_id)
                tool_output = self.mcp.format_tool_results(tool_results)

                non_tool_text = self.mcp.strip_tool_calls(first_result.content)
                if non_tool_text:
                    yield non_tool_text + "\n\n"

                for tr in tool_results:
                    if tr.output and not tr.output.startswith("Error"):
                        tool_calls_succeeded += 1
                    else:
                        tool_calls_failed += 1
                    yield f"[Tool: {tr.name}] "
                    self.conversations.add_message(
                        conv_id, "tool", tr.output,
                        tool_name=tr.name, tool_output=tr.output,
                    )

                messages.append({"role": "assistant", "content": first_result.content})
                messages.append({"role": "user", "content": tool_output})

                start = time.monotonic()
                full_response = []
                for token in self.inference.chat_stream(messages):
                    full_response.append(token)
                    yield token

                elapsed_ms = int((time.monotonic() - start) * 1000)
                content = "".join(full_response)
            else:
                # No tool calls — stream the first result directly
                start = time.monotonic()
                for char_chunk in _chunk_text(first_result.content, 4):
                    yield char_chunk
                elapsed_ms = int((time.monotonic() - start) * 1000)
                content = first_result.content

        # Record router metrics
        if self.router and decision_id:
            self.router.record_response_metrics(
                decision_id=decision_id,
                model_used=model_used,
                latency_ms=elapsed_ms,
                tokens_generated=len(content) // 4,  # rough estimate
            )

        # Store feedback signals for next turn
        self._prev_rag_was_used = rag_context is not None
        self._prev_tool_calls_succeeded = tool_calls_succeeded
        self._prev_tool_calls_failed = tool_calls_failed

        # Save assistant message
        asst_msg = self.conversations.add_message(
            conv_id, "assistant", content,
            model_id=model_used,
            latency_ms=elapsed_ms,
        )
        if self.rag:
            self.rag.embed_message(asst_msg.id, content)

        # Auto-title
        if self._current_conversation.title is None:
            title = user_input[:60].strip()
            if len(user_input) > 60:
                title += "..."
            self.conversations.update_conversation(conv_id, title=title)

    def ingest_document(self, file_path: str | Path) -> tuple[str, int]:
        """Ingest a document for RAG. Returns (doc_id, chunk_count)."""
        if self.rag is None:
            raise RuntimeError("RAG pipeline not initialized (embedding model missing?).")
        return self.rag.ingest_document(Path(file_path))

    def rag_search(self, query: str) -> list[dict]:
        """Search RAG for relevant content."""
        if self.rag is None:
            return []
        results = self.rag.retrieve(query)
        return [
            {
                "source_type": r.record.source_type,
                "content": r.record.content_preview,
                "score": round(r.score, 3),
            }
            for r in results
        ]

    def list_conversations(self, limit: int = 20) -> list[Conversation]:
        return self.conversations.list_conversations(limit=limit)

    def get_history(self, conv_id: str | None = None) -> list[Message]:
        cid = conv_id or (self._current_conversation.id if self._current_conversation else None)
        if not cid:
            return []
        return self.conversations.get_messages(cid)

    # ── Training integration ──────────────────────────────────────────

    def prepare_training_dataset(
        self,
        conversation_ids: list[str] | None = None,
        document_ids: list[str] | None = None,
        jsonl_path: str | None = None,
        format: str = "alpaca",
    ) -> tuple[Path, int]:
        """Prepare a training dataset from conversations, documents, or JSONL.

        Returns (dataset_path, example_count).
        """
        from zdxai.training.dataset import DatasetBuilder

        builder = DatasetBuilder(self.db, self.config)
        examples = []

        if jsonl_path:
            examples.extend(builder.from_jsonl(Path(jsonl_path)))
        if conversation_ids is not None or (not jsonl_path and not document_ids):
            examples.extend(builder.from_conversations(conversation_ids))
        if document_ids is not None:
            examples.extend(builder.from_documents(document_ids))

        if not examples:
            raise ValueError("No training examples found.")

        output_path = self.config.data_dir / "training" / "dataset.jsonl"
        builder.build_dataset(examples, output_path, format=format)
        return output_path, len(examples)

    def start_training(
        self,
        adapter_name: str,
        dataset_path: Path,
        progress_callback=None,
        **training_kwargs,
    ) -> Path:
        """Run LoRA training and return the adapter path."""
        from zdxai.training.trainer import LoRATrainer, TrainingConfig

        if not self.config.training_hf_model_id:
            raise ValueError(
                "No HuggingFace model ID configured for training. "
                "Set training_hf_model_id in config or use a supported GGUF model."
            )

        tcfg = TrainingConfig(
            hf_model_id=self.config.training_hf_model_id,
            adapter_name=adapter_name,
            **training_kwargs,
        )

        trainer = LoRATrainer(tcfg, self.config, progress_callback=progress_callback)
        adapter_path = trainer.train(dataset_path)

        # Register the adapter
        if self.adapter_manager:
            self.adapter_manager.register_adapter(
                name=adapter_name,
                adapter_path=adapter_path,
                base_model=tcfg.hf_model_id,
            )

        return adapter_path

    def activate_adapter(self, name: str) -> None:
        """Activate a trained adapter and reload inference."""
        if self.adapter_manager is None:
            raise RuntimeError("Adapter manager not initialized.")
        self.adapter_manager.activate_adapter(name)
        self.inference.reload_adapter(self.config.adapter_path)
        log.info("Adapter '%s' activated, model reloaded.", name)

    def deactivate_adapter(self) -> None:
        """Deactivate the current adapter and reload inference."""
        if self.adapter_manager is None:
            raise RuntimeError("Adapter manager not initialized.")
        self.adapter_manager.deactivate_adapter()
        self.inference.reload_adapter(None)
        log.info("Adapter deactivated, model reloaded.")


def _chunk_text(text: str, chunk_size: int) -> Iterator[str]:
    """Yield text in chunks to simulate streaming."""
    for i in range(0, len(text), chunk_size):
        yield text[i : i + chunk_size]
