"""Embedding Gravity Wells query router."""

from zdxai.router.router import QueryRouter

__all__ = ["QueryRouter"]
