"""Embedding Gravity Wells: the core routing algorithm.

Routing decisions create gravity wells in embedding space. Each well is a
learned attractor with a centroid, mass, and quality score. New queries are
routed by computing gravitational pull toward existing wells. Wells grow,
shrink, split, and merge based on response quality.

No hardcoded query-type rules — the routing table IS the embedding space.
"""

from __future__ import annotations

import hashlib
import logging
import math
import uuid
from datetime import datetime, timezone

import numpy as np

from zdxai.router.cache import RoutingCache
from zdxai.router.types import GravityWell, QueryMetrics, RoutingVerdict

log = logging.getLogger(__name__)

_EPSILON = 1e-7


def _new_id() -> str:
    return uuid.uuid4().hex


def _now_iso() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%fZ")


def _cosine_similarity(a: np.ndarray, b: np.ndarray) -> float:
    """Cosine similarity between two vectors."""
    norm_a = np.linalg.norm(a)
    norm_b = np.linalg.norm(b)
    if norm_a < _EPSILON or norm_b < _EPSILON:
        return 0.0
    return float(np.dot(a, b) / (norm_a * norm_b))


def _euclidean_distance_normalized(a: np.ndarray, b: np.ndarray) -> float:
    """Euclidean distance normalized by sqrt(dim) to stay in [0, ~1]."""
    dim = len(a)
    dist = float(np.linalg.norm(a - b))
    return dist / (math.sqrt(dim) + _EPSILON)


class GravityField:
    """The gravity well routing algorithm.

    Maintains a set of wells in embedding space. New queries compute
    gravitational pull toward each well. The highest-pull well (above
    a threshold) determines the routing verdict.
    """

    def __init__(
        self,
        cache: RoutingCache,
        min_gravity: float = 0.5,
        split_variance_threshold: float = 0.3,
        merge_similarity_threshold: float = 0.95,
        max_wells: int = 500,
        mass_floor: float = 0.1,
        centroid_drift_alpha: float = 0.05,
        genesis_complexity_threshold: float = 0.6,
        prefer_local: bool = True,
    ) -> None:
        self._cache = cache
        self._min_gravity = min_gravity
        self._split_variance = split_variance_threshold
        self._merge_similarity = merge_similarity_threshold
        self._max_wells = max_wells
        self._mass_floor = mass_floor
        self._alpha = centroid_drift_alpha
        self._genesis_complexity = genesis_complexity_threshold
        self._prefer_local = prefer_local

        # In-memory well list (loaded from DB at init)
        self._wells: list[GravityWell] = []
        self._query_count_since_maintenance = 0

    def load(self) -> None:
        """Load active wells from the database into memory."""
        self._wells = self._cache.load_active_wells()
        log.info("Gravity field loaded: %d active wells.", len(self._wells))

    @property
    def well_count(self) -> int:
        return len(self._wells)

    # ── Core Routing ─────────────────────────────────────────────────

    def compute_verdict(
        self,
        query_embedding: np.ndarray,
        query_metrics: np.ndarray,
        available_platforms: list[str] | None = None,
    ) -> tuple[RoutingVerdict, float | None, str | None]:
        """Compute a routing verdict for the given query.

        Returns (verdict, gravitational_pull, well_id).
        If no well matches, falls through to genesis protocol.
        """
        if not self._wells:
            verdict = self._genesis_verdict(query_metrics, available_platforms)
            return verdict, None, None

        best_well: GravityWell | None = None
        best_pull: float = -1.0

        for well in self._wells:
            if not well.is_active:
                continue
            pull = self._gravitational_pull(
                query_embedding, query_metrics, well
            )
            if pull > best_pull:
                best_pull = pull
                best_well = well

        if best_well is not None and best_pull >= self._min_gravity:
            # Check if platform in verdict is still available
            verdict = best_well.verdict
            if verdict.is_platform and available_platforms is not None:
                if verdict.platform_name not in available_platforms:
                    # Platform unavailable — fall back to local
                    verdict = RoutingVerdict(
                        target="local",
                        use_rag=verdict.use_rag,
                        use_tools=verdict.use_tools,
                        confidence=verdict.confidence * 0.5,
                    )

            confidence = min(1.0, best_pull / (best_pull + 1.0))
            return (
                RoutingVerdict(
                    target=verdict.target,
                    use_rag=verdict.use_rag,
                    use_tools=verdict.use_tools,
                    platform_model=verdict.platform_model,
                    confidence=confidence,
                ),
                best_pull,
                best_well.id,
            )

        # No well has sufficient gravity — genesis
        verdict = self._genesis_verdict(query_metrics, available_platforms)
        return verdict, best_pull if best_pull > 0 else None, None

    def _gravitational_pull(
        self,
        query_embedding: np.ndarray,
        query_metrics: np.ndarray,
        well: GravityWell,
    ) -> float:
        """Compute gravitational pull between a query and a well.

        pull = mass * quality_ema * combined_sim² / (1 - combined_sim + ε)

        The sim² / (1 - sim) curve creates sharp decision boundaries:
        very similar queries get exponentially more pull.
        """
        cosine_sim = _cosine_similarity(query_embedding, well.centroid_embedding)
        feature_dist = _euclidean_distance_normalized(query_metrics, well.feature_centroid)
        feature_sim = max(0.0, 1.0 - feature_dist)

        combined_sim = 0.7 * cosine_sim + 0.3 * feature_sim
        combined_sim = max(0.0, min(0.999, combined_sim))  # clamp to avoid division by zero

        gravity = (
            well.mass
            * well.quality_ema
            * (combined_sim ** 2)
            / (1.0 - combined_sim + _EPSILON)
        )
        return gravity

    # ── Genesis Protocol ─────────────────────────────────────────────

    def _genesis_verdict(
        self,
        query_metrics: np.ndarray,
        available_platforms: list[str] | None = None,
    ) -> RoutingVerdict:
        """Make a routing decision from scratch for a novel query.

        Uses only the feature vector and simple heuristics. This is the
        ONLY place where heuristics exist — they get overridden by
        learned wells quickly.
        """
        metrics = QueryMetrics.from_array(query_metrics)

        use_rag = False
        use_tools = False
        target = "local"

        # Tool signals: file paths, URLs suggest tool use
        if metrics.path_signal > 0.5 or metrics.url_signal > 0.5:
            use_tools = True

        # Imperative queries often benefit from tools
        if metrics.imperative_signal > 0.5 and metrics.code_signal < 0.1:
            use_tools = True

        # RAG signals: longer queries, code, deep conversations
        if metrics.token_count_norm > 0.25 or metrics.code_signal > 0.15:
            use_rag = True
        if metrics.conversation_depth_norm > 0.3:
            use_rag = True

        # Complexity estimation for platform routing
        complexity = (
            min(1.0, metrics.token_count_norm) * 0.3
            + metrics.code_signal * 0.3
            + metrics.math_signal * 0.2
            + metrics.conversation_depth_norm * 0.2
        )

        if (
            complexity > self._genesis_complexity
            and not self._prefer_local
            and available_platforms
        ):
            target = f"platform:{available_platforms[0]}"

        return RoutingVerdict(
            target=target,
            use_rag=use_rag,
            use_tools=use_tools,
            platform_model=None,
            confidence=0.1,  # low confidence — genesis decisions
        )

    # ── Well Creation ────────────────────────────────────────────────

    def create_well(
        self,
        query_embedding: np.ndarray,
        query_metrics: np.ndarray,
        verdict: RoutingVerdict,
        parent_well_id: str | None = None,
    ) -> GravityWell:
        """Create a new gravity well at the given position."""
        now = _now_iso()
        well = GravityWell(
            id=_new_id(),
            centroid_embedding=query_embedding.copy(),
            feature_centroid=query_metrics.copy(),
            verdict=verdict,
            mass=1.0,
            quality_ema=0.5,
            sample_count=1,
            variance_accumulator=0.0,
            variance_mean=0.0,
            is_active=True,
            parent_well_id=parent_well_id,
            created_at=now,
            updated_at=now,
        )
        self._wells.append(well)
        self._cache.save_well(well)
        log.debug("Created gravity well %s (target=%s)", well.id[:8], verdict.target)
        return well

    # ── Well Updates ─────────────────────────────────────────────────

    def update_well(
        self,
        well: GravityWell,
        query_embedding: np.ndarray,
        query_metrics: np.ndarray,
        quality: float,
    ) -> None:
        """Update a well after a routing decision is evaluated.

        - Drifts the centroid toward the query (EMA)
        - Updates quality EMA
        - Adjusts mass based on quality
        - Tracks variance via Welford's online algorithm
        """
        alpha = self._alpha

        # Centroid drift (EMA)
        well.centroid_embedding = (
            (1 - alpha) * well.centroid_embedding + alpha * query_embedding
        )
        norm = np.linalg.norm(well.centroid_embedding)
        if norm > _EPSILON:
            well.centroid_embedding /= norm  # re-normalize

        well.feature_centroid = (
            (1 - alpha) * well.feature_centroid + alpha * query_metrics
        )

        # Quality EMA
        well.quality_ema = 0.9 * well.quality_ema + 0.1 * quality

        # Mass adjustment: good quality grows, bad quality shrinks
        mass_delta = (quality - 0.5) * 2.0
        well.mass = max(self._mass_floor, well.mass + mass_delta)

        # Welford's online variance of cosine distances from centroid
        well.sample_count += 1
        cosine_dist = 1.0 - _cosine_similarity(query_embedding, well.centroid_embedding)
        delta = cosine_dist - well.variance_mean
        well.variance_mean += delta / well.sample_count
        delta2 = cosine_dist - well.variance_mean
        well.variance_accumulator += delta * delta2

        self._cache.save_well(well)

    def get_well_variance(self, well: GravityWell) -> float:
        """Get the variance of queries attracted to this well."""
        if well.sample_count < 2:
            return 0.0
        return well.variance_accumulator / (well.sample_count - 1)

    # ── Well Splitting ───────────────────────────────────────────────

    def maybe_split_well(self, well: GravityWell) -> list[GravityWell] | None:
        """Split a well if its variance exceeds the threshold.

        Returns the two child wells if split occurred, None otherwise.
        """
        if well.sample_count < 20:
            return None

        variance = self.get_well_variance(well)
        if variance < self._split_variance:
            return None

        log.info(
            "Splitting well %s (variance=%.3f, samples=%d)",
            well.id[:8], variance, well.sample_count,
        )

        # Create two children with a deterministic perturbation.  BAN experiment
        # replay must not depend on process-global RNG state.  The centroid bytes
        # define the seed, so the same learned state produces the same split.
        seed_bytes = hashlib.sha256(
            well.centroid_embedding.astype(np.float32).tobytes()
            + str(well.sample_count).encode("ascii")
        ).digest()[:8]
        seed = int.from_bytes(seed_bytes, "big", signed=False)
        rng = np.random.default_rng(seed)
        perturbation = rng.standard_normal(len(well.centroid_embedding)).astype(np.float32)
        perturbation /= np.linalg.norm(perturbation) + _EPSILON
        perturbation *= 0.1  # small perturbation

        child_a = self.create_well(
            query_embedding=well.centroid_embedding + perturbation,
            query_metrics=well.feature_centroid.copy(),
            verdict=well.verdict,
            parent_well_id=well.id,
        )
        child_a.mass = well.mass / 2.0
        child_a.quality_ema = well.quality_ema
        self._cache.save_well(child_a)

        child_b = self.create_well(
            query_embedding=well.centroid_embedding - perturbation,
            query_metrics=well.feature_centroid.copy(),
            verdict=well.verdict,
            parent_well_id=well.id,
        )
        child_b.mass = well.mass / 2.0
        child_b.quality_ema = well.quality_ema
        self._cache.save_well(child_b)

        # Deactivate parent
        well.is_active = False
        self._cache.save_well(well)

        return [child_a, child_b]

    # ── Well Merging ─────────────────────────────────────────────────

    def run_maintenance(self) -> dict:
        """Run periodic maintenance: merge similar wells, prune excess.

        Returns stats about what was done.
        """
        merged = self._merge_similar_wells()
        pruned = self._cache.prune_lowest_mass_wells(self._max_wells)

        # Refresh in-memory list
        self._wells = self._cache.load_active_wells()
        self._query_count_since_maintenance = 0

        return {"merged": merged, "pruned": pruned, "active_wells": len(self._wells)}

    def _merge_similar_wells(self) -> int:
        """Merge well pairs with very similar centroids and same verdict."""
        merged_count = 0
        merged_ids: set[str] = set()

        for i, well_a in enumerate(self._wells):
            if not well_a.is_active or well_a.id in merged_ids:
                continue
            for well_b in self._wells[i + 1 :]:
                if not well_b.is_active or well_b.id in merged_ids:
                    continue
                if well_a.verdict.target != well_b.verdict.target:
                    continue
                if well_a.verdict.use_rag != well_b.verdict.use_rag:
                    continue
                if well_a.verdict.use_tools != well_b.verdict.use_tools:
                    continue

                sim = _cosine_similarity(
                    well_a.centroid_embedding, well_b.centroid_embedding
                )
                if sim >= self._merge_similarity:
                    self._merge_wells(well_a, well_b)
                    merged_ids.add(well_b.id)
                    merged_count += 1

        return merged_count

    def _merge_wells(self, keep: GravityWell, absorb: GravityWell) -> None:
        """Merge 'absorb' into 'keep'."""
        total_mass = keep.mass + absorb.mass
        w_keep = keep.mass / total_mass
        w_absorb = absorb.mass / total_mass

        # Quality-weighted centroid merge
        keep.centroid_embedding = (
            w_keep * keep.centroid_embedding + w_absorb * absorb.centroid_embedding
        )
        norm = np.linalg.norm(keep.centroid_embedding)
        if norm > _EPSILON:
            keep.centroid_embedding /= norm

        keep.feature_centroid = (
            w_keep * keep.feature_centroid + w_absorb * absorb.feature_centroid
        )

        keep.mass = total_mass
        keep.quality_ema = w_keep * keep.quality_ema + w_absorb * absorb.quality_ema
        keep.sample_count += absorb.sample_count
        self._cache.save_well(keep)

        absorb.is_active = False
        self._cache.save_well(absorb)

        log.debug(
            "Merged well %s into %s (combined mass=%.2f)",
            absorb.id[:8], keep.id[:8], total_mass,
        )

    # ── Maintenance Trigger ──────────────────────────────────────────

    def tick(self) -> dict | None:
        """Called after each routing decision. Triggers maintenance if due."""
        from zdxai.constants import ROUTER_WELL_MAINTENANCE_INTERVAL

        self._query_count_since_maintenance += 1
        if self._query_count_since_maintenance >= ROUTER_WELL_MAINTENANCE_INTERVAL:
            return self.run_maintenance()
        return None
