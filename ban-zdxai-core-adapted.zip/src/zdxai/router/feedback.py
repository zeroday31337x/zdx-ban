"""Implicit feedback detection from user messages.

Analyzes the user's next message to detect signals about the quality
of the previous response. No explicit thumbs-up/down required — the
system learns from natural conversational cues.
"""

from __future__ import annotations

import re


# Patterns that indicate the user is correcting the assistant
_CORRECTION_STARTS = (
    "no,", "no ", "no.", "nope", "wrong", "incorrect", "that's wrong",
    "that's not", "thats wrong", "thats not", "actually,", "actually ",
    "i meant", "i said", "not what i", "you misunderstood",
    "that doesn't", "that does not", "that isnt", "that isn't",
    "try again", "please try", "let me rephrase", "what i meant",
)

# Patterns that indicate the user is satisfied
_GRATITUDE_PATTERNS = re.compile(
    r"\b(?:thanks?|thank\s+you|thx|perfect|excellent|great|awesome|"
    r"good\s+job|well\s+done|exactly|nice|works?|got\s+it|helpful)\b",
    re.IGNORECASE,
)

# Patterns that indicate the user wants elaboration (neutral-to-negative)
_ELABORATION_STARTS = (
    "can you explain", "what do you mean", "i don't understand",
    "could you clarify", "more detail", "elaborate", "what about",
    "how does that", "why does", "but what",
)


class FeedbackDetector:
    """Detect implicit quality signals from a follow-up user message."""

    @staticmethod
    def detect_correction(message: str) -> bool:
        """Check if the message indicates the previous response was wrong."""
        lower = message.strip().lower()
        for pattern in _CORRECTION_STARTS:
            if lower.startswith(pattern):
                return True
        return False

    @staticmethod
    def detect_gratitude(message: str) -> bool:
        """Check if the message expresses satisfaction."""
        return bool(_GRATITUDE_PATTERNS.search(message))

    @staticmethod
    def detect_elaboration_request(message: str) -> bool:
        """Check if the user wants more detail (mildly negative signal)."""
        lower = message.strip().lower()
        for pattern in _ELABORATION_STARTS:
            if lower.startswith(pattern):
                return True
        return False

    @classmethod
    def analyze(cls, followup_message: str) -> dict[str, bool]:
        """Analyze a follow-up message for all signal types.

        Returns a dict with boolean flags for each signal.
        """
        return {
            "correction": cls.detect_correction(followup_message),
            "gratitude": cls.detect_gratitude(followup_message),
            "elaboration": cls.detect_elaboration_request(followup_message),
        }
