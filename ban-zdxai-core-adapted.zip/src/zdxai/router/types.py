"""Core dataclasses for the Embedding Gravity Wells router."""

from __future__ import annotations

import json
from dataclasses import dataclass, field

import numpy as np


@dataclass
class QueryMetrics:
    """Lightweight feature vector computed from query text without an LLM.

    Each field is a float in [0.0, 1.0] representing a structural signal.
    """

    token_count_norm: float = 0.0
    question_signal: float = 0.0
    imperative_signal: float = 0.0
    code_signal: float = 0.0
    url_signal: float = 0.0
    path_signal: float = 0.0
    math_signal: float = 0.0
    conversation_depth_norm: float = 0.0

    FEATURE_DIM: int = field(default=8, init=False, repr=False)

    def to_array(self) -> np.ndarray:
        """Convert to an 8-dimensional float32 numpy array."""
        return np.array(
            [
                self.token_count_norm,
                self.question_signal,
                self.imperative_signal,
                self.code_signal,
                self.url_signal,
                self.path_signal,
                self.math_signal,
                self.conversation_depth_norm,
            ],
            dtype=np.float32,
        )

    @classmethod
    def from_array(cls, arr: np.ndarray) -> QueryMetrics:
        """Reconstruct from a float32 array."""
        return cls(
            token_count_norm=float(arr[0]),
            question_signal=float(arr[1]),
            imperative_signal=float(arr[2]),
            code_signal=float(arr[3]),
            url_signal=float(arr[4]),
            path_signal=float(arr[5]),
            math_signal=float(arr[6]),
            conversation_depth_norm=float(arr[7]),
        )

    def to_json(self) -> str:
        return json.dumps(
            [
                self.token_count_norm,
                self.question_signal,
                self.imperative_signal,
                self.code_signal,
                self.url_signal,
                self.path_signal,
                self.math_signal,
                self.conversation_depth_norm,
            ]
        )

    @classmethod
    def from_json(cls, raw: str) -> QueryMetrics:
        arr = json.loads(raw)
        return cls.from_array(np.array(arr, dtype=np.float32))


@dataclass
class RoutingVerdict:
    """The routing decision for a single query."""

    target: str  # "local" | "platform:openai" | "platform:anthropic" | etc.
    use_rag: bool
    use_tools: bool
    platform_model: str | None = None
    confidence: float = 0.0

    def to_dict(self) -> dict:
        return {
            "target": self.target,
            "use_rag": self.use_rag,
            "use_tools": self.use_tools,
            "platform_model": self.platform_model,
            "confidence": self.confidence,
        }

    @classmethod
    def from_dict(cls, d: dict) -> RoutingVerdict:
        return cls(
            target=d["target"],
            use_rag=d["use_rag"],
            use_tools=d["use_tools"],
            platform_model=d.get("platform_model"),
            confidence=d.get("confidence", 0.0),
        )

    def to_json(self) -> str:
        return json.dumps(self.to_dict())

    @classmethod
    def from_json(cls, raw: str) -> RoutingVerdict:
        return cls.from_dict(json.loads(raw))

    @property
    def is_platform(self) -> bool:
        return self.target.startswith("platform:")

    @property
    def platform_name(self) -> str | None:
        if self.is_platform:
            return self.target.split(":", 1)[1]
        return None


@dataclass
class GravityWell:
    """A learned routing attractor in embedding space."""

    id: str
    centroid_embedding: np.ndarray  # 384-dim
    feature_centroid: np.ndarray  # 8-dim
    verdict: RoutingVerdict
    mass: float = 1.0
    quality_ema: float = 0.5
    sample_count: int = 0
    variance_accumulator: float = 0.0  # Welford's M2
    variance_mean: float = 0.0  # Welford's running mean of distances
    is_active: bool = True
    parent_well_id: str | None = None
    created_at: str = ""
    updated_at: str = ""


@dataclass
class QualitySignals:
    """Signals collected after a response for quality scoring."""

    latency_ms: int = 0
    tokens_generated: int = 0
    user_correction_detected: bool = False
    user_gratitude_detected: bool = False
    response_length_ratio: float = 0.0
    tool_calls_succeeded: int = 0
    tool_calls_failed: int = 0
    rag_was_used: bool = False
    rag_relevance_max: float = 0.0

    def to_dict(self) -> dict:
        return {
            "latency_ms": self.latency_ms,
            "tokens_generated": self.tokens_generated,
            "user_correction_detected": self.user_correction_detected,
            "user_gratitude_detected": self.user_gratitude_detected,
            "response_length_ratio": self.response_length_ratio,
            "tool_calls_succeeded": self.tool_calls_succeeded,
            "tool_calls_failed": self.tool_calls_failed,
            "rag_was_used": self.rag_was_used,
            "rag_relevance_max": self.rag_relevance_max,
        }

    def to_json(self) -> str:
        return json.dumps(self.to_dict())

    @classmethod
    def from_dict(cls, d: dict) -> QualitySignals:
        return cls(**d)


@dataclass
class RoutingDecision:
    """Persisted record of a routing decision for replay and evaluation."""

    id: str
    query_text: str
    query_embedding: np.ndarray
    query_metrics: QueryMetrics
    well_id: str | None
    verdict: RoutingVerdict
    gravitational_pull: float | None
    confidence: float
    quality_score: float | None = None
    quality_signals: QualitySignals | None = None
    conversation_id: str | None = None
    message_id: str | None = None
    model_used: str | None = None
    latency_ms: int | None = None
    created_at: str = ""
