"""Response quality evaluation for the routing feedback loop.

Computes a quality score (0.0–1.0) from objective metrics and implicit
user feedback. This score drives gravity well updates — good routing
decisions strengthen wells, bad ones weaken them.
"""

from __future__ import annotations

from zdxai.router.feedback import FeedbackDetector
from zdxai.router.types import QualitySignals, RoutingDecision


class ResponseEvaluator:
    """Evaluate response quality and produce signals for well updates."""

    def __init__(self) -> None:
        self._feedback = FeedbackDetector()

    def build_signals(
        self,
        decision: RoutingDecision,
        followup_message: str | None = None,
        tool_calls_succeeded: int = 0,
        tool_calls_failed: int = 0,
        rag_was_used: bool = False,
        rag_relevance_max: float = 0.0,
        tokens_generated: int = 0,
        query_tokens: int = 0,
    ) -> QualitySignals:
        """Build quality signals from a completed routing decision.

        Args:
            decision: The routing decision to evaluate.
            followup_message: The user's next message (for implicit feedback).
            tool_calls_succeeded: Number of successful tool calls.
            tool_calls_failed: Number of failed tool calls.
            rag_was_used: Whether RAG context was injected.
            rag_relevance_max: Highest cosine similarity of retrieved chunks.
            tokens_generated: Tokens in the assistant response.
            query_tokens: Estimated tokens in the user query.
        """
        correction = False
        gratitude = False

        if followup_message:
            feedback = self._feedback.analyze(followup_message)
            correction = feedback["correction"]
            gratitude = feedback["gratitude"]

        length_ratio = 0.0
        if query_tokens > 0:
            length_ratio = min(5.0, tokens_generated / query_tokens)

        return QualitySignals(
            latency_ms=decision.latency_ms or 0,
            tokens_generated=tokens_generated,
            user_correction_detected=correction,
            user_gratitude_detected=gratitude,
            response_length_ratio=length_ratio,
            tool_calls_succeeded=tool_calls_succeeded,
            tool_calls_failed=tool_calls_failed,
            rag_was_used=rag_was_used,
            rag_relevance_max=rag_relevance_max,
        )

    @staticmethod
    def compute_score(signals: QualitySignals) -> float:
        """Compute a quality score (0.0–1.0) from signals.

        The score is a weighted combination of objective metrics and
        implicit user feedback. The baseline is 0.5 (neutral).
        """
        score = 0.5

        # Latency: reward fast responses, penalize very slow ones
        if signals.latency_ms < 2000:
            score += 0.1
        elif signals.latency_ms < 5000:
            score += 0.05
        elif signals.latency_ms > 10000:
            score -= 0.1

        # Response substance: generated meaningful content
        if signals.tokens_generated > 20:
            score += 0.1
        elif signals.tokens_generated < 5:
            score -= 0.1

        # Length ratio: response proportional to query
        if 0.5 < signals.response_length_ratio < 5.0:
            score += 0.05

        # Tool success rate
        total_tools = signals.tool_calls_succeeded + signals.tool_calls_failed
        if total_tools > 0:
            success_rate = signals.tool_calls_succeeded / total_tools
            score += 0.15 * success_rate
            score -= 0.1 * (1.0 - success_rate)

        # RAG relevance: if RAG was used, reward high relevance
        if signals.rag_was_used and signals.rag_relevance_max > 0.5:
            score += 0.1

        # Implicit user feedback (strongest signals)
        if signals.user_gratitude_detected:
            score += 0.2
        if signals.user_correction_detected:
            score -= 0.3

        return max(0.0, min(1.0, score))
