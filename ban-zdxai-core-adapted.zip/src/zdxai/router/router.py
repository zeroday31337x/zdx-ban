"""QueryRouter: the main entry point for the Embedding Gravity Wells system.

Composes fingerprinting, gravity wells, evaluation, caching, and platform
management into a single interface used by the Engine.
"""

from __future__ import annotations

import logging

import numpy as np

from zdxai.config import Config
from zdxai.core.embeddings import EmbeddingEngine
from zdxai.router.cache import RoutingCache
from zdxai.router.evaluator import ResponseEvaluator
from zdxai.router.fingerprint import QueryFingerprinter
from zdxai.router.gravity import GravityField
from zdxai.router.platforms.manager import PlatformManager
from zdxai.router.types import QualitySignals, RoutingVerdict
from zdxai.storage.database import Database

log = logging.getLogger(__name__)


class QueryRouter:
    """Embedding Gravity Wells query router.

    Decides per-query: local model vs platform AI, RAG vs no RAG,
    tools vs no tools. Learns from implicit user feedback and
    improves routing over time.
    """

    def __init__(
        self,
        config: Config,
        db: Database,
        embedding_engine: EmbeddingEngine,
    ) -> None:
        self._config = config
        self._cache = RoutingCache(db)
        self._fingerprinter = QueryFingerprinter(embedding_engine)
        self._evaluator = ResponseEvaluator()
        self._gravity = GravityField(
            cache=self._cache,
            min_gravity=config.router_min_gravity,
            split_variance_threshold=config.router_well_split_threshold,
            max_wells=500,
            centroid_drift_alpha=config.router_feedback_alpha,
            genesis_complexity_threshold=config.router_genesis_complexity,
            prefer_local=config.router_prefer_local,
        )
        self.platform_manager = PlatformManager(db)

        # Track the last decision for deferred evaluation
        self._last_decision_id: str | None = None
        self._last_decision_tokens: int = 0

    def startup(self) -> None:
        """Load gravity wells and discover platforms."""
        self._gravity.load()
        available = self.platform_manager.discover()
        log.info(
            "Router ready: %d wells, %d platforms (%s)",
            self._gravity.well_count,
            len(available),
            ", ".join(available) if available else "none",
        )

    # ── Main Routing ─────────────────────────────────────────────────

    def route(
        self,
        query: str,
        conversation_depth: int = 0,
        conversation_id: str | None = None,
        message_id: str | None = None,
    ) -> tuple[RoutingVerdict, str]:
        """Route a query. Returns (verdict, decision_id).

        This is the main entry point called by Engine.chat().
        """
        # Fingerprint
        embedding, metrics = self._fingerprinter.fingerprint(
            query, conversation_depth
        )
        metrics_array = metrics.to_array()

        # Compute verdict via gravity wells
        available = self.platform_manager.available_platforms() or None
        verdict, pull, well_id = self._gravity.compute_verdict(
            embedding, metrics_array, available
        )

        # If no well matched (genesis), create a new well
        if well_id is None:
            well = self._gravity.create_well(embedding, metrics_array, verdict)
            well_id = well.id

        # Record decision
        decision_id = self._cache.record_decision(
            query_text=query,
            query_embedding=embedding,
            query_metrics=metrics,
            verdict=verdict,
            well_id=well_id,
            gravitational_pull=pull,
            confidence=verdict.confidence,
            conversation_id=conversation_id,
            message_id=message_id,
        )

        # Track for deferred evaluation
        self._last_decision_id = decision_id

        # Maintenance tick
        maintenance = self._gravity.tick()
        if maintenance:
            log.info(
                "Gravity maintenance: merged=%d pruned=%d active=%d",
                maintenance["merged"],
                maintenance["pruned"],
                maintenance["active_wells"],
            )

        log.debug(
            "Routed query → %s (confidence=%.2f, well=%s, pull=%s)",
            verdict.target,
            verdict.confidence,
            well_id[:8] if well_id else "genesis",
            f"{pull:.3f}" if pull is not None else "N/A",
        )

        return verdict, decision_id

    # ── Post-Response Recording ──────────────────────────────────────

    def record_response_metrics(
        self,
        decision_id: str,
        model_used: str,
        latency_ms: int,
        tokens_generated: int = 0,
    ) -> None:
        """Record which model handled the query and response metrics."""
        self._cache.update_decision_model(decision_id, model_used, latency_ms)
        self._last_decision_tokens = tokens_generated

    # ── Deferred Evaluation ──────────────────────────────────────────

    def evaluate_previous_response(
        self,
        new_user_message: str,
        conversation_id: str | None = None,
        tool_calls_succeeded: int = 0,
        tool_calls_failed: int = 0,
        rag_was_used: bool = False,
        rag_relevance_max: float = 0.0,
    ) -> None:
        """Evaluate the previous routing decision based on the new user message.

        Called at the start of each chat() invocation to retroactively
        score the last response using implicit feedback signals.
        """
        decision = self._cache.get_last_unevaluated_decision(conversation_id)
        if not decision:
            return

        # Estimate query tokens from stored text length
        query_tokens = max(1, len(decision.query_text) // 4)

        signals = self._evaluator.build_signals(
            decision=decision,
            followup_message=new_user_message,
            tool_calls_succeeded=tool_calls_succeeded,
            tool_calls_failed=tool_calls_failed,
            rag_was_used=rag_was_used,
            rag_relevance_max=rag_relevance_max,
            tokens_generated=self._last_decision_tokens,
            query_tokens=query_tokens,
        )
        quality = self._evaluator.compute_score(signals)

        # Update the decision record
        self._cache.update_decision_quality(decision.id, quality, signals)

        # Update the gravity well
        if decision.well_id:
            well = self._cache.get_well(decision.well_id)
            if well and well.is_active:
                self._gravity.update_well(
                    well=well,
                    query_embedding=decision.query_embedding,
                    query_metrics=decision.query_metrics.to_array(),
                    quality=quality,
                )

                # Check if well needs splitting
                self._gravity.maybe_split_well(well)

        log.debug(
            "Evaluated decision %s: quality=%.2f (correction=%s, gratitude=%s)",
            decision.id[:8],
            quality,
            signals.user_correction_detected,
            signals.user_gratitude_detected,
        )

    # ── Stats & Replay ───────────────────────────────────────────────

    def stats(self) -> dict:
        """Return router statistics."""
        return {
            "active_wells": self._gravity.well_count,
            "total_decisions": self._cache.decision_count(),
            "platforms_available": self.platform_manager.available_platforms(),
            "platform_stats": self.platform_manager.get_platform_stats(),
        }

    def replay(self, limit: int = 100) -> list[dict]:
        """Replay recent decisions against current well state."""
        return self._cache.replay_batch(self._gravity, limit)

    def recent_decisions(self, limit: int = 20) -> list[dict]:
        """Get recent routing decisions as dicts for display."""
        decisions = self._cache.get_recent_decisions(limit)
        return [
            {
                "id": d.id[:8],
                "target": d.verdict.target,
                "use_rag": d.verdict.use_rag,
                "use_tools": d.verdict.use_tools,
                "confidence": round(d.confidence, 2),
                "quality": round(d.quality_score, 2) if d.quality_score is not None else None,
                "model": d.model_used,
                "latency_ms": d.latency_ms,
                "query": d.query_text[:80],
            }
            for d in decisions
        ]
