"""Query fingerprinting: embedding vector + structural feature vector."""

from __future__ import annotations

import re

import numpy as np

from zdxai.core.embeddings import EmbeddingEngine
from zdxai.router.types import QueryMetrics

# Words that signal an imperative (command-like) query
_IMPERATIVE_WORDS = frozenset({
    "write", "create", "make", "build", "generate", "show", "list", "find",
    "search", "get", "set", "run", "execute", "open", "close", "delete",
    "remove", "install", "update", "fix", "explain", "describe", "summarize",
    "translate", "convert", "compare", "analyze", "check", "test", "deploy",
    "read", "send", "move", "copy", "rename", "download", "upload", "start",
    "stop", "restart", "configure", "add", "edit", "modify", "change",
    "help", "tell", "give", "compute", "calculate", "sort", "filter",
    "refactor", "debug", "optimize", "implement", "design", "plan",
})

_CODE_CHARS = frozenset("{}();=><[]!&|@#$`\\")
_MATH_CHARS = frozenset("+-*/=^%0123456789")
_URL_PATTERN = re.compile(r"https?://")
_PATH_PATTERN = re.compile(r"(?:^|[\s\"'])[/~][\w./-]+|[A-Z]:\\[\w.\\-]+")


class QueryFingerprinter:
    """Compute a query embedding and lightweight structural feature vector.

    The embedding captures semantic meaning. The feature vector captures
    structural properties (code-like, command-like, file references, etc.)
    using fast string analysis — no LLM calls.
    """

    def __init__(self, embedding_engine: EmbeddingEngine) -> None:
        self._embedding = embedding_engine

    def fingerprint(
        self,
        query: str,
        conversation_depth: int = 0,
    ) -> tuple[np.ndarray, QueryMetrics]:
        """Return (embedding_384d, metrics_8d) for a query string."""
        embedding = self._embedding.embed(query)
        metrics = self.compute_metrics(query, conversation_depth)
        return embedding, metrics

    @staticmethod
    def compute_metrics(query: str, conversation_depth: int = 0) -> QueryMetrics:
        """Compute the 8-dim structural feature vector from raw text."""
        text = query.strip()
        if not text:
            return QueryMetrics()

        length = len(text)

        # Token count approximation: ~4 chars per token for English
        est_tokens = length / 4.0
        token_count_norm = min(1.0, est_tokens / 200.0)

        # Question signal
        question_signal = 1.0 if "?" in text else 0.0

        # Imperative signal: does the first word look like a command?
        first_word = text.split()[0].lower().rstrip(".,!?:;")
        imperative_signal = 1.0 if first_word in _IMPERATIVE_WORDS else 0.0

        # Code signal: ratio of code-like characters
        code_count = sum(1 for ch in text if ch in _CODE_CHARS)
        code_signal = min(1.0, code_count / max(1, length) * 10.0)

        # URL signal
        url_signal = 1.0 if _URL_PATTERN.search(text) else 0.0

        # Path signal
        path_signal = 1.0 if _PATH_PATTERN.search(text) else 0.0

        # Math signal: ratio of math-like characters
        math_count = sum(1 for ch in text if ch in _MATH_CHARS)
        math_signal = min(1.0, math_count / max(1, length) * 5.0)

        # Conversation depth (saturates at 20 turns)
        conversation_depth_norm = min(1.0, conversation_depth / 20.0)

        return QueryMetrics(
            token_count_norm=token_count_norm,
            question_signal=question_signal,
            imperative_signal=imperative_signal,
            code_signal=code_signal,
            url_signal=url_signal,
            path_signal=path_signal,
            math_signal=math_signal,
            conversation_depth_norm=conversation_depth_norm,
        )
