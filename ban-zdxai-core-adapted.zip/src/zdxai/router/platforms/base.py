"""Abstract base for platform AI runners."""

from __future__ import annotations

from abc import ABC, abstractmethod
from collections.abc import Iterator
from dataclasses import dataclass


@dataclass
class PlatformMessage:
    """Unified message format for all platforms."""

    role: str  # "system", "user", "assistant"
    content: str


@dataclass
class PlatformResponse:
    """Unified response format returned by all platform runners."""

    content: str
    model: str
    tokens_prompt: int
    tokens_completion: int
    latency_ms: int
    platform: str
    finish_reason: str  # "stop", "length", "error"


class PlatformRunner(ABC):
    """Abstract base for external AI platform runners.

    Each runner handles authentication, model selection, request
    formatting, and response parsing for a specific platform.
    API keys are read from environment variables at runtime —
    never stored on disk.
    """

    name: str = ""
    api_key_env_var: str = ""
    default_base_url: str = ""
    free_model: str = ""
    paid_model: str = ""

    @abstractmethod
    def is_available(self) -> bool:
        """Check if the platform is configured (API key present)."""
        ...

    @abstractmethod
    def get_api_key(self) -> str | None:
        """Read the API key from the environment."""
        ...

    @abstractmethod
    def select_model(self) -> str:
        """Auto-select the best available model.

        Returns the paid model if an API key is set and the platform
        supports it, otherwise the free/cheapest model.
        """
        ...

    @abstractmethod
    def complete(
        self,
        messages: list[PlatformMessage],
        model: str | None = None,
        max_tokens: int = 1024,
        temperature: float = 0.7,
    ) -> PlatformResponse:
        """Synchronous chat completion."""
        ...

    @abstractmethod
    def complete_stream(
        self,
        messages: list[PlatformMessage],
        model: str | None = None,
        max_tokens: int = 1024,
        temperature: float = 0.7,
    ) -> Iterator[str]:
        """Streaming chat completion. Yields content tokens."""
        ...
