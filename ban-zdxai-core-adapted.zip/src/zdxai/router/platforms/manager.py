"""Platform manager: discovery, selection, fallback, and rate limiting."""

from __future__ import annotations

import logging
import time
import uuid
from datetime import datetime, timezone

from zdxai.storage.database import Database
from zdxai.router.platforms.base import (
    PlatformMessage,
    PlatformResponse,
    PlatformRunner,
)
from zdxai.router.platforms.openai_runner import OpenAIPlatformRunner
from zdxai.router.platforms.anthropic_runner import AnthropicPlatformRunner
from zdxai.router.platforms.gemini_runner import GeminiPlatformRunner
from zdxai.router.platforms.xai_runner import XAIPlatformRunner

log = logging.getLogger(__name__)


def _now_iso() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%fZ")


class PlatformManager:
    """Manages all platform runners.

    Handles discovery (which platforms have API keys), selection
    (which platform to use for a given request), fallback (try
    the next platform if one fails), and rate limit tracking.
    """

    def __init__(self, db: Database) -> None:
        self._db = db
        self._runners: dict[str, PlatformRunner] = {}
        self._rate_limits: dict[str, dict] = {}

    def discover(self) -> list[str]:
        """Discover which platforms are available (have API keys).

        Returns a list of available platform names.
        """
        all_runners = [
            OpenAIPlatformRunner(),
            AnthropicPlatformRunner(),
            GeminiPlatformRunner(),
            XAIPlatformRunner(),
        ]

        self._runners.clear()
        available = []

        for runner in all_runners:
            if runner.is_available():
                self._runners[runner.name] = runner
                available.append(runner.name)
                log.info("Platform discovered: %s", runner.name)
                self._ensure_platform_config(runner)
            else:
                log.debug("Platform not available: %s (no API key)", runner.name)

        return available

    def available_platforms(self) -> list[str]:
        """Return names of currently available platforms."""
        return list(self._runners.keys())

    def get_runner(self, name: str) -> PlatformRunner | None:
        return self._runners.get(name)

    def complete_with_fallback(
        self,
        messages: list[PlatformMessage],
        preferred_platform: str | None = None,
        model: str | None = None,
        max_tokens: int = 1024,
        temperature: float = 0.7,
    ) -> PlatformResponse | None:
        """Try to complete using the preferred platform, falling back to others.

        Returns None if all platforms fail.
        """
        # Build ordered list: preferred first, then others
        order = []
        if preferred_platform and preferred_platform in self._runners:
            order.append(preferred_platform)
        for name in self._runners:
            if name not in order:
                order.append(name)

        for platform_name in order:
            runner = self._runners[platform_name]

            # Check rate limit
            if not self._check_rate_limit(platform_name):
                log.debug("Platform %s rate limited, skipping.", platform_name)
                continue

            try:
                response = runner.complete(
                    messages=messages,
                    model=model if platform_name == preferred_platform else None,
                    max_tokens=max_tokens,
                    temperature=temperature,
                )
                self._record_request(
                    platform_name=platform_name,
                    model=response.model,
                    tokens_prompt=response.tokens_prompt,
                    tokens_completion=response.tokens_completion,
                    latency_ms=response.latency_ms,
                    status="success",
                )
                return response

            except Exception as exc:
                log.warning(
                    "Platform %s failed: %s. Trying next.",
                    platform_name, exc,
                )
                self._record_request(
                    platform_name=platform_name,
                    model=model or runner.select_model(),
                    tokens_prompt=0,
                    tokens_completion=0,
                    latency_ms=0,
                    status="error",
                    error_message=str(exc)[:500],
                )
                continue

        return None

    def stream_with_fallback(
        self,
        messages: list[PlatformMessage],
        preferred_platform: str | None = None,
        model: str | None = None,
        max_tokens: int = 1024,
        temperature: float = 0.7,
    ):
        """Stream from preferred platform, falling back on error.

        Yields (platform_name, token_iterator) on success, or None on failure.
        """
        order = []
        if preferred_platform and preferred_platform in self._runners:
            order.append(preferred_platform)
        for name in self._runners:
            if name not in order:
                order.append(name)

        for platform_name in order:
            runner = self._runners[platform_name]
            if not self._check_rate_limit(platform_name):
                continue

            try:
                stream = runner.complete_stream(
                    messages=messages,
                    model=model if platform_name == preferred_platform else None,
                    max_tokens=max_tokens,
                    temperature=temperature,
                )
                return platform_name, stream
            except Exception as exc:
                log.warning("Platform %s stream failed: %s", platform_name, exc)
                continue

        return None, iter([])

    # ── Rate Limiting ────────────────────────────────────────────────

    def _check_rate_limit(self, platform_name: str) -> bool:
        """Check if we can make a request to this platform."""
        limits = self._rate_limits.get(platform_name)
        if not limits:
            return True

        remaining = limits.get("remaining", 60)
        reset_at = limits.get("reset_at", 0)

        if remaining <= 0:
            if time.time() < reset_at:
                return False
            # Reset window expired
            limits["remaining"] = limits.get("rpm", 60)

        return True

    def _decrement_rate_limit(self, platform_name: str) -> None:
        if platform_name not in self._rate_limits:
            self._rate_limits[platform_name] = {
                "remaining": 59,
                "rpm": 60,
                "reset_at": time.time() + 60,
            }
        else:
            self._rate_limits[platform_name]["remaining"] -= 1

    # ── Persistence ──────────────────────────────────────────────────

    def _ensure_platform_config(self, runner: PlatformRunner) -> None:
        """Ensure a platform_configs row exists for this runner."""
        row = self._db.execute(
            "SELECT id FROM platform_configs WHERE platform_name = ?",
            (runner.name,),
        ).fetchone()

        if not row:
            self._db.execute(
                """INSERT INTO platform_configs
                   (id, platform_name, api_key_env_var, base_url,
                    free_model, paid_model, is_enabled, created_at, updated_at)
                   VALUES (?, ?, ?, ?, ?, ?, 1, ?, ?)""",
                (
                    uuid.uuid4().hex,
                    runner.name,
                    runner.api_key_env_var,
                    runner.default_base_url,
                    runner.free_model,
                    runner.paid_model,
                    _now_iso(),
                    _now_iso(),
                ),
            )
            self._db.commit()

    def _record_request(
        self,
        platform_name: str,
        model: str,
        tokens_prompt: int,
        tokens_completion: int,
        latency_ms: int,
        status: str,
        error_message: str | None = None,
        decision_id: str | None = None,
    ) -> None:
        """Log a platform request for analytics and rate limiting."""
        self._db.execute(
            """INSERT INTO platform_requests
               (id, platform_name, model, tokens_prompt, tokens_completion,
                latency_ms, status, error_message, decision_id, created_at)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (
                uuid.uuid4().hex,
                platform_name,
                model,
                tokens_prompt,
                tokens_completion,
                latency_ms,
                status,
                error_message,
                decision_id,
                _now_iso(),
            ),
        )
        self._db.commit()
        self._decrement_rate_limit(platform_name)

        # Update platform stats
        self._db.execute(
            """UPDATE platform_configs SET
                 total_requests = total_requests + 1,
                 total_tokens = total_tokens + ? + ?,
                 updated_at = ?
               WHERE platform_name = ?""",
            (tokens_prompt, tokens_completion, _now_iso(), platform_name),
        )
        self._db.commit()

    def get_platform_stats(self) -> list[dict]:
        """Get stats for all configured platforms."""
        rows = self._db.execute(
            "SELECT * FROM platform_configs ORDER BY platform_name"
        ).fetchall()
        stats = []
        for row in rows:
            stats.append({
                "platform": row["platform_name"],
                "is_available": row["platform_name"] in self._runners,
                "is_enabled": bool(row["is_enabled"]),
                "free_model": row["free_model"],
                "paid_model": row["paid_model"],
                "total_requests": row["total_requests"],
                "total_tokens": row["total_tokens"],
                "quality_ema": row["quality_ema"],
            })
        return stats
