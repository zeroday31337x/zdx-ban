"""OpenAI platform runner."""

from __future__ import annotations

import json
import logging
import os
import time
from collections.abc import Iterator

import httpx

from zdxai.router.platforms.base import (
    PlatformMessage,
    PlatformResponse,
    PlatformRunner,
)

log = logging.getLogger(__name__)


class OpenAIPlatformRunner(PlatformRunner):
    """Runner for the OpenAI API (chat completions)."""

    name = "openai"
    api_key_env_var = "OPENAI_API_KEY"
    default_base_url = "https://api.openai.com/v1"
    free_model = "gpt-3.5-turbo"
    paid_model = "gpt-4o"

    def __init__(self, base_url: str | None = None) -> None:
        self._base_url = base_url or self.default_base_url

    def is_available(self) -> bool:
        return self.get_api_key() is not None

    def get_api_key(self) -> str | None:
        return os.environ.get(self.api_key_env_var)

    def select_model(self) -> str:
        return self.paid_model if self.get_api_key() else self.free_model

    def complete(
        self,
        messages: list[PlatformMessage],
        model: str | None = None,
        max_tokens: int = 1024,
        temperature: float = 0.7,
    ) -> PlatformResponse:
        api_key = self.get_api_key()
        if not api_key:
            raise RuntimeError("OpenAI API key not configured.")

        model = model or self.select_model()
        payload = {
            "model": model,
            "messages": [{"role": m.role, "content": m.content} for m in messages],
            "max_tokens": max_tokens,
            "temperature": temperature,
        }

        start = time.monotonic()
        with httpx.Client(timeout=60.0) as client:
            resp = client.post(
                f"{self._base_url}/chat/completions",
                headers={
                    "Authorization": f"Bearer {api_key}",
                    "Content-Type": "application/json",
                },
                json=payload,
            )
        latency_ms = int((time.monotonic() - start) * 1000)

        resp.raise_for_status()
        data = resp.json()

        choice = data["choices"][0]
        usage = data.get("usage", {})

        return PlatformResponse(
            content=choice["message"]["content"],
            model=data.get("model", model),
            tokens_prompt=usage.get("prompt_tokens", 0),
            tokens_completion=usage.get("completion_tokens", 0),
            latency_ms=latency_ms,
            platform=self.name,
            finish_reason=choice.get("finish_reason", "stop"),
        )

    def complete_stream(
        self,
        messages: list[PlatformMessage],
        model: str | None = None,
        max_tokens: int = 1024,
        temperature: float = 0.7,
    ) -> Iterator[str]:
        api_key = self.get_api_key()
        if not api_key:
            raise RuntimeError("OpenAI API key not configured.")

        model = model or self.select_model()
        payload = {
            "model": model,
            "messages": [{"role": m.role, "content": m.content} for m in messages],
            "max_tokens": max_tokens,
            "temperature": temperature,
            "stream": True,
        }

        with httpx.Client(timeout=120.0) as client:
            with client.stream(
                "POST",
                f"{self._base_url}/chat/completions",
                headers={
                    "Authorization": f"Bearer {api_key}",
                    "Content-Type": "application/json",
                },
                json=payload,
            ) as resp:
                resp.raise_for_status()
                for line in resp.iter_lines():
                    if not line.startswith("data: "):
                        continue
                    payload_str = line[6:]
                    if payload_str.strip() == "[DONE]":
                        break
                    try:
                        chunk = json.loads(payload_str)
                        delta = chunk["choices"][0].get("delta", {})
                        content = delta.get("content")
                        if content:
                            yield content
                    except (json.JSONDecodeError, KeyError, IndexError):
                        continue
