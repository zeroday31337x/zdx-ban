"""Platform AI runners for external model providers."""

from zdxai.router.platforms.manager import PlatformManager

__all__ = ["PlatformManager"]
