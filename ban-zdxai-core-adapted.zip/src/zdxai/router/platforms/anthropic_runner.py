"""Anthropic platform runner."""

from __future__ import annotations

import json
import logging
import os
import time
from collections.abc import Iterator

import httpx

from zdxai.router.platforms.base import (
    PlatformMessage,
    PlatformResponse,
    PlatformRunner,
)

log = logging.getLogger(__name__)

_API_VERSION = "2023-06-01"


class AnthropicPlatformRunner(PlatformRunner):
    """Runner for the Anthropic Messages API."""

    name = "anthropic"
    api_key_env_var = "ANTHROPIC_API_KEY"
    default_base_url = "https://api.anthropic.com/v1"
    free_model = "claude-3-haiku-20240307"
    paid_model = "claude-sonnet-4-20250514"

    def __init__(self, base_url: str | None = None) -> None:
        self._base_url = base_url or self.default_base_url

    def is_available(self) -> bool:
        return self.get_api_key() is not None

    def get_api_key(self) -> str | None:
        return os.environ.get(self.api_key_env_var)

    def select_model(self) -> str:
        return self.paid_model if self.get_api_key() else self.free_model

    def _build_payload(
        self,
        messages: list[PlatformMessage],
        model: str,
        max_tokens: int,
        temperature: float,
        stream: bool = False,
    ) -> dict:
        """Build the Anthropic Messages API payload.

        Anthropic requires system messages to be passed separately.
        """
        system_text = ""
        api_messages = []

        for msg in messages:
            if msg.role == "system":
                system_text = msg.content
            else:
                api_messages.append({"role": msg.role, "content": msg.content})

        payload = {
            "model": model,
            "messages": api_messages,
            "max_tokens": max_tokens,
            "temperature": temperature,
        }
        if system_text:
            payload["system"] = system_text
        if stream:
            payload["stream"] = True

        return payload

    def _headers(self, api_key: str) -> dict[str, str]:
        return {
            "x-api-key": api_key,
            "anthropic-version": _API_VERSION,
            "Content-Type": "application/json",
        }

    def complete(
        self,
        messages: list[PlatformMessage],
        model: str | None = None,
        max_tokens: int = 1024,
        temperature: float = 0.7,
    ) -> PlatformResponse:
        api_key = self.get_api_key()
        if not api_key:
            raise RuntimeError("Anthropic API key not configured.")

        model = model or self.select_model()
        payload = self._build_payload(messages, model, max_tokens, temperature)

        start = time.monotonic()
        with httpx.Client(timeout=60.0) as client:
            resp = client.post(
                f"{self._base_url}/messages",
                headers=self._headers(api_key),
                json=payload,
            )
        latency_ms = int((time.monotonic() - start) * 1000)

        resp.raise_for_status()
        data = resp.json()

        content_blocks = data.get("content", [])
        content = "".join(
            block.get("text", "") for block in content_blocks if block.get("type") == "text"
        )

        usage = data.get("usage", {})

        return PlatformResponse(
            content=content,
            model=data.get("model", model),
            tokens_prompt=usage.get("input_tokens", 0),
            tokens_completion=usage.get("output_tokens", 0),
            latency_ms=latency_ms,
            platform=self.name,
            finish_reason=data.get("stop_reason", "end_turn"),
        )

    def complete_stream(
        self,
        messages: list[PlatformMessage],
        model: str | None = None,
        max_tokens: int = 1024,
        temperature: float = 0.7,
    ) -> Iterator[str]:
        api_key = self.get_api_key()
        if not api_key:
            raise RuntimeError("Anthropic API key not configured.")

        model = model or self.select_model()
        payload = self._build_payload(
            messages, model, max_tokens, temperature, stream=True
        )

        with httpx.Client(timeout=120.0) as client:
            with client.stream(
                "POST",
                f"{self._base_url}/messages",
                headers=self._headers(api_key),
                json=payload,
            ) as resp:
                resp.raise_for_status()
                for line in resp.iter_lines():
                    if not line.startswith("data: "):
                        continue
                    try:
                        event = json.loads(line[6:])
                        if event.get("type") == "content_block_delta":
                            delta = event.get("delta", {})
                            text = delta.get("text", "")
                            if text:
                                yield text
                    except (json.JSONDecodeError, KeyError):
                        continue
