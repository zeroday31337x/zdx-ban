"""Google Gemini platform runner."""

from __future__ import annotations

import json
import logging
import os
import time
from collections.abc import Iterator

import httpx

from zdxai.router.platforms.base import (
    PlatformMessage,
    PlatformResponse,
    PlatformRunner,
)

log = logging.getLogger(__name__)


class GeminiPlatformRunner(PlatformRunner):
    """Runner for the Google Gemini (Generative Language) API."""

    name = "gemini"
    api_key_env_var = "GEMINI_API_KEY"
    default_base_url = "https://generativelanguage.googleapis.com/v1beta"
    free_model = "gemini-2.0-flash"
    paid_model = "gemini-2.0-pro"

    def __init__(self, base_url: str | None = None) -> None:
        self._base_url = base_url or self.default_base_url

    def is_available(self) -> bool:
        return self.get_api_key() is not None

    def get_api_key(self) -> str | None:
        return os.environ.get(self.api_key_env_var)

    def select_model(self) -> str:
        return self.paid_model if self.get_api_key() else self.free_model

    def _build_contents(
        self, messages: list[PlatformMessage]
    ) -> tuple[list[dict], str | None]:
        """Convert messages to Gemini contents format.

        Gemini uses "user" and "model" roles, with system instruction separate.
        Returns (contents_list, system_instruction_text).
        """
        system_text = None
        contents = []

        for msg in messages:
            if msg.role == "system":
                system_text = msg.content
                continue

            role = "model" if msg.role == "assistant" else "user"
            contents.append({
                "role": role,
                "parts": [{"text": msg.content}],
            })

        return contents, system_text

    def complete(
        self,
        messages: list[PlatformMessage],
        model: str | None = None,
        max_tokens: int = 1024,
        temperature: float = 0.7,
    ) -> PlatformResponse:
        api_key = self.get_api_key()
        if not api_key:
            raise RuntimeError("Gemini API key not configured.")

        model = model or self.select_model()
        contents, system_text = self._build_contents(messages)

        payload: dict = {
            "contents": contents,
            "generationConfig": {
                "maxOutputTokens": max_tokens,
                "temperature": temperature,
            },
        }
        if system_text:
            payload["systemInstruction"] = {
                "parts": [{"text": system_text}]
            }

        url = f"{self._base_url}/models/{model}:generateContent?key={api_key}"

        start = time.monotonic()
        with httpx.Client(timeout=60.0) as client:
            resp = client.post(
                url,
                headers={"Content-Type": "application/json"},
                json=payload,
            )
        latency_ms = int((time.monotonic() - start) * 1000)

        resp.raise_for_status()
        data = resp.json()

        candidates = data.get("candidates", [])
        content = ""
        if candidates:
            parts = candidates[0].get("content", {}).get("parts", [])
            content = "".join(p.get("text", "") for p in parts)

        usage = data.get("usageMetadata", {})
        finish_reason = candidates[0].get("finishReason", "STOP") if candidates else "ERROR"

        return PlatformResponse(
            content=content,
            model=model,
            tokens_prompt=usage.get("promptTokenCount", 0),
            tokens_completion=usage.get("candidatesTokenCount", 0),
            latency_ms=latency_ms,
            platform=self.name,
            finish_reason=finish_reason.lower(),
        )

    def complete_stream(
        self,
        messages: list[PlatformMessage],
        model: str | None = None,
        max_tokens: int = 1024,
        temperature: float = 0.7,
    ) -> Iterator[str]:
        api_key = self.get_api_key()
        if not api_key:
            raise RuntimeError("Gemini API key not configured.")

        model = model or self.select_model()
        contents, system_text = self._build_contents(messages)

        payload: dict = {
            "contents": contents,
            "generationConfig": {
                "maxOutputTokens": max_tokens,
                "temperature": temperature,
            },
        }
        if system_text:
            payload["systemInstruction"] = {
                "parts": [{"text": system_text}]
            }

        url = (
            f"{self._base_url}/models/{model}:streamGenerateContent"
            f"?alt=sse&key={api_key}"
        )

        with httpx.Client(timeout=120.0) as client:
            with client.stream(
                "POST",
                url,
                headers={"Content-Type": "application/json"},
                json=payload,
            ) as resp:
                resp.raise_for_status()
                for line in resp.iter_lines():
                    if not line.startswith("data: "):
                        continue
                    try:
                        chunk = json.loads(line[6:])
                        candidates = chunk.get("candidates", [])
                        if candidates:
                            parts = candidates[0].get("content", {}).get("parts", [])
                            for part in parts:
                                text = part.get("text", "")
                                if text:
                                    yield text
                    except (json.JSONDecodeError, KeyError):
                        continue
