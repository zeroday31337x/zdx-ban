"""SQLite persistence for gravity wells, routing decisions, and replay."""

from __future__ import annotations

import json
import uuid
from datetime import datetime, timezone

import numpy as np

from zdxai.storage.database import Database
from zdxai.storage.embeddings_store import blob_to_embedding, embedding_to_blob
from zdxai.router.types import (
    GravityWell,
    QualitySignals,
    QueryMetrics,
    RoutingDecision,
    RoutingVerdict,
)


def _new_id() -> str:
    return uuid.uuid4().hex


def _now_iso() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%fZ")


class RoutingCache:
    """Persistent storage for gravity wells and routing decisions."""

    def __init__(self, db: Database) -> None:
        self._db = db

    # ── Gravity Wells ────────────────────────────────────────────────

    def load_active_wells(self) -> list[GravityWell]:
        """Load all active gravity wells from the database."""
        rows = self._db.execute(
            "SELECT * FROM routing_wells WHERE is_active = 1"
        ).fetchall()
        return [self._row_to_well(r) for r in rows]

    def get_well(self, well_id: str) -> GravityWell | None:
        row = self._db.execute(
            "SELECT * FROM routing_wells WHERE id = ?", (well_id,)
        ).fetchone()
        return self._row_to_well(row) if row else None

    def save_well(self, well: GravityWell) -> None:
        """Insert or update a gravity well."""
        now = _now_iso()
        self._db.execute(
            """INSERT INTO routing_wells
               (id, centroid_embedding, feature_centroid, verdict_json,
                mass, quality_ema, sample_count, variance_accumulator,
                variance_mean, is_active, parent_well_id, created_at, updated_at)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
               ON CONFLICT(id) DO UPDATE SET
                 centroid_embedding = excluded.centroid_embedding,
                 feature_centroid = excluded.feature_centroid,
                 verdict_json = excluded.verdict_json,
                 mass = excluded.mass,
                 quality_ema = excluded.quality_ema,
                 sample_count = excluded.sample_count,
                 variance_accumulator = excluded.variance_accumulator,
                 variance_mean = excluded.variance_mean,
                 is_active = excluded.is_active,
                 updated_at = excluded.updated_at
            """,
            (
                well.id,
                embedding_to_blob(well.centroid_embedding),
                embedding_to_blob(well.feature_centroid),
                well.verdict.to_json(),
                well.mass,
                well.quality_ema,
                well.sample_count,
                well.variance_accumulator,
                well.variance_mean,
                1 if well.is_active else 0,
                well.parent_well_id,
                well.created_at or now,
                now,
            ),
        )
        self._db.commit()

    def deactivate_well(self, well_id: str) -> None:
        self._db.execute(
            "UPDATE routing_wells SET is_active = 0, updated_at = ? WHERE id = ?",
            (_now_iso(), well_id),
        )
        self._db.commit()

    def delete_well(self, well_id: str) -> None:
        self._db.execute("DELETE FROM routing_wells WHERE id = ?", (well_id,))
        self._db.commit()

    def well_count(self, active_only: bool = True) -> int:
        clause = " WHERE is_active = 1" if active_only else ""
        row = self._db.execute(
            f"SELECT COUNT(*) AS c FROM routing_wells{clause}"
        ).fetchone()
        return row["c"]

    def prune_lowest_mass_wells(self, max_wells: int) -> int:
        """Remove the lowest-mass wells if count exceeds max_wells. Returns count pruned."""
        count = self.well_count()
        if count <= max_wells:
            return 0
        excess = count - max_wells
        self._db.execute(
            """DELETE FROM routing_wells
               WHERE id IN (
                 SELECT id FROM routing_wells
                 WHERE is_active = 1
                 ORDER BY mass ASC
                 LIMIT ?
               )""",
            (excess,),
        )
        self._db.commit()
        return excess

    def _row_to_well(self, row) -> GravityWell:
        return GravityWell(
            id=row["id"],
            centroid_embedding=blob_to_embedding(row["centroid_embedding"]),
            feature_centroid=blob_to_embedding(row["feature_centroid"]),
            verdict=RoutingVerdict.from_json(row["verdict_json"]),
            mass=row["mass"],
            quality_ema=row["quality_ema"],
            sample_count=row["sample_count"],
            variance_accumulator=row["variance_accumulator"],
            variance_mean=row["variance_mean"],
            is_active=bool(row["is_active"]),
            parent_well_id=row["parent_well_id"],
            created_at=row["created_at"],
            updated_at=row["updated_at"],
        )

    # ── Routing Decisions ────────────────────────────────────────────

    def record_decision(
        self,
        query_text: str,
        query_embedding: np.ndarray,
        query_metrics: QueryMetrics,
        verdict: RoutingVerdict,
        well_id: str | None,
        gravitational_pull: float | None,
        confidence: float,
        conversation_id: str | None = None,
        message_id: str | None = None,
    ) -> str:
        """Record a routing decision. Returns the decision ID."""
        decision_id = _new_id()
        self._db.execute(
            """INSERT INTO routing_decisions
               (id, query_text, query_embedding, query_metrics_json,
                well_id, verdict_json, gravitational_pull, confidence,
                conversation_id, message_id, created_at)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (
                decision_id,
                query_text[:2000],
                embedding_to_blob(query_embedding),
                query_metrics.to_json(),
                well_id,
                verdict.to_json(),
                gravitational_pull,
                confidence,
                conversation_id,
                message_id,
                _now_iso(),
            ),
        )
        self._db.commit()
        return decision_id

    def update_decision_quality(
        self,
        decision_id: str,
        quality_score: float,
        signals: QualitySignals,
    ) -> None:
        """Fill in the quality evaluation for a decision."""
        self._db.execute(
            """UPDATE routing_decisions
               SET quality_score = ?, quality_signals_json = ?
               WHERE id = ?""",
            (quality_score, signals.to_json(), decision_id),
        )
        self._db.commit()

    def update_decision_model(
        self, decision_id: str, model_used: str, latency_ms: int
    ) -> None:
        """Record which model actually handled the query."""
        self._db.execute(
            "UPDATE routing_decisions SET model_used = ?, latency_ms = ? WHERE id = ?",
            (model_used, latency_ms, decision_id),
        )
        self._db.commit()

    def get_last_unevaluated_decision(
        self, conversation_id: str | None = None,
    ) -> RoutingDecision | None:
        """Get the most recent decision that hasn't been quality-scored yet."""
        if conversation_id:
            row = self._db.execute(
                """SELECT * FROM routing_decisions
                   WHERE quality_score IS NULL AND conversation_id = ?
                   ORDER BY created_at DESC LIMIT 1""",
                (conversation_id,),
            ).fetchone()
        else:
            row = self._db.execute(
                """SELECT * FROM routing_decisions
                   WHERE quality_score IS NULL
                   ORDER BY created_at DESC LIMIT 1""",
            ).fetchone()
        return self._row_to_decision(row) if row else None

    def get_decision(self, decision_id: str) -> RoutingDecision | None:
        row = self._db.execute(
            "SELECT * FROM routing_decisions WHERE id = ?", (decision_id,)
        ).fetchone()
        return self._row_to_decision(row) if row else None

    def get_recent_decisions(self, limit: int = 50) -> list[RoutingDecision]:
        rows = self._db.execute(
            "SELECT * FROM routing_decisions ORDER BY created_at DESC LIMIT ?",
            (limit,),
        ).fetchall()
        return [self._row_to_decision(r) for r in rows]

    def decision_count(self) -> int:
        row = self._db.execute(
            "SELECT COUNT(*) AS c FROM routing_decisions"
        ).fetchone()
        return row["c"]

    def _row_to_decision(self, row) -> RoutingDecision:
        signals = None
        if row["quality_signals_json"]:
            signals = QualitySignals.from_dict(json.loads(row["quality_signals_json"]))
        return RoutingDecision(
            id=row["id"],
            query_text=row["query_text"],
            query_embedding=blob_to_embedding(row["query_embedding"]),
            query_metrics=QueryMetrics.from_json(row["query_metrics_json"]),
            well_id=row["well_id"],
            verdict=RoutingVerdict.from_json(row["verdict_json"]),
            gravitational_pull=row["gravitational_pull"],
            confidence=row["confidence"],
            quality_score=row["quality_score"],
            quality_signals=signals,
            conversation_id=row["conversation_id"],
            message_id=row["message_id"],
            model_used=row["model_used"],
            latency_ms=row["latency_ms"],
            created_at=row["created_at"],
        )

    # ── Replay ───────────────────────────────────────────────────────

    def replay_batch(
        self,
        gravity_field,
        limit: int = 100,
    ) -> list[dict]:
        """Replay recent decisions against current well state.

        Returns a list of dicts with original vs replayed verdicts.
        """
        decisions = self.get_recent_decisions(limit)
        results = []
        for d in decisions:
            replayed_verdict, replayed_pull = gravity_field.compute_verdict(
                d.query_embedding, d.query_metrics.to_array()
            )
            results.append({
                "decision_id": d.id,
                "original_target": d.verdict.target,
                "replayed_target": replayed_verdict.target,
                "changed": d.verdict.target != replayed_verdict.target,
                "original_confidence": d.confidence,
                "replayed_confidence": replayed_verdict.confidence,
                "quality_score": d.quality_score,
            })
        return results
